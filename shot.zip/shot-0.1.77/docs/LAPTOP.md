# CandleLab on a laptop: lock, sleep, power and internet

Written 14 October 2026 at the owner's request: «make sure we properly handle the cases on a laptop: screen lock, turn off, power off, internet off; and prepare a guide for the user on how to keep the computer». The same guide is inside the app: **Settings → Computer state → How to set up the computer** (Ukrainian and English, tabs for macOS, Windows 11 and Linux GNOME). This file is the plain-steps version.

## The short version

1. **Locking the screen is safe.** The screensaver and a dark display do not stop CandleLab.
2. **Sleep is not safe.** A sleeping computer runs nothing: no prices, no paper, no time exits. Closing the lid of a laptop puts it to sleep. So do *Sleep*, *Hibernate*, *Shut down*, *Restart* and *Log out*.
3. **What stays when CandleLab is not running:** the stop-loss and the take-profit that CandleLab placed *on the exchange* before it entered. Nothing else does.
4. Keep the laptop **plugged in, awake and online**; turn on `npm run autostart:on`; run `npm run doctor` once a week.

## What stops CandleLab, and what does not

| What happens | CandleLab keeps running? |
|---|---|
| Screen locks, screensaver starts, display turns off | **Yes.** Programs, network and prices carry on. |
| You switch to another user without logging out | Yes. |
| Lid closed (no external display), *Sleep*, idle sleep | **No.** The whole process is frozen. |
| *Hibernate*, *Shut down*, *Restart*, an OS update restart, *Log out* | **No.** The process ends. |
| Battery runs flat, power cut | **No.** The process is killed without a goodbye. |
| Internet drops | Yes, but CandleLab is blind: no prices, no order changes. |
| The app crashes | **No** (until it is started again; with autostart that is about 10 seconds). |
| You close the terminal window | Only if CandleLab runs in that window (`npm start`, `npm run dev`). Started with `npm run app:up` or by autostart, it keeps going. |

## What the exchange protects while CandleLab is off

Before every live entry CandleLab places a stop-loss (and usually a take-profit) **on the exchange** and checks that it is there; a position never exists without it (docs/STAGED_EXITS.md, «A position never exists without an open exchange-side stop»). These stay in force with CandleLab switched off, the computer asleep or the internet gone.

What is **not** protected, because it lives inside CandleLab:

- **Time exits** (the trade's deadline) wait until CandleLab is back; an overdue one is made at once, at market, on the first pass after the return.
- **Moves of the stop**: breakeven, trailing, partial take-profits of staged exits.
- **New entries**: none are taken while CandleLab is off.
- **Paper**: the simulation stands still.
- **Alerts** to the phone.

## The six things to do

### macOS (Sonoma, Sequoia, Tahoe)

1. **Keep it plugged in.** On battery the Mac sleeps sooner and the battery can run out.
2. **Never let it sleep.**
   - System Settings → **Battery** → **Options…** → turn on *Prevent automatic sleeping on power adapter when the display is off*. (Mac mini, iMac, Studio: System Settings → **Displays** → **Advanced…**.)
   - System Settings → Battery → Low Power Mode → Never.
   - System Settings → **Lock Screen**: set the display and screen saver to anything you like.
   - Start CandleLab with `npm run app:up` or `npm run autostart:on`: it then asks macOS not to sleep by itself with `caffeinate -i -s` (see below).
3. **Do not close the lid.** A MacBook sleeps when the lid closes, whatever a program asks. The one exception is *clamshell mode*: power adapter + external display + keyboard or mouse connected.
4. **Stop update restarts.** System Settings → General → **Software Update** → (i) next to *Automatic updates* → turn off *Install macOS updates*. Do not press *Restart now* while you trade.
5. **Stable internet, exact time.** Use a cable (Ethernet adapter) or a Wi-Fi that does not switch networks. Turn off VPNs that drop (Tailscale can stay). System Settings → General → **Date & Time** → *Set time and date automatically*.
6. **Autostart and a weekly check.** `npm run autostart:on` (a LaunchAgent: it starts after you log in and after a crash). Automatic login is not available with FileVault; then, after a restart, CandleLab waits for you to log in. Run `npm run doctor` once a week.

### Windows 11

1. **Keep it plugged in.**
2. **Never let it sleep.**
   - Settings → System → **Power & battery** → *Screen, sleep & hibernate timeouts* → *When plugged in, put my device to sleep after* → **Never**. (The screen timeout may stay.)
   - Same page: *Power mode* → Balanced or Best performance; *Battery saver* → *Turn on automatically* → Never.
   - Start CandleLab with `npm run app:up` or `npm run autostart:on`: a hidden PowerShell holds the *system required* state (`SetThreadExecutionState`) while CandleLab runs. No administrator rights are needed.
3. **Lid: do nothing.** Control Panel → Hardware and Sound → **Power Options** → *Choose what closing the lid does* → *When I close the lid* → **Plugged in** → *Do nothing*. (Or Settings → System → Power & battery → *Lid, power & sleep button controls*.) Leave *On battery* at *Sleep*. Some new laptops use *Modern Standby*: test the lid for a minute before trusting it overnight.
4. **Stop update restarts.** Settings → Windows Update → **Advanced options** → *Active hours* → Manual: cover the hours CandleLab works. Turn on *Notify me when a restart is required to finish updating*. While you trade: *Pause updates*. Windows Home cannot fully turn off automatic restarts.
5. **Stable internet, exact time.** Prefer Ethernet. For Wi-Fi: Device Manager → Network adapters → your Wi-Fi → Properties → *Power Management* → turn off *Allow the computer to turn off this device to save power*. Settings → Time & language → Date & time → *Set time automatically* → *Sync now*.
6. **Autostart and a weekly check.** `npm run autostart:on` (a Task Scheduler task at log-on, restarted after a crash; a console window may flash). After a restart for an update, CandleLab starts when you log in.

### Linux (Ubuntu GNOME)

1. **Keep it plugged in.**
2. **Never let it sleep.** Settings → **Power** → *Automatic Suspend* → *Plugged In* → Off (and *On Battery Power* → Off), or `gsettings set org.gnome.settings-daemon.plugins.power sleep-inactive-ac-type 'nothing'` (and `sleep-inactive-battery-type`). Start CandleLab with `npm run app:up` or `npm run autostart:on` (it holds a `systemd-inhibit` lock for sleep and idle).
3. **Lid: ignore.** GNOME has no switch; `sudo nano /etc/systemd/logind.conf`, in `[Login]` set `HandleLidSwitch=ignore`, `HandleLidSwitchExternalPower=ignore`, `HandleLidSwitchDocked=ignore` and `IdleAction=ignore`, then reboot. (Restarting `systemd-logind` on the fly can end your session.)
4. **Stop update restarts.** Software & Updates → Updates → *When there are security updates* → *Display immediately*. `grep -r Automatic-Reboot /etc/apt/apt.conf.d/` must say `"false"` or nothing.
5. **Stable internet, exact time.** Ethernet, or turn off Wi-Fi power saving: in `/etc/NetworkManager/conf.d/default-wifi-powersave-on.conf` set `wifi.powersave = 2`. `timedatectl set-ntp true`; `timedatectl status` should say *System clock synchronized: yes*.
6. **Autostart and a weekly check.** `npm run autostart:on` (a systemd **user** service) and, once, `loginctl enable-linger $USER` so it starts at boot without anyone logged in.

## What happens if…

| If | Live positions | Paper | Alerts | What CandleLab does when it is back |
|---|---|---|---|---|
| The screen locks, the screensaver starts, the display turns off | Nothing changes. | Nothing changes. | As usual. | Nothing to recover. |
| The lid is closed (not clamshell) or the computer sleeps | The exchange-side stop and target stay. Time exits and stop moves (breakeven, trailing) wait. | Stands still. | Do not arrive. | Within about 5 seconds of waking it sees the gap, reconnects the price feeds, measures the exchange clocks again, checks live trades against the exchange (an overdue time exit is made at once), re-evaluates paper against the minute candles of the gap, takes **no** signal of a bar that closed unseen, and sends **one** alert with a summary. |
| The computer is shut down or restarted | Same as sleep: only the exchange-side stop and target. | Stands still, state saved. | Do not arrive. | After the next start (by itself with autostart, once you log in): «started after the computer restarted», check against the exchange, paper re-evaluated. |
| The battery runs flat | Like a sudden power-off. | Stands still. | Do not arrive. | «The computer switched off suddenly», database check, check against the exchange. |
| Power cut | The exchange-side stop and target stay. | Stands still. | Do not arrive; the heartbeat stops, so your phone tells you if you set it up. | CandleLab sees the last run did not end cleanly, runs `PRAGMA quick_check` on the databases, checks the exchange and shows a banner «positions checked: all fine / need attention». |
| The internet drops | The exchange-side stop and target stay. CandleLab cannot see prices or change orders. | Prices older than 30 s are ignored: nothing is evaluated. | Stay in the app; they cannot reach the phone. | After about 45 s the journal says the internet is gone. When it is back: price feeds reconnect, exchange check, paper re-evaluated against candles, one summary alert (if the outage was over 2 minutes or something was open). |
| Wi-Fi switches for a moment | Usually nothing: breaks under ~45 s are not an event. | Nothing. | Nothing. | The feeds reconnect by themselves (their watchdogs). |
| An OS update restarts the computer | As a shutdown. | Stands still. | Do not arrive. | CandleLab starts after you log in (autostart), then as after a restart. |
| The app crashes | The exchange-side stop and target stay; time exits and stop moves wait. | Stands still. | Do not arrive until CandleLab runs. | With autostart: back in about 10 s (macOS, Linux) or a minute (Windows), «restarted after a crash». Without it: down until you start it. |
| You close the terminal | Nothing if CandleLab runs through `npm run app:up` or autostart. | Same. | Same. | If CandleLab ran in that window it stops in an orderly way (the window's hang-up is handled like a stop); start it again. |

## Before you leave the laptop for the night

- [ ] The charger is plugged in and charging.
- [ ] The lid is open (or clamshell: power, external display, keyboard).
- [ ] `npm run doctor` shows no red items.
- [ ] The **Computer** chip at the top of the app is green.
- [ ] CandleLab was started with `npm run app:up` or by autostart, not in a terminal window you will close.
- [ ] The internet is stable: cable or reliable Wi-Fi, no VPN that drops.
- [ ] Automatic updates will not restart the system at night.
- [ ] Every open live position has an exchange-side stop (Live page).
- [ ] Phone alerts work (send a test one) and, if you like, the heartbeat is set up.

## What CandleLab does by itself now

All of it lives in `server/health/` and is covered by tests (`npm test`).

- **Run record** (`data/health/run.json`, a small file, written every 10 s, replaced atomically). A graceful stop (SIGINT, SIGTERM, SIGHUP) marks it *clean*. At the next start CandleLab knows whether the last run ended cleanly, for how long nothing ran, and whether the **computer** was restarted in between (it booted after the record's last sign of life). So «crash», «power loss or forced shutdown», «computer restarted, CandleLab stopped cleanly» and «stopped and started again» are different sentences.
- **Sleep, wake and clock steps.** A timer fires every 5 s and compares the wall clock with the monotonic clock. While the computer sleeps the monotonic clock of macOS and Linux stands still and the wall clock runs on, so *wall minus monotonic* is the sleep. More than 30 s is a *sleep* (a clock set forward reads the same); a jump backwards of more than 3 s is *clock set back*; a timer that is more than a minute late on both clocks is a *stall*. Durations of this process never use the wall clock.
- **Network.** Every 15 s (5 s while something fails) CandleLab asks the exchanges' public ping (Binance `/fapi/v1/ping`, Bybit `/v5/market/time`, Bybit only while it is in use) and resolves a host name. Three failed rounds in a row = lost, two good ones = back, so a hiccup never spams. An exchange that answers with an error while the internet works is reported as that exchange being down. The clock of the computer is compared with the exchange's (Bybit's time, Binance's `Date` header).
- **Recovery hooks, once per event** (a sleep, a stall, a restart, an outage that ends): the floor under entries (below); the price guards of the paper brokers learn which stretch nobody watched; the price feeds reconnect at once; the clock offset of the exchange clients is measured again; each live module runs **one** management pass now (the same pass as every 5 seconds, under the same lock): it re-checks each open trade against the exchange and its stop, makes an overdue time exit, and opens nothing. The result is the verdict «checked: all fine / needs attention / could not be checked».
- **Nothing acts on a price older than 30 seconds.** Paper reads prices through `GuardedPrices` (`server/health/prices.ts`): a price older than 30 s is invisible to the paper broker, so it neither opens nor evaluates on it.
- **A stretch nobody watched is looked at against the candles.** After a sleep, an outage or a restart, the paper broker's check of an open position is held until the minute candles of the gap are fetched over REST (`missedRange`: only candles *wholly* inside the gap, so a candle that began before a position existed never counts); then the gap's lowest and highest price are merged into the normal check: a stop or target touched while the computer slept fires **at its own level**, with the broker's usual slippage and «stop first on a tie». If the candles cannot be fetched (three retries), the position is checked against the live price only and the journal says so. **Found from the position itself too (6 Nov 2026):** the health service notes the stretch only after it has seen two good rounds of pings, and the price feeds are often back a few seconds earlier; in those seconds the broker looked at the position with the live price alone and moved its «checked until» time to the present, so the stretch noted afterwards held no whole candle and a stop crossed in the 31-hour outage of 1 Nov was never fired (docs/PARITY.md §16, `server/health/paperGap.test.ts`). `GuardedPrices.range` therefore treats a position last looked at more than two minutes ago as unwatched in between, whatever the cause (a sleep, an outage, a restart, a dead feed), and fetches the candles from that time to now before anything else (`UNWATCHED_MS`); the note from the health service stays and is skipped for such a position. A long stretch for which the exchange returns no candle at all is journaled.
- **A restart and the arming (9 Nov 2026).** By default every start switches real-money entries off. The owner can turn on «Перезапуск не вимикає входи» (Live page, Binance mainnet): entries that were on stay on across a restart, a crash or a power loss, for the same API key; the floor below still refuses signals of bars that closed unseen, and the terms are checked again at start. docs/SERVER.md «Restarts».
- **Entries for signals that fired while the computer was off are NOT taken late.** Each entry loop (Binance live, Bybit live, the paper runner) has a *floor*: a signal bar that closed before CandleLab was watching again is skipped, and the summary counts the skipped bars («Bars missed: 6»). The same floor is set at every start.
- **One summary, in the journal and as an alert** (important level: in the app, and on the phone through ntfy/Telegram/webhook if they are configured), e.g. «The computer slept 02:10–03:45 (95 min). Live positions on the exchange: 1. The exchange-side stop and target protected them the whole time. Time exits and stop moves (breakeven, trailing) were paused. Checked against the exchange: all fine. Paper positions: 2. The missed stretch will be re-evaluated against the one-minute candles. No new entries were opened meanwhile: signals of bars that closed during the break are not taken late. Bars missed: 6.» Short naps with nothing open are a journal line only; an outage that starts right after a wake is part of that wake's story, not a second alert.
- **Backups and integrity.** At every start `PRAGMA quick_check` runs on `platform`, `shot`, `paper` and `lab` (`data/*.sqlite`). A damaged one stops the start (exit code 78: a supervisor does not restart in a loop) with a message in Ukrainian and English that names the newest backup and says how to put it back **by hand**; nothing is restored automatically. A daily backup (`VACUUM INTO`, each copy checked) goes to `data/backups/auto/<date>/`; the last 7 days are kept. The candle shards and the large research database are never touched.
- **Disk space.** Amber below 5 GB or 10 % free, red below 1 GB; one journal line and alert at most every 6 hours.
- **Keep-awake and autostart** (`scripts/service.mjs`, `scripts/autostart.mjs`): see the commands below.
- **The panel**: the **Computer** chip in the top bar (green, amber, red; on a phone it appears only when something needs a look, and the *More* tab carries its dot), **Settings → Computer state** (uptime, last break, internet and each exchange, clock difference, power, keep-awake, autostart, disk, backups, database check, the recent events, the doctor and this guide), and a banner after an unexpected restart with the verdict of the reconcile. `GET /api/health/state` gives the page its booleans, times, counts and codes: **never** a key, secret, address or path. «What protects you when CandleLab is off» is printed on the Live and Paper pages.

## Commands

```sh
npm run doctor              # read-only checklist of this computer (green / amber / red, with the exact fix); --lang uk|en, --json
npm run autostart:on        # start CandleLab at log-in and after a crash; --dry-run shows what would change
npm run autostart:off       # undo it; prints what it removed
npm run autostart:status    # on / off / out of date
npm run app:up              # start CandleLab in the background (with keep-awake); app:down, app:restart, app:status
```

**Keep-awake** (started by `app:up` and by autostart, tied to the server's process id, ended with it; it changes no system setting):

| System | Command | Needs |
|---|---|---|
| macOS | `caffeinate -i -s -w <pid>` (`-i` no idle sleep, also on battery; `-s` no system sleep, **only on AC power**, see `man caffeinate`; `-w` ends with the server) | nothing |
| Linux | `systemd-inhibit --what=sleep:idle … ` waiting for the pid | `systemd-inhibit` |
| Windows | a hidden PowerShell with `SetThreadExecutionState(ES_CONTINUOUS \| ES_SYSTEM_REQUIRED)` (encoded command, no quoting problems) | PowerShell, no administrator |

It is a belt-and-braces: set the power settings above as well. It is **not** a way around the lid.

**Autostart**, per system (nothing needs administrator rights; every command prints what it changed and is idempotent):

| System | What it writes | Restart rule |
|---|---|---|
| macOS | `~/Library/LaunchAgents/com.shot.futures.plist`, loaded with `launchctl bootstrap gui/<uid>` (falls back to `launchctl load -w`) | `RunAtLoad`; `KeepAlive: SuccessfulExit=false`, `ThrottleInterval` 10 s |
| Linux | `~/.config/systemd/user/shot-futures.service`, `systemctl --user enable --now` | `Restart=on-failure`, 10 s, `RestartPreventExitStatus=78` |
| Windows | a Scheduled Task «CandleLab Futures» (at logon, runs on battery, no time limit) imported from XML with `schtasks` | restart on failure every minute |

All three run `node scripts/service.mjs run`: the supervised foreground mode. It keeps the server as a child, ends with **0** after a normal stop (`npm run app:down`, a signal) or a corrupt database (so nothing restarts in a loop) and with **1** after a crash (so the job restarts it); `npm run app:restart` relaunches the server inside the same job. **Autostart works after you log in**, not at the login screen: after a restart for an update CandleLab waits for you (Linux: `loginctl enable-linger $USER` once removes that). `autostart:off` stops a CandleLab that was running under it: start it again with `npm run app:up`; the exchange-side stops stay.

## Did paper miss a trade? (audit of 21 October 2026)

`npx tsx scripts/paper_audit.ts [--hours 26]` answers it from the local candles, read-only (no network, no keys, the app is not touched, the database is opened read-only): for every exchange with paper on, the saved strategies enabled there are run through the lab's engine over the candles and the entries it finds in the window are laid beside the paper trades the app really opened (matched within ten minutes). An entry only the engine has is a candidate for a missed signal; an entry only paper has is listed too; an exchange whose candles end before the window is said to need a top-up first (**top the candles up before the audit**, the audit cannot see what the store does not hold). The engine is a proxy of paper (PARITY.md), so a candidate is checked against its reason before anything is called missed.

The first run (26 hours, 21 Oct 2026, after a day of deploys that each stopped the app for about a second and no stop in the last 12 hours): Binance, Bybit, Gate, Bitget and MEXC matched the engine entry for entry. The one candidate was the second Binance strategy on JCTUSDT at 02:30 UTC: paper had refused it with the visible refusal «На JCTUSDT уже є позиція або ордери» (one position per symbol, as on Binance itself, `server/broker/plan.ts`), because the first strategy had just opened the same token; that is the rule, not a loss of the signal, so nothing was backfilled. OKX could not be audited: its top-up had failed on the stored names `AUSDT … WUSDT` (the downloader's pattern wanted two letters of base; fixed the same day), so its candles still end on 14 Oct.

## The dead-man's switch (optional)

If the laptop is off, asleep or offline, nothing inside CandleLab can tell you. A free outside service can: it expects a signal every minute and alerts you when the signals **stop**.

1. Create a free account on **healthchecks.io**.
2. *Add Check*: **Period 1 minute, Grace Time 5 minutes**.
3. *Integrations*: add email or Telegram.
4. Copy the **Ping URL** (`https://hc-ping.com/…`).
5. Add `HEARTBEAT_URL=<the address>` to `.env` and run `npm run app:restart`.

CandleLab then sends a plain **GET** to that address every minute while it is healthy (its own run record can be written). **Nothing else is sent**: no positions, no keys, no body, no identifiers. It is still a third-party service: it sees that you use CandleLab and your IP address. The address is a secret (anyone who knows it can send signals in your place): CandleLab never logs it, never shows it, and the app only says whether it is set and when the last ping worked. Off when the line is empty.

## Honest limits

- **A laptop is not a server.** It sleeps, it gets hot, it is carried around, its cables and Wi-Fi fail. For serious live use run CandleLab on a small always-on computer (a mini PC, a Mac mini) or a VPS. The phone control (remote mode, docs/MOBILE.md) works with such a computer the same way.
- Without CandleLab only the exchange-side stop and target work. Everything above is about getting CandleLab back quickly and **honestly**: it says what it missed instead of pretending.
- Reconcile after a wake reads the exchange; it does not decide anything new. A time exit that came due while the computer slept is made at market at once; that is the rule of the plan, applied late.

## Not verified

Run on one MacBook only in the sandbox, with fakes, and by reading real `pmset` output. Everything below needs a real machine, a real sleep or a real power cut:

1. **The sleep detector on real hardware.** The two-clock rule assumes the monotonic clock of macOS and Linux does not advance in sleep (libuv uses `mach_absolute_time` / `CLOCK_MONOTONIC`) and the wall clock does. The tests inject both clocks; I did not sleep the machine. On Windows the monotonic clock may count sleep; then a sleep shows up as a *stall* (a timer more than a minute late on both clocks) and recovery still runs.
2. **A real power cut or forced shutdown**: simulated by writing an unclean run record.
3. **`caffeinate -i -s` and a closed lid** without an external display (Apple silicon, any macOS): not verified; the guide says so.
4. **The Windows and Linux keepers and autostart** were never run: the PowerShell script, `schtasks /Create /XML` (UTF-16 file, hidden window, restart on failure) and the systemd user unit are tested only as generated text and recorded commands. Autostart on macOS was run only with `--dry-run`. No `launchctl`, `systemctl` or `schtasks` was run for real, by design.
5. **The doctor on Windows 11 and Ubuntu**: the parsers are tested on outputs written from the documented shapes (including a Ukrainian-labelled `powercfg`), not captured there. macOS is captured from macOS 26.5 (`pmset -g`, `-g custom`, `-g batt`, `-g assertions`, `-g sched`); the Sonoma and Sequoia battery samples are the same command's documented shape.
6. **The reconcile after a wake against a real exchange**: tested with the fake exchanges of both live modules (an open trade, a silent exchange, an overdue time exit, no overlap with the 5-second pass).
7. **Paper gap evaluation against real klines**: tested with injected candles; the real REST calls (`/fapi/v1/klines` with `startTime`/`endTime`, Bybit `/v5/market/kline`) were not exercised.
8. **Delivery of the summary alert** to ntfy/Telegram: it uses the existing alert service, which was not changed.

## Follow-up (not done here)

- **Paper:** replay the missed minute candles **in order** through the staged-exit model (today the gap is one range: stop first on a tie, so a staged trade that would have taken a partial profit before the stop is judged conservatively); fetch the funding history of the gap (today the current rate is used for a print that fell in it).
- **AI approaches** (Smart Money, Freestyle): their cadence timers and entries are not wired to the floor; their paper positions are covered by the price guard.
- **Scanner:** its own price socket reconnects only through its 30 s watchdog (it was verified to fire after a simulated sleep).
- A guided **restore** command for the backups (deliberately absent: restoring is a human decision).

## Why CandleLab can lose its files (macOS) and what keeps it up (22 October 2026)

**What happened (21 Oct 2026).** From about 12:45 to 16:09 UTC the running app could not open any NEW file in its data folder (`EPERM`): files it already held (the databases) kept working, so paper kept trading, but the candle store looked empty («no candles»), the pages answered with a raw error, the run record, the backups and the follower could not write, and the health check later called it «a crash, last sign of life 3 h 21 min ago». The cause is macOS: the project lives in `~/Documents`, a protected folder, and a process started from another app (an assistant, a terminal) is allowed in only on that app's behalf; when that app is closed, updated or restarted the grant goes away while the process lives on. A restart from a new session cured it for the new process only.

**What is built (all of it works without a supervisor unless said):**
- **It is seen and said.** A look at the data folder every 5 minutes, and every 10 seconds while the run record cannot be written: the journal, the banner and an alert say «CandleLab втратив доступ до папки даних» and when it is back.
- **The pages still open.** The built client is kept in memory and served ONLY when the disk refuses (the disk is always read first, so a new build shows at once): the app loads with its banner instead of a JSON error (`server/clientRoutes.ts`).
- **The last sign of life is also kept in the database** (`health.alive`, every 10 s), whose files stay writable: a stall like this is no longer reported as hours of downtime (`RunState` `extraAlive`).
- **It cures itself under an autostart supervisor.** If the access is not back within 3 minutes and the app runs under launchd or systemd (`SHOT_SUPERVISOR`, set by the generated plist and unit; run `npm run autostart:on` again to update an older one), it ends itself with code 75 and the supervisor starts a fresh process: that one is attributed to the job, not to the app that started the old one, so the folder opens again (macOS asks once to let «node» into Documents; allow it). Without a supervisor nothing restarts the app, so it stays up and says what to do.
- **The doctor says where the risk is** (`npm run doctor`, the Computer panel): the data folder in Documents, Desktop, Downloads or iCloud Drive without autostart is amber, with autostart a note.
- **A crashed app is started again by the follower** (`npm run follow:on`; `scripts/follow.mjs` guard): three looks (a minute apart) without an answer, at most 3 starts in half an hour, nothing when it was stopped on purpose (`app:down` removes the service file) or runs under a supervisor. It cannot cure the lost access above (the new process would inherit it).
- **Deploys avoid the entry window.** A deploy that restarts the server waits while a bar has just closed (the first 4½ minutes after :00, :15, :30, :45): paper looks for entries once per bar, and a signal of a bar that closed while the app was down is never taken late (36 restarts in a week cost entries). A browser-only deploy goes in at any time.

**The durable fix is not to depend on another app at all:** `npm run autostart:on` (then allow «node» once), or move the CandleLab folder out of Documents (for example to `~/CandleLab`).
