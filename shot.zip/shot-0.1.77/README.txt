CandleLab 0.1.77
================

English
-------
macOS:   double-click "Install CandleLab.command"   (if macOS objects, right-click it, choose Open, then Open)
Windows: double-click "Install CandleLab.cmd"
Linux:   open a terminal in this folder and run:  sh install.sh --from-dir "$PWD"
Nothing else needs to be installed first. The installer puts CandleLab in ~/SHOT (macOS, Linux) or %LOCALAPPDATA%\SHOT (Windows), starts it and opens your browser.
Real-money trading is off until you switch it on yourself. To update or remove CandleLab see the docs/ folder (DISTRIBUTION.md); "sh install.sh --uninstall" keeps your data.

Українською
-----------
macOS:   двічі клацніть "Install CandleLab.command"   (якщо macOS заперечує: правий клік, Відкрити, ще раз Відкрити)
Windows: двічі клацніть "Install CandleLab.cmd"
Linux:   відкрийте термінал у цій папці й виконайте:  sh install.sh --from-dir "$PWD"
Нічого ставити заздалегідь не треба. Інсталятор кладе CandleLab у ~/SHOT (macOS, Linux) або %LOCALAPPDATA%\SHOT (Windows), запускає його й відкриває браузер.
Торгівля реальними грошима вимкнена, доки ви самі її не ввімкнете.
