// Starts CandleLab by itself after you log in, and restarts it after a crash (docs/LAPTOP.md). One command, three systems, each undoable:
//   node scripts/autostart.mjs on|off|status [--dry-run] [--lang uk|en]       (npm run autostart:on | autostart:off | autostart:status)
// macOS: a LaunchAgent in ~/Library/LaunchAgents · Linux: a systemd USER service · Windows: a Scheduled Task at logon. Nothing needs administrator rights, nothing outside the user's own
// folders is written, and every command prints exactly what it changed. The job runs `node scripts/service.mjs run` (the supervised foreground mode of the service manager).
import { execFile } from 'node:child_process';
import nodeFs from 'node:fs';
import { homedir, tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { amsg } from './lib/autostartMessages.mjs';
import { envValue } from './lib/env.mjs';
import { pickLang } from './lib/messages.mjs';
import { resolvePort } from './service.mjs';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
/** The names written on the three systems; server/health/keepAwake.ts has the same three (server/health/autostart.test.ts checks they agree). */
export const LABEL = 'com.shot.futures', UNIT = 'shot-futures.service', TASK = 'CandleLab Futures';

const xml = text => String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;');

/** A path of a version manager changes with every Node upgrade. */
export const versionManagerPath = nodePath => /[\\/]\.(?:nvm|fnm|volta|asdf|nodenv)[\\/]|[\\/]fnm_multishells[\\/]|[\\/]nvm4w[\\/]|[\\/]\.local[\\/]share[\\/]fnm[\\/]/i.test(nodePath);

/** The LaunchAgent: runs the supervised mode at login, restarts it only after a crash (not after a normal stop), at most every 10 s, with the normal priority of an interactive program. */
export function plistContent({ nodePath, root, home = homedir() }) {
  const path = ['/opt/homebrew/bin', '/usr/local/bin', '/usr/bin', '/bin', '/usr/sbin', '/sbin', dirname(nodePath)].filter((p, i, all) => all.indexOf(p) === i).join(':');
  const log = join(root, 'data', 'autostart.log');
  return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>${LABEL}</string>
  <key>ProgramArguments</key>
  <array>
    <string>${xml(nodePath)}</string>
    <string>${xml(join(root, 'scripts', 'service.mjs'))}</string>
    <string>run</string>
  </array>
  <key>WorkingDirectory</key>
  <string>${xml(root)}</string>
  <key>RunAtLoad</key>
  <true/>
  <key>KeepAlive</key>
  <dict>
    <key>SuccessfulExit</key>
    <false/>
  </dict>
  <key>ThrottleInterval</key>
  <integer>10</integer>
  <key>ProcessType</key>
  <string>Interactive</string>
  <key>EnvironmentVariables</key>
  <dict>
    <key>PATH</key>
    <string>${xml(path)}</string>
    <key>HOME</key>
    <string>${xml(home)}</string>
    <key>SHOT_SUPERVISOR</key>
    <string>launchd</string>
  </dict>
  <key>StandardOutPath</key>
  <string>${xml(log)}</string>
  <key>StandardErrorPath</key>
  <string>${xml(log)}</string>
</dict>
</plist>
`;
}

/** The systemd USER unit: restart after a crash after 10 s, never after exit code 0 or 78 (a stop; a corrupt database), a 30-second grace for the orderly stop. */
export function unitContent({ nodePath, root }) {
  const q = v => (/[\s"\\]/.test(v) ? `"${v.replace(/(["\\])/g, '\\$1')}"` : v);
  return `[Unit]
Description=CandleLab Futures (local trading research app)

[Service]
Type=simple
WorkingDirectory=${root}
ExecStart=${q(nodePath)} ${q(join(root, 'scripts', 'service.mjs'))} run
Environment=SHOT_SUPERVISOR=systemd
Restart=on-failure
RestartSec=10
RestartPreventExitStatus=78
KillSignal=SIGTERM
TimeoutStopSec=30

[Install]
WantedBy=default.target
`;
}

/** The Task Scheduler task: at logon of this user, even on battery (a laptop), restarted every minute after a failure, never stopped for running long. */
export function taskXml({ nodePath, root, user }) {
  const script = join(root, 'scripts', 'service.mjs');
  const command = `& '${nodePath.replace(/'/g, "''")}' '${script.replace(/'/g, "''")}' run`;
  return `<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.4" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo>
    <Description>CandleLab Futures: starts the local trading research app at logon and restarts it after a crash.</Description>
  </RegistrationInfo>
  <Triggers>
    <LogonTrigger>
      <Enabled>true</Enabled>${user ? `\n      <UserId>${xml(user)}</UserId>` : ''}
    </LogonTrigger>
  </Triggers>
  <Principals>
    <Principal id="Author">${user ? `\n      <UserId>${xml(user)}</UserId>` : ''}
      <LogonType>InteractiveToken</LogonType>
      <RunLevel>LeastPrivilege</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <AllowHardTerminate>true</AllowHardTerminate>
    <StartWhenAvailable>true</StartWhenAvailable>
    <RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable>
    <AllowStartOnDemand>true</AllowStartOnDemand>
    <Enabled>true</Enabled>
    <Hidden>false</Hidden>
    <RunOnlyIfIdle>false</RunOnlyIfIdle>
    <WakeToRun>false</WakeToRun>
    <ExecutionTimeLimit>PT0S</ExecutionTimeLimit>
    <Priority>7</Priority>
    <RestartOnFailure>
      <Interval>PT1M</Interval>
      <Count>999</Count>
    </RestartOnFailure>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>powershell.exe</Command>
      <Arguments>-NoProfile -WindowStyle Hidden -Command "${xml(command)}"</Arguments>
      <WorkingDirectory>${xml(root)}</WorkingDirectory>
    </Exec>
  </Actions>
</Task>
`;
}

/** Runs a command; never throws: { code, stdout, stderr }. */
export const realExec = (file, args) => new Promise(resolveRun => {
  try {
    execFile(file, args, { timeout: 30_000, windowsHide: true, encoding: 'utf8' }, (error, stdout, stderr) => resolveRun({ code: error ? (typeof error.code === 'number' ? error.code : 1) : 0, stdout: String(stdout ?? ''), stderr: String(stderr ?? '') }));
  } catch (error) { resolveRun({ code: 1, stdout: '', stderr: String(error?.message ?? error) }); }
});

/** Builds the three commands. Everything that touches the outside world is replaceable (tests inject a fake file system and a recording `exec`; they never touch the real home or the real service). */
export function createAutostart(overrides = {}) {
  const d = {
    fs: nodeFs, exec: realExec, platform: process.platform, home: homedir(), uid: typeof process.getuid === 'function' ? process.getuid() : 0, nodePath: process.execPath, root: ROOT,
    user: process.env.USERDOMAIN && process.env.USERNAME ? `${process.env.USERDOMAIN}\\${process.env.USERNAME}` : process.env.USERNAME ?? '', tmp: tmpdir(), log: console.log, lang: pickLang(), dryRun: false, env: process.env,
    /** True when CandleLab already answers on its port (the new job then leaves it alone). */
    shotRunning: async () => {
      try {
        const envText = (() => { try { return nodeFs.readFileSync(join(overrides.root ?? ROOT, '.env'), 'utf8'); } catch { return ''; } })();
        const port = resolvePort({ env: process.env, envFileText: envText || '' });
        void envValue;
        const response = await fetch(`http://127.0.0.1:${port}/api/health`, { signal: AbortSignal.timeout(1500) });
        return Boolean((await response.json()).ok);
      } catch { return false; }
    },
    ...overrides,
  };
  const t = (key, vars) => amsg(d.lang, key, vars);
  const say = (key, vars) => d.log(t(key, vars));
  const entry = join(d.root, 'dist', 'server', 'index.js');
  const exists = p => { try { return d.fs.existsSync(p); } catch { return false; } };
  const read = p => { try { return d.fs.readFileSync(p, 'utf8'); } catch { return null; } };
  /** Writes a file (or says it would); false when it was already exactly this. */
  function put(path, content, mode, enc = 'utf8') {
    if (read(path) === content) { say('unchanged'); return false; }
    if (!d.dryRun) { d.fs.mkdirSync(dirname(path), { recursive: true }); d.fs.writeFileSync(path, content, enc === 'utf8' ? { mode } : { mode, encoding: enc }); }
    say('wrote', { path });
    return true;
  }
  function drop(path) { if (!exists(path)) return false; if (!d.dryRun) d.fs.unlinkSync(path); say('removed', { path }); return true; }
  /** Runs a command and prints it; `soft` ignores a failure. */
  async function sh(file, args, { soft = false } = {}) {
    const command = [file, ...args].join(' ');
    if (d.dryRun) { say('ran', { command }); return { code: 0, stdout: '', stderr: '' }; }
    const r = await d.exec(file, args);
    if (r.code === 0 || soft) { if (r.code === 0) say('ran', { command }); return r; }
    throw new Error(t('fail', { command, detail: (r.stderr || r.stdout).trim().slice(0, 300) }));
  }
  const needBuild = () => { if (!exists(entry)) throw new Error(t('nobuild')); };
  const paths = {
    plist: join(d.home, 'Library', 'LaunchAgents', `${LABEL}.plist`),
    unit: join(d.home, '.config', 'systemd', 'user', UNIT),
  };
  const desired = () => d.platform === 'darwin' ? plistContent({ nodePath: d.nodePath, root: d.root, home: d.home }) : d.platform === 'linux' ? unitContent({ nodePath: d.nodePath, root: d.root }) : null;
  const gui = `gui/${d.uid}`;

  async function on() {
    if (!['darwin', 'linux', 'win32'].includes(d.platform)) throw new Error(t('unsupported', { platform: d.platform }));
    say(d.platform === 'darwin' ? 'title.mac' : d.platform === 'linux' ? 'title.linux' : 'title.win');
    if (d.dryRun) say('dry');
    needBuild();
    if (versionManagerPath(d.nodePath)) say('on.nvm', { node: d.nodePath });
    const running = await d.shotRunning().catch(() => false);
    let changed = false;
    if (d.platform === 'darwin') {
      const loaded = (await d.exec('launchctl', ['print', `${gui}/${LABEL}`])).code === 0;
      changed = put(paths.plist, desired(), 0o644);
      if (changed || !loaded) {
        if (loaded) await sh('launchctl', ['bootout', `${gui}/${LABEL}`], { soft: true }); // the definition changed: load the new one
        const boot = await sh('launchctl', ['bootstrap', gui, paths.plist], { soft: true });
        if (boot.code !== 0) await sh('launchctl', ['load', '-w', paths.plist]); // older macOS
        changed = true;
      }
    } else if (d.platform === 'linux') {
      if ((await d.exec('systemctl', ['--user', '--version'])).code !== 0) throw new Error(t('nosystemd'));
      const enabled = (await d.exec('systemctl', ['--user', 'is-enabled', UNIT])).stdout.trim() === 'enabled';
      changed = put(paths.unit, desired(), 0o644);
      if (changed) await sh('systemctl', ['--user', 'daemon-reload']);
      if (changed || !enabled) { await sh('systemctl', ['--user', 'enable', '--now', UNIT]); changed = true; }
      const linger = await d.exec('loginctl', ['show-user', d.env.USER ?? '', '-p', 'Linger']);
      if (/Linger=yes/.test(linger.stdout)) say('on.linger.set'); else say('on.linger');
    } else {
      const queried = await d.exec('schtasks', ['/Query', '/TN', TASK]);
      const file = join(d.tmp, 'shot-futures-task.xml');
      if (!d.dryRun) d.fs.writeFileSync(file, Buffer.concat([Buffer.from([0xff, 0xfe]), Buffer.from(taskXml({ nodePath: d.nodePath, root: d.root, user: d.user }), 'utf16le')]));
      try {
        await sh('schtasks', ['/Create', '/TN', TASK, '/XML', file, '/F']);
        changed = true;
        if (queried.code !== 0 && !running) await sh('schtasks', ['/Run', '/TN', TASK], { soft: true });
      } finally { if (!d.dryRun) { try { d.fs.unlinkSync(file); } catch { /* already gone */ } } }
    }
    if (!changed) { say('already'); return { changed: false }; }
    say(d.platform === 'darwin' ? 'on.done.mac' : d.platform === 'linux' ? 'on.done.linux' : 'on.done.win');
    say('on.login');
    if (running) say('on.running');
    return { changed: true };
  }

  async function off() {
    if (!['darwin', 'linux', 'win32'].includes(d.platform)) throw new Error(t('unsupported', { platform: d.platform }));
    say(d.platform === 'darwin' ? 'title.mac' : d.platform === 'linux' ? 'title.linux' : 'title.win');
    if (d.dryRun) say('dry');
    let did = false;
    if (d.platform === 'darwin') {
      const loaded = (await d.exec('launchctl', ['print', `${gui}/${LABEL}`])).code === 0;
      if (loaded) { await sh('launchctl', ['bootout', `${gui}/${LABEL}`], { soft: true }); did = true; }
      did = drop(paths.plist) || did;
    } else if (d.platform === 'linux') {
      const had = exists(paths.unit);
      if (had) {
        await sh('systemctl', ['--user', 'disable', '--now', UNIT], { soft: true });
        drop(paths.unit);
        await sh('systemctl', ['--user', 'daemon-reload'], { soft: true });
        did = true;
      }
    } else {
      const queried = await d.exec('schtasks', ['/Query', '/TN', TASK]);
      if (queried.code === 0) { await sh('schtasks', ['/End', '/TN', TASK], { soft: true }); await sh('schtasks', ['/Delete', '/TN', TASK, '/F']); did = true; }
    }
    if (!did) { say('off.none'); return { changed: false }; }
    say('off.done'); say('off.stopped');
    return { changed: true };
  }

  async function status() {
    if (!['darwin', 'linux', 'win32'].includes(d.platform)) { say('unsupported', { platform: d.platform }); return { enabled: null }; }
    let enabled = false, loaded = null, upToDate = null, file = null, how = '';
    if (d.platform === 'darwin') {
      file = paths.plist; const text = read(file);
      loaded = (await d.exec('launchctl', ['print', `${gui}/${LABEL}`])).code === 0; upToDate = text === null ? null : text === desired(); enabled = text !== null && loaded; how = 'LaunchAgent';
      if (text !== null && !loaded) { say('status.off'); say('status.file', { path: file }); say('status.notloaded'); return { enabled: false, loaded, upToDate, file }; }
    } else if (d.platform === 'linux') {
      file = paths.unit; const text = read(file);
      loaded = (await d.exec('systemctl', ['--user', 'is-enabled', UNIT])).stdout.trim() === 'enabled'; upToDate = text === null ? null : text === desired(); enabled = text !== null && loaded; how = 'systemd --user';
    } else {
      enabled = (await d.exec('schtasks', ['/Query', '/TN', TASK])).code === 0; loaded = enabled; how = 'Task Scheduler';
    }
    if (!enabled) { say('status.off'); return { enabled: false, loaded, upToDate, file }; }
    say('status.on', { how });
    if (file) say('status.file', { path: file });
    if (upToDate === false) say('status.outdated');
    return { enabled: true, loaded, upToDate, file };
  }

  return { on, off, status, paths };
}

export function parseArgs(argv) {
  const out = { command: 'status', dryRun: false, lang: undefined };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--dry-run') out.dryRun = true;
    else if (a === '--lang') out.lang = argv[++i];
    else if (a.startsWith('--lang=')) out.lang = a.slice(7);
    else if (!a.startsWith('-')) out.command = a;
  }
  return out;
}

export async function main(argv = process.argv.slice(2), overrides = {}) {
  const { command, dryRun, lang } = parseArgs(argv);
  if (!['on', 'off', 'status'].includes(command)) throw new Error('Use on, off or status (add --dry-run to see what would change).');
  const base = { dryRun, ...(lang === 'uk' || lang === 'en' ? { lang } : {}), ...overrides };
  const a = createAutostart(base);
  await a[command]();
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().catch(error => { console.error(`Error: ${error instanceof Error ? error.message : String(error)}`); process.exit(1); });
}
