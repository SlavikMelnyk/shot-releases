# Staged exits: scale-out, a part at the first target, breakeven, trailing

Added 13 October 2026 at the owner's request: *«До live недоступна: Частковий вихід, безубиток і trailing-стоп поки що лише в тесті … make sure this is accessible for live and this strategy can work live fully».* The Strategy Lab can test four things that a plain «one stop, one target» exit cannot do:

| Exit | Parameter | Meaning |
| --- | --- | --- |
| Scale-out | `partials[]` (`fallPct`, `closePct`) | A fall of `fallPct` % from the entry closes `closePct` % of the **initial** position (a rise for a long). Up to three levels. |
| Part at the first target | `firstTargetClosePct` + `secondTarget` (`none` / `base` / `percent`) | The nearer of the first and the second target closes the share; the deeper one the rest. A second target that is not below `entry·0.997` is ignored and the rest rides. |
| Breakeven | `breakevenAfterPartial` | After the first take-profit has filled, an extra stop at the entry price protects the rest. |
| Trailing | `trailingPct`, `trailingActivatePct` | Once the price has moved `trailingActivatePct` % in favour, a stop follows `trailingPct` % behind the best price. |

**Step 1 (done): the pure model and paper trading.** Paper executes all four. **Step 2 (done, 13 October 2026): the Binance live executor** maps the model onto Binance conditional orders (section «Binance live» below); `LIVE_STAGED_EXITS.binance` is on, nothing in it has run against a real exchange, and arming stays the owner's typed `REAL MONEY`. **Step 3 (done, 13 October 2026): the Bybit live executor** (section «Bybit live» below) maps it onto reduce-only conditional orders next to the position's own stop-loss and take-profit, with a trailing stop that CandleLab places and moves; `LIVE_STAGED_EXITS.bybit` is on, nothing in it has run against a real or test Bybit account either, and `liveBlockers` consults the flag of the strategy's own exchange. Nothing here is evidence that any staged exit earns money: the lab's own research found exits do not add return ([SHORT_STRATEGIES.md](SHORT_STRATEGIES.md)).

## The model (`shared/exits.ts`)

Pure: no I/O, no clock, no randomness. The reference semantics are the backtest's (`simulateTrade`, `server/lab/trade.ts`); direction-aware through `side` (only shorts of the spike family exist today).

| Export | What it is |
| --- | --- |
| `ExitSpec` | What a strategy asks for, in percentages. `exitSpecOf(params)` compiles it from the saved parameters (or returns `null`: one stop and one target is enough); `compilePlan` stores it in the new optional field `SpikePlan.exits`. A plan without `exits` behaves exactly as before. |
| `ExitPlan` | The spec resolved against ONE trade: absolute prices (entry, protective stop, the scale-out levels, the part at the first target, the final target). `resolveExits(spec, {entry, stop, target, base})`. Stored with the trade (paper: `meta.exits`) and never changed. |
| `ExitSplit` | The plan cut into whole instrument steps: the planned quantity of each take-profit and the rest (`splitQuantities(plan, initialQty, facts)`). |
| `ExitStage` | How many take-profits have filled, derived from the quantity still open ALONE (`stageOf(split, openQty, step)`, or `stageFor(plan, initialQty, openQty, facts)` straight from the plan; `desiredOrders(...).stage` carries it too). |
| `ExitOrders` | The DECLARATIVE set of orders that must exist on an exchange for a position at that stage: `desiredOrders(plan, initialQty, openQty, facts)`. Idempotent. |
| `reconcileExitOrders(desired, placed)` | `{place, keep, cancel}`: what to place and what to cancel to get from the orders that exist to the desired ones. |
| `applyRange(...)` | A simulator of those orders against the price range seen since the last check (paper trading, the parity tests, and the oracle for a live executor's tests). |
| `LIVE_STAGED_EXITS` | Per exchange, whether its live executor implements the model. Each live agent flips its own flag (and removes nothing else) when its executor and tests are done. |

### Invariants (each has a test in `shared/exits.test.ts`)

1. **The protective stop is never removed or moved while any quantity is open.** It is in every desired set, at the same price, and it closes the whole position (`closeAll`). Breakeven and trailing are ADDITIONAL, tighter stops; the tighter one fires first (the backtest's `min(stop, …)`). So «no position without a stop» holds at every instant, including between two stages.
2. **Stage = f(plan, initial quantity, open quantity).** Nothing else is stored, so a restart re-derives the same orders. (The trailing stop's anchor, the best price since the entry, is exchange-side in live; paper stores it in `meta.exitState`.)
3. **`desiredOrders` is pure and idempotent**; the identity of an order (`orderKey`) does not change when nothing it depends on changed, so a reconcile loop that runs every second places and cancels nothing.
4. **Quantities are whole steps and at least `minQty`.** A share that rounds to nothing, or to less than the minimum, is merged into the NEXT level, and what is left after the last level goes to the final target. If the quantity that would remain after all levels is below the minimum, the deepest levels are merged back into the rest.
5. **Everything is reduce-only.** No order of the set can open or enlarge a position.

### The orders of every stage

A short with entry 100, protective stop 108, target 90, scale-out at −3 % (30 %) and −6 % (30 %), breakeven, trailing 4 % from −5 %; initial quantity 1000:

```
price ▲   (short: profit is DOWN)
 108 ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─  stop                 closeAll, same in every stage
 100 ─ entry ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─  breakeven (stage ≥ 1) closeAll, at the entry
  97 ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─  tp1  30 % → qty 300
  95 ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─  trailing activation (callback 4 %, qty = open)
  94 ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─  tp2  30 % → qty 300
  90 ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─  target               closeAll (qty 400 = the rest)

 stage 0   open 1000   stop · trailing(1000) · tp1(300) · tp2(300) · target(400)
 stage 1   open  700   stop · BREAKEVEN · trailing(700) · tp2(300) · target(400)            ← tp1 filled
 stage 2   open  400   stop · breakeven · trailing(400) · target(400)                       ← tp2 filled
 flat      open    0   (nothing: cancel whatever is left)

 time ─────────────────────────────────────────────────────────────────────────────────▶
   entry        tp1 fills           tp2 fills        target / stop / breakeven / trailing / time limit
   [stage 0]    [stage 1]           [stage 2]        [flat]
```

Rules behind the figure:

- `stop` = `{kind: 'stop', closeAll: true}`, price rounded towards the entry (a short's stop DOWN to the tick, so it can only fire earlier than asked, never later).
- `breakeven` = a stop at the entry price (rounded the same way), `closeAll`, present when the plan asks for it and at least one take-profit has filled.
- `trailing` = `{kind: 'trailing', price: ACTIVATION price, callbackPct, quantity: open}`, not `closeAll` (an exchange trailing order needs a quantity). `callbackPct` is rounded DOWN to the exchange's step (never looser than asked), raised to its minimum with an issue, and **refused** above its maximum (`issues: ['trailing-above-max']`, no trailing order: the live blocker «Trailing-стоп у live — до 10%.» keeps such a strategy from ever getting here).
- `tp1…tpN` = reduce-only take-profits, nearest first. Their planned size never changes; a partly filled one keeps its remainder (`quantity` is what is still unfilled, the key uses the planned size).
- `target` = the final target, `closeAll`, its size is the same in every stage (the rest after all take-profits). Absent when the rest rides (a part at the first target with `secondTarget: none`, or a second target that was ignored).
- A scale-out level at or beyond the final target is dropped (`plan.merged`): the final target closes the rest first.

### Order identity and the reconcile loop

`orderKey(order)` is the identity of an order: `stop:108`, `breakeven:100`, `target:90`, `tp1:97:300` (id, price, planned size) and `trailing:95:4:700` (bound to its quantity). `reconcileExitOrders(desired, placed)` compares keys:

- `place`: wanted and missing, in the desired order (the protective stop first);
- `keep`: wanted and present;
- `cancel`: present and not wanted (a filled take-profit's leftover, the trailing stop with an outdated quantity, anything unknown, a second copy). **The protective stop is never in `cancel` while the position is open**, because its key does not change; `cancel` lists everything only when the desired set is empty (the position is flat).

## Paper trading (what runs now)

**The «Власні правила» type (14 Oct 2026):** a strategy of this type, short OR LONG, carries its staged exits in `plan.exits` with its own side (`exitSpecOf(p, p.side)`), and the paper runner passes them to the broker exactly as for the spike type (no pre-spike base: a second target is a percent of the entry); the long's take-profits lie above the entry, its breakeven stop under the price, its trailing stop behind the highest high (`server/broker/paper.long.test.ts`, `server/parity/rulesParity.test.ts`; the replay on real candles in [PARITY.md](PARITY.md) §9). The live executors place shorts of the spike type only and refuse the rules type.

`SpikePaper` passes `plan.exits` and the signal's pre-spike base to `PaperBroker.open` (`OpenRequest.exits`). The broker resolves the plan against the real fill (scale-out levels and the breakeven stop are measured from the fill, as in the backtest), cuts it into the contract's own steps (`tickSize`, `stepSize`, `minQty` of Binance or Bybit; paper applies no minimum notional to reduce-only exits), and stores in the trade record:

| `meta` field | |
| --- | --- |
| `exits` | the resolved `ExitPlan` (immutable) |
| `initialQty` | the quantity at the entry |
| `exitState` | `{extreme, trailArmed}`: the best price since the entry and whether trailing is armed |
| `exitFacts` | the instrument's `tickSize`, `stepSize`, `minQty` the quantities were cut with (a check makes no network call and the stage stays derivable if the exchange changes a step later) |
| `partials[]` | one record per take-profit that filled: `{at, orderId, qty, level, price}` |
| `lastExitPrice`, `backtestReason` | on a closed trade: the final fill, and the exit reason in the backtest's word (`trailing` → `stop`) |

Every 5 s `PaperBroker.tick` evaluates the price range since the previous check: liquidation exactly as for a single-stop trade; then `applyRange` decides which orders were touched. A take-profit reduces the position with the broker's accounting (`grossRealized`, fees, margin and notional released in proportion, the quantity), a closing fill settles the rest. Facts:

- **Exit reasons** on the trade: `target`, `stop`, `breakeven`, `trailing`, `time`, `liquidation` (and `manual`/`panic`). The Paper page names them and shows «частин закрито: N» next to an open trade and the counts of breakeven and trailing exits in the plan table.
- **Prices.** `trade.exitPrice` of a trade closed in parts is the weighted price over all parts, like the backtest's; `meta.lastExitPrice` is the final fill. `stopPrice` is the protective stop, `takeProfitPrice` the final target (null when the rest rides).
- **Accounting identity** (tested): `realizedPnl = Σ (entry − part price)·qty − fees − funding paid`, funding is charged on the quantity still open, a liquidation after take-profits loses only the margin still open, and the equity (`budgetOf`) includes the profit booked by take-profits at once (not only when the rest closes; this also corrects `reduce()` for the AI approaches, whose booked partial profit had been missing from the equity until the close).
- **The pause after a stop** (`cooldownHours`) uses the backtest's word: a trailing exit counts as a stop, a breakeven exit does not (`meta.backtestReason`). Since 14 October 2026 the same real exit also ends the EVENT in `detect()` (`KnownTrade`, [PARITY.md](PARITY.md)): a trade that left on breakeven or trailing no longer keeps its token blocked until a hypothetical plain stop-and-target trade would have ended, in paper and in both live executors.
- **Restart.** The broker keeps nothing in memory: stage, orders and anchor come from the trade record; a test restarts it between two stages and compares the result with an uninterrupted run.
- **Strategies saved before this change** pick up their staged exits from the saved parameters at start-up (`StrategyLab.currentPlan`); only trades opened afterwards use them, trades already open keep their single stop and target. Trades of plans without `exits` carry no staged field and run through the old code path unchanged (a test pins the exact `meta` keys and numbers).

## Differences from the backtest

Each one is pinned by a test in `server/lab/exits.parity.test.ts` unless marked otherwise. Everything else is equal: for the scenarios of `engine.test.ts` and for about 1,270 random short and 1,010 random long paths (seeded, all staged combinations, with the scale-out levels nearer than the target) the model reports the same exit reason and the same weighted exit price (relative error ≤ 1e-6, from rounding the quantity and the price to the instrument's steps).

| # | Topic | Backtest (`simulateTrade`) | Model / paper / exchange | Pin |
| --- | --- | --- | --- | --- |
| 1 | **Granularity** | one decision per 1m candle: the stop of a minute is the one at its start, a new low moves the trailing stop for the NEXT minute | paper decides per check (about 5 s) by the same rule; an exchange per tick. A bounce of at least the callback inside one minute is invisible to the backtest and stops a trailing stop in paper and live | «the same bounce seen as two sub-minute ranges» |
| 2 | **Reason names** | no `trailing`: a trailing stop that is hit is `stop` (or `breakeven` when breakeven is armed and the trailing level is not below the entry) | `trailing` is its own reason; a trailing level equal to the entry counts as `breakeven` | «vocabulary» (mapping `backtestReason`) |
| 3 | **Levels beyond the final target** | a scale-out level deeper than the final target gets its own fill only if one minute reaches both | the level is dropped; the final target closes the rest. The model is never better than the backtest, and equal unless one minute spans both | «a scale-out level at or beyond the final target is merged» |
| 4 | **Trailing callback** | any percentage | rounded DOWN to the exchange's step (Binance 0.1 %), minimum 0.1 %, maximum 10 % (a live blocker) | «the trailing callback is rounded DOWN» |
| 5 | **Quantities** | exact shares of one unit | whole steps ≥ `minQty`; shares that do not fit are merged (invariant 4) | «quantities are whole steps» |
| 6 | **Slippage** | one `slippagePct` on every fill | paper: 0.1 % on stops, half of 0.05 % on targets and levels, 0.05 % on the time exit; an exchange: the real book | «slippage conventions» |
| 7 | **Gap fill** | a level fills at the minute's open when the open is already beyond it | paper fills a stop at the last price when it is already beyond the stop, else at the level; an exchange at the first price after the trigger | «a stop that gaps» |
| 8 | **Price rounding** | none | stops, the breakeven stop, take-profits and the trailing activation are rounded towards the entry to the tick: stops fire up to a tick earlier, take-profits fill up to a tick earlier | `shared/exits.test.ts` |
| 9 | **Levels from the fill** | stop and target come from the fill price | in paper (and live) the stop and the first target are computed from the mark price before the fill, the scale-out levels and the breakeven stop from the fill: about 0.05 % apart | not pinned (the same in the existing single-stop path) |
| 10 | **Breakeven is not free** | the exit price is the entry | the stop fires at the entry minus up to a tick and costs the stop slippage and the exit fee, so a «breakeven» exit loses a few hundredths of a percent | `paper.staged.test.ts` (numbers) |

Where they matter: 1 and 6 make paper and live slightly **worse** than the backtest for trailing stops, and 3 can only make the model worse. Nothing in the model is better than the backtest by construction.

## What a live executor must do

The specification for both live executors. **Binance is implemented** (next section; deviations from this specification are listed there, the main one: the breakeven stop is a quantity-based order on Binance, never a second close-position stop). **Bybit is implemented** (section «Bybit live»; its mapping differs from the Bybit column of the table below, which was written before the documentation was read: the stop-loss and the final target are the position's own, the take-profits and the breakeven stop are reduce-only conditional orders, and the trailing stop is such an order that CandleLab moves, because Bybit's own `trading-stop` trailing stop is not documented to leave the stop-loss alone). Its flag in `LIVE_STAGED_EXITS` (`shared/exits.ts`) was set after its tests passed; the exchange testnet run is the owner's.

### 1. At the entry

1. Resolve the plan from the real fill: `resolveExits(plan.exits, {entry: fillPrice, stop, target, base: signal.base})` and store the `ExitPlan` and the initial quantity (the filled quantity) in the live trade record. Re-derive nothing else.
2. The protective stop is placed and confirmed BEFORE the entry, exactly as today. The rest of the set is placed after the fill is known: `desiredOrders(plan, initialQty, openQty, facts)` with the exchange's `tickSize`, `stepSize` and `minQty` (leave `minNotional` out when the exchange exempts reduce-only orders; verify it).
3. Refuse the entry (before any order) if `desiredOrders(...).issues` contains `trailing-above-max` or `no-stop`.

### 2. Mapping a declared order to an exchange order

| Declared | Binance USDⓈ-M (to verify on testnet) | Bybit linear (to verify on testnet) |
| --- | --- | --- |
| `stop` (`closeAll`) | the existing protective `STOP_MARKET` with `closePosition=true`, reduce-only | the existing position-level stop (Full mode) |
| `breakeven` (`closeAll`) | a second `STOP_MARKET` `closePosition=true` at the entry price. If the exchange refuses several close-position orders, use a reduce-only `STOP_MARKET` with `quantity = open` and replace it (place, then cancel) when a take-profit fills | a reduce-only conditional market order (`triggerPrice`, `reduceOnly`) so that the original position stop stays untouched. If only the single position-level stop slot is available, **amend it atomically** to the tighter of {original, breakeven}; the invariant then reads «the slot always holds a stop at least as tight as the original, changed in one call, never absent» |
| `tp1…tpN` (`partial`) | reduce-only `TAKE_PROFIT_MARKET` (or a reduce-only limit) with `quantity` | a reduce-only limit or conditional order with `qty` |
| `target` (`closeAll`) | the existing `TAKE_PROFIT_MARKET` with `closePosition=true` | the existing position-level take-profit, or a reduce-only conditional order |
| `trailing` | reduce-only `TRAILING_STOP_MARKET`, `quantity` = open, `activationPrice` = `price`, `callbackRate` = `callbackPct` (0.1–10, step 0.1) | the position-level trailing stop (a price distance = the extreme times `callbackPct`), `activePrice` = `price` |

Whatever the mapping, the set of orders on the exchange must close the same quantities at the same trigger prices as `desiredOrders`. Conditional orders must use the same trigger source as the protective stop (mark price today).

### 3. The reconcile loop (every pass, and at once after any fill event)

```
position = exchange.position(symbol)                       # the truth about the open quantity
if position is flat:
    cancel every order of this trade (clientOrderId prefix); close the trade record; reason = which declared order filled
    return
want  = desiredOrders(trade.exits, trade.initialQty, position.qty, facts)      # nothing else is read
have  = our open orders on the exchange, as {key, ref}    # recompute id = clientId(tradeId, key) for each wanted order and match it to the exchange's list; unknown ids of our prefix are stale
diff  = reconcileExitOrders(want.orders, have)
for o in diff.place:                                       # the protective stop first
    place(o, clientOrderId = clientId(trade.id, o.key))    # a «duplicate id» answer means «already there»
    confirm by query; if the PROTECTIVE stop cannot be confirmed: close the position at market, disarm entries (as today)
if every placement was confirmed:
    for c in diff.cancel: cancel(c.ref)                    # «unknown order» / «already filled» are fine
record trade.stage = want.stage.filled, the keys placed, a journal line per change
```

Properties this gives, all required of the executor: **place missing, cancel stale, and never cancel before the replacement is confirmed**, so there is no window without a stop; **restart-safe** (nothing but the trade record, the exchange's position and its open orders is read); **idempotent** (client order ids are `hash(tradeId + key)`, at most 36 characters on Binance).

### 4. Edge cases the executor owns

- **A stop that would trigger at once.** Placing the breakeven stop (or a trailing order whose activation price the market has already passed) can be refused as «would immediately trigger»: for a stop this means the price is already beyond it, so close the rest at market now with the reason `breakeven`; for the trailing activation place the order without an activation price (it trails from now; document it in the trade record).
- **A take-profit that fills partly** keeps its order and key; do nothing until it is filled or the position changes.
- **Several take-profits filled by one gap**: the position quantity says so; place whatever the new stage asks for.
- **The reason of an exit** comes from the order that filled: `stop`→`stop`, `breakeven`→`breakeven`, `trailing`→`trailing`, `target`→`target`; the executor's own market close at the deadline is `time`; a flat position that no known order closed is `external`. Use `backtestReason(reason)` for the pause after a stop (a trailing exit pauses the token like a stop, as in the backtest).
- **The time limit** is not an order: at the deadline cancel nothing first, send a reduce-only market close for the open quantity (as today), then cancel what is left once the position is flat.
- **Funding, fees and P&L** come from the exchange as today; the weighted exit price of a trade closed in parts is Σ(fill quantity × price) / initial quantity.
- **Panic / manual close**: unchanged: close the position reduce-only, then cancel the set.
- **Reduce-only behaviour when the position shrinks**: the quantity-bound orders (`trailing`, take-profits) must not exceed the open quantity; the model replaces the trailing order at every stage change (its key contains the quantity). Confirm on the testnet what the exchange does with an old reduce-only order that is larger than the position, and keep the replacement order «place, then cancel».

### 5. Tests a live executor should have

- **An oracle**: drive `applyRange` with a price path as the fake exchange's matching engine and compare the executor's orders and fills stage by stage (the pattern of `server/lab/exits.parity.test.ts` and `server/broker/paper.staged.test.ts`).
- **Reconcile**: from every stage, with every order lost, duplicated or stale, the next pass reaches `desiredOrders`, never cancels the protective stop and places the stop first.
- **Restart** between any two passes: the same orders afterwards.
- **Every refusal**: trailing above the maximum, no stop, a stop that cannot be confirmed, a take-profit rejected for size.

## Binance live (13 October 2026)

Implemented in `server/trading/spike/staged.ts` (the executor), `server/trading/spike/trader.ts` (the hooks), `server/binance/client.ts` (typed methods), `shared/stagedLive.ts` (the record stored in `LiveTrade.staged`), and the Live page (`src/components/live/*`). Test support: `server/trading/spike/fakeExchange.ts` (a small matching engine with Binance's documented trigger and reduce-only rules, injected faults, and a check of the stop invariant at every request and every price step) and `stagedHarness.ts`. **No order, signed request or key was used to build or test it**; every test runs the real `SpikeTrader` and `BinanceClient` over the fake.

### The order sequence

| Moment | What is on Binance, in the order it is placed |
| --- | --- |
| Entry (unchanged) | isolated/cross + leverage → **protective `STOP_MARKET` `closePosition`, confirmed by `clientAlgoId`** → `MARKET` short → stop re-checked. A plan with `exits` is refused before any order if its trailing stop is above 10 % or it has no stop. |
| Right after the fill | the plan is resolved against the REAL fill and stored in the same write that marks the trade OPEN (`LiveTrade.staged`). Then one reconcile pass places, in this order: the **final target** (`TAKE_PROFIT_MARKET` `closePosition`, as before; absent when the rest rides), the **trailing stop**, the **take-profits** nearest first. Each is confirmed by its id. |
| Stage 0 | stop · target · trailing(initial) · tp1 … tpN |
| A take-profit has filled | the next pass (at once: the quantity changed) places the **breakeven stop** and the trailing stop for the new quantity, confirms them, and only then cancels the trailing stop with the old quantity. The protective stop is not touched. |
| Stage N | stop · target · breakeven(open) · trailing(open) · the take-profits not filled yet |
| Flat | the trader's `finish` reads the exit reason from the orders that fired, cancels the stop and target (as before), then `cleanup` re-reads the position and cancels what is left of the staged set. |

Mapping to Binance (`POST /fapi/v1/algoOrder`, `algoType=CONDITIONAL`; all verified against the public documentation unless the last column says otherwise):

| Declared | Type and parameters | `workingType` | Note |
| --- | --- | --- | --- |
| `stop` | `STOP_MARKET` `closePosition=true` (existing) | `MARK_PRICE` | never placed, replaced or cancelled by the staged executor while a quantity is open |
| `target` | `TAKE_PROFIT_MARKET` `closePosition=true` (existing) | `CONTRACT_PRICE` | for a plan with a second target it is the SECOND target, and the first target is a take-profit |
| `tpN` | `TAKE_PROFIT_MARKET` `quantity` `reduceOnly=true` | `CONTRACT_PRICE` | the same source as the final target (the task brief said `MARK_PRICE` «to match the existing stop/target»; the existing target is `CONTRACT_PRICE`, so the take-profits match that) |
| `breakeven` | `STOP_MARKET` `quantity` `reduceOnly=true` at the entry | `MARK_PRICE` | quantity-based on purpose: Binance accepts one close-position stop (the protective one); the order is bound to the open quantity and replaced (place, confirm, cancel) when a take-profit fills |
| `trailing` | `TRAILING_STOP_MARKET` `quantity` `reduceOnly=true` `callbackRate` (0.1–10, one decimal) `activatePrice` | `MARK_PRICE` | the parameter is `activatePrice` in the algo API (not `activationPrice`); no `activatePrice` when the strategy asks to trail from the entry, or when the market has already passed it (`-2021`) |

Client ids: the stop and target keep their ids; every other order is `shot_o_<8 hex of hash(tradeId)>_<18 hex of hash(tradeId|key)>` (34 characters; Binance allows 36, `^[\.A-Z\:/a-z0-9_-]{1,36}$`). The key is `orderKey` of the model, plus the open quantity for the breakeven stop. Placing the same key twice is the same order: before every placement the id is looked up (`NEW` = done), and after it the id is queried again, so a reply that never arrived is resolved by the confirmation and not by a second order.

### Where each invariant is enforced, and the test

| Invariant | Enforced in | Test |
| --- | --- | --- |
| A position never exists without an open exchange-side stop, at every instant | the stop is placed and confirmed before the entry (`trader.ts open`) **where Binance takes it; Binance refuses it while no position exists (-4509, measured on the practice network on 28 Oct 2026), and then the entry goes first and the stop follows within one request, or the position is closed (docs/TESTNET.md «The second cause»)**; `staged.ts`: `placeMissing` drops it from the orders to place (`kind !== 'stop'`), `pass` drops it from the orders to cancel, `cancelOne` refuses its id, `placeOne` throws if asked for it; `checkStop` reports a missing stop as `stopLost` and the trader's existing «protection lost → close and disarm» path runs | `staged.property.test.ts` (80 seeds by default; 10,000 ran clean with `STAGED_SEEDS=10000`, some of them against an exchange that counts reduce-only orders against each other or against a close: random price moves, passes, rejected / timed-out / lost-reply requests of every kind, cancellations by the owner, restarts, time jumps, outside closes, new entries; `fakeExchange.ts` asserts the stop after every request and price step, and records any cancel or re-placement of it); `staged.test.ts` «the fake exchange notices a protective stop that is cancelled…» proves the check can fail |
| The original stop is never replaced by breakeven or trailing | they are additional quantity-based reduce-only orders; they are tighter, so they fire first | `staged.test.ts` stage 1 / stage 2 (exact request sequences), the property test |
| Nothing is cancelled on a guess | a stale trailing / breakeven order is cancelled only when every wanted order of its kind stands (`stands` in `cancelReplaced`); an unreadable open-order list ends the pass without a request | «a stale order is not cancelled while its replacement is missing», «an unreadable list…» |
| Leftovers are cancelled only when flat | `cleanup` is called from `finish` and from the flat branch of `reconcile`, and re-reads the position first (`STILL_OPEN` and nothing cancelled when it is open, -1 when it cannot be read). For a staged trade `cleanup` is also the ONLY thing that cancels the protective stop and the final target after the exit (`finish` and `reconcile` do not cancel them first), so a wrong «flat» reading of the positions (an empty reply) cannot strip an open position of its stop; the trade then stays OPEN (review of 13 Oct 2026, finding 1) | «leftover orders that cannot be cancelled…», time-exit, manual close, panic, `external`, `expireOnFlat` tests; `staged.api.test.ts` (`POST /api/panic`) |
| A failure never touches the stop and is never silent | `failed` journals, alerts once (and once more when it gives up after six refusals) and backs off 10 s → 30 s → 1 min → 2 min → 5 min | «a rejected take-profit…», «gives up after six refusals», the i18n scenario |
| Idempotent | client ids; `statusOf` before and after every placement; one pass at a time per trade (`exclusive`) | «two passes at the same time…», «an order that already exists under the id is detected», «a reply lost AFTER…» |
| Restart at any point | nothing important lives in memory: the record has the resolved plan, the initial quantity and the contract rules; the stage comes from the position, the orders from `openAlgoOrders`, the ids from `shot_o_<trade>_` | the three «restart» tests, the property test (restarts) |
| Plans without `exits` are unchanged | every staged line is guarded by `plan.exits` / `trade.staged`; the record of a plain trade has no `staged` key | «keeps plans WITHOUT exits exactly as they were», the existing tests of the trader (`trader.test.ts`), unchanged except for the one that pinned the old refusal |

### Failure modes

| What fails | What happens |
| --- | --- |
| A take-profit, the trailing stop or the final target is **rejected** | journal line + one `important` alert (title «Поетапний вихід не розставлено»), the sentence is stored in `staged.problems` and shown on the Live page; retried after 10 s, 30 s, 1 min, 2 min, 5 min; after six refusals it stops until the stage changes (then it gets one more go) or the process restarts (second alert). A timeout or a rate-limit pause is not a refusal: it keeps the back-off at 5 minutes and never makes the executor give up. The position keeps the stop; a final target that cannot be placed falls back to the bot watching the mark price (the old «Take-profit не підтверджено» behaviour). |
| The reply is **lost / times out** | the order is looked up by its client id: found → placed; not found → counted as a failure and retried (the same id, so never two orders). |
| The **open-order list** cannot be read | nothing is cancelled and the staged orders wait (warning once a minute); the FINAL TARGET is still placed and confirmed by its own id (it needs no list), and falls back to the bot watching it by mark price if that fails too, so a list that stays unreadable leaves the trade with what a plain trade has. |
| The **breakeven stop would trigger at once** (`-2021`: the price is already beyond the entry) | the rest is closed with a reduce-only market order and recorded as `breakeven` (journal + alert «Безубиток: ринкове закриття»). |
| A **trailing activation price** is already behind the market (`-2021`) | the trailing stop is placed without `activatePrice` (it trails from now) and a note is stored on the trade. |
| A take-profit's level was **passed** before it could be placed (`-2021`) | not chased: reported as a problem; the stop, the target, breakeven and trailing still apply. |
| **Binance refuses the reduce-only market close** because of the extra reduce-only orders (`-2022` / `-4118`) | `releaseForClose` cancels the additional staged orders only (never the stop or the final target) and the close is retried on the next tick. |
| **Leftover orders cannot be cancelled** after the position is flat | alert, `staged.cleanup = 'pending'` on the closed trade, retried quietly every 30 s until the exchange is clean; the pre-entry check refuses a new entry on that contract while any conditional order is open. |
| The **protective stop disappears** | the existing path: disarm, close with a reduce-only order, cancel the rest (also found by the staged pass within 15 s). |
| The owner **cancels a take-profit by hand** | the stage is derived from the quantity, so a later take-profit that fires makes the stage lag by one; the executor does not place a take-profit whose order already fired, and does not get stuck (the property test found and pinned this). |
| The process **dies** at any point | next start: `OPENING` → `FAILED` (existing, press «Звірити з Binance»); `OPEN` with `staged` → the next pass re-derives and completes the set. A crash while the entry order itself is in flight leaves an `OPENING` record: after the restart it is `FAILED`, and «Звірити з Binance» puts a protected position back under management as a plain stop-only trade (the plan was never resolved), which is said in the journal of the reconcile. |

### Small sizes

Quantities are cut to the contract's market lot step and minimum by the model (`splitQuantities`). A part below one step (or the minimum) is merged into the next one; if the quantity left after all take-profits would be below the minimum, the deepest ones are merged back. `begin` stores the consequence as sentences in `staged.degraded` («При вашому розмірі (5) часткові виходи зводяться до …»), the entry journals them, and the Live page shows them on the trade; the plan list explains the rule before any trade. With every part merged the position keeps one stop and one target (plus the trailing stop, if any), and the breakeven stop is never placed because no take-profit can fill first. Reduce-only orders are exempt from the minimum notional (Binance's own message for `-4164`: «unless you choose reduce only»), so only the step and the minimum quantity matter.

### Differences from the backtest and the model that live adds

Each is in addition to the table «Differences from the backtest» above.

| # | Topic | Live |
| --- | --- | --- |
| 11 | **Trailing anchor** | Binance tracks the best price from the moment the order is placed. The model replaces the trailing stop whenever a take-profit fills (its quantity changes), so after a replacement the stop follows the best price since the replacement, not since the entry. Looser than the backtest by the distance the market moved in between, and tighter than nothing: the breakeven stop (at the entry) fires first in most cases. A note is stored on the trade. |
| 12 | **Trigger source** | stops: mark price (as the protective stop); take-profits and the final target: last price (as the existing target); the backtest uses candles of last prices. |
| 13 | **A level passed before placement** | not chased (see failure modes). |
| 14 | **Granularity** | the executor looks at the exchange every 5 s and reconciles every 15 s or at once when the open quantity changes; the orders themselves trigger on the exchange per tick. |

### Facts checked against Binance's public documentation (13 October 2026) and facts that were not

Checked (`developers.binance.com`, USDⓈ-M futures: New Algo Order, Query Algo Order, Cancel Algo Order, the error-code page, the filters page):

- `POST /fapi/v1/algoOrder`: `algoType=CONDITIONAL`; `type` includes `STOP_MARKET`, `TAKE_PROFIT_MARKET`, `TRAILING_STOP_MARKET`; `quantity` cannot be sent with `closePosition=true`; `reduceOnly` cannot be sent in Hedge Mode or with `closePosition=true`; `closePosition` is for `STOP_MARKET` / `TAKE_PROFIT_MARKET`; `priceProtect` is for those two.
- Trailing: the parameter is `activatePrice` (defaults to the latest price, respecting `workingType`), `callbackRate` min 0.1 max 10; for BUY the order tracks the lowest price after placement and triggers at that price × (1 + `callbackRate`); a trailing order that would trigger at once is refused with `-2021` and `activatePrice` must be below the latest price for BUY.
- `workingType` is `MARK_PRICE` or `CONTRACT_PRICE` (default `CONTRACT_PRICE`); `clientAlgoId` matches `^[\.A-Z\:/a-z0-9_-]{1,36}$` and must be unique among OPEN orders; Query/Cancel take `clientAlgoId`; the query reply has `algoStatus`, `actualOrderId`, `actualPrice`, `actualQty`, `triggerTime`.
- `algoStatus` values `NEW`, `TRIGGERING`, `TRIGGERED`, `FINISHED`, `CANCELED`, `REJECTED`, `EXPIRED` (the `ALGO_UPDATE` event documentation; read through a search summary): `EXPIRED` is a system cancellation, e.g. of a close-position (GTE_GTC) order after the position is closed; `REJECTED` is a matching-engine refusal at trigger time.
- Error codes: `-2021` «Order would immediately trigger», `-2022` «ReduceOnly Order is rejected» (also a conflict with existing open orders), `-4118` «ReduceOnly Order Failed. Please check your existing position and open orders», `-4164` «Order's notional must be no smaller than 5.0 (unless you choose reduce only)», `-4116` duplicated client order id (regular orders), `-4014`/`-4023` tick/step violations, `-2025` open-order limit.
- Filters: `MARKET_LOT_SIZE` applies to market orders (these are `*_MARKET` orders, so the executor cuts quantities with it, as the entry does), `(quantity − minQty) % stepSize == 0`; `MAX_NUM_ALGO_ORDERS` is a per-symbol cap on algo orders (example 100).

**Not verified without a real exchange** (the executor is written so that each of these fails safe, and the owner's testnet steps below look at each):

1. The reply shape of `GET /fapi/v1/openAlgoOrders` (the page was not available): the code needs an array whose entries carry `clientAlgoId`; `algoStatus`, when present, must be `NEW` for an entry to count as open.
2. Whether quantity-based reduce-only conditional orders count against each other or the position **at placement** (`-2022`, `-4118`). Under the strict reading the stage-0 set (trailing + take-profits larger than the position together) is refused: tested («under the strict reading…») — the take-profits are reported as problems and the position stays covered by the stop, the target and the trailing stop; no staged order can then fire, which is the safe outcome.
3. Whether open reduce-only conditional orders make a reduce-only MARKET close fail (`-2022`). The executor handles it (`releaseForClose`), but the real behaviour decides whether a time exit / panic needs the second attempt.
4. What Binance does to a reduce-only order that is larger than the position after a partial fill (adjust, cancel, reject at trigger). The executor replaces the trailing / breakeven orders at every stage; if Binance cancels them itself, the next pass places them again.
5. The error code for a second `closePosition` stop (`-4130` in practice; it is not on the error-code page) and for a duplicate `clientAlgoId` on the algo endpoint. The executor does not depend on either code: a refused placement is resolved by looking the id up.
6. That `TRAILING_STOP_MARKET` accepts `workingType=MARK_PRICE` and that `STOP_MARKET` is refused with `-2021` when the price is beyond the trigger (documented for the trailing type; assumed for the stop).
7. How soon the income rows of the last fill appear: the P&L is read once when the trade closes (as before), so a very recent last fill can be missing from `realizedPnl`; Binance's history is the truth.
8. Which lot-size filter governs the quantity of a conditional market order (the executor uses `MARKET_LOT_SIZE` like the entry, falling back to `LOT_SIZE`), and whether `minQty` is always a multiple of the step (Binance's rule is `(quantity − minQty) % stepSize == 0`; the model cuts to multiples of the step). A refusal (`-4003`/`-4004`/`-4005`/`-4023`) is a reported problem, never a risk to the stop.

## Independent safety review (13 October 2026)

A second agent read the executor adversarially, ran it against a harsher fake exchange (`FakeOptions.idsNeverReused`, `rejectOversized`, `listLimit`, and a manual partial close, `externalReduce`), added those worlds to the property test (10,000 seeds clean) and ran a mutation pass on a scratch copy (76 deliberate breakages of the executor, the trader, the client, the model and the fake; 72 are caught by the tests, and the property test alone catches the ones that strip the stop: both stop guards removed with the stop classified as stale, `releaseForClose` cancelling the stop, a lost stop ignored, no clean-up, no staged pass. The four survivors are redundant guards, where one line alone is harmless by design: the stop filter in `pass` and the refusal in `cancelOne`, the second check of a trailing stop above 10 %, and the shipped default of the Bybit switch, which the tests set explicitly.) Fixed, each with a test that fails before and passes after:

1. **A wrong «flat» reading cancelled the protective stop (HIGH, conditional).** `finish` cancelled the stop and the target on the caller's reading of the positions and only then let `cleanup` re-read them; an empty positions reply under an open position left it with no stop, no manager and the staged orders resting. Now `cleanup` proves the position flat first and is the only thing that cancels the stop and the target of a staged trade (also in «Звірити з Binance»). Plain trades keep their old path (unchanged on purpose; the same weakness exists there).
2. **A flapping trailing stop (MEDIUM).** An open quantity that is on no stage (the owner closed part by hand, a fill read in between) made the trailing order placed for it look like an unknown stale order: it was cancelled and placed again, pass after pass. Orders under the id of a wanted order are now always recognised, and the last recorded quantity counts as a stage for recognising the ids (exit reason too).
3. **No final target when the list cannot be read (MEDIUM, unverified shape).** See «Failure modes».
4. **Give-up (LOW/MEDIUM).** Timeouts and rate limits no longer count toward the six refusals; a stage change gives an order that gave up one more go; a problem is dropped once its order stands.
5. **Exit reason (LOW).** An order that triggered but filled nothing (a reduce-only order that fired after the position was flat) no longer outranks the order that closed the position, when the exchange reports `actualQty`.
6. **A closed trade could be reopened by a pass in flight (LOW, not reachable today).** The pass no longer writes its older record back when the trade is not active any more.

Still **not verifiable without an exchange** (testnet checks, in addition to the owner's checklist below): (a) that the PROTECTIVE stop still fills in full when quantity-based reduce-only orders rest next to it (trigger the stop on purpose with the whole set placed, and watch the position go flat); (b) that placing the staged set does not cancel or replace the close-position stop (the executor would notice within 15 s, close the position and disarm); (c) that `openAlgoOrders` returns every open algo order of the symbol, as an array (a silently incomplete list leaves orphan reduce-only orders after the exit and the clean-up cannot know); (d) what Binance does with a reduce-only order whose quantity exceeds the position when it triggers (rejects or clamps; the executor is safe either way, a stale trailing/breakeven order may simply not fire in the seconds before its replacement); (e) whether a client id can be used again after its order was cancelled or fired (the docs say «unique among open orders»; the executor survives the strict reading, it then cannot re-place an order the owner cancelled).

## Bybit live (13 October 2026)

Implemented in `server/bybit/staged.ts` (the executor), `server/bybit/trader.ts` (the hooks), `server/bybit/trading.ts` (typed methods `createConditional`, `cancelConditional`, `orderHistory`), `shared/stagedLive.ts` (the same record as Binance's, with three optional additions: `facts.minNotional`, `trail`, `StagedOrderView.trail`) and the Live page (`src/components/live/*`, shared with Binance; the Bybit-only English is `src/i18n/en/bybit-staged.ts`). Test support: `server/bybit/fakeExchange.ts` (extended into a small exchange: conditional orders with Bybit's documented trigger, reduce-only, duplicate-id, precision, minimum-value and order-count rules, a price engine, injected faults, and a check of the stop-loss at every request and every price step) and `stagedHarness.ts`. **No order, signed request or key was used to build or test it**; every test runs the real `BybitSpikeTrader` and `BybitTradingClient` (signing included) over the fake. `LIVE_STAGED_EXITS.bybit` is true since the tests passed; arming stays the owner's typed `REAL MONEY`, and open trades are managed whatever the flag says.

### What stands where, and why the trailing stop is a stop that CandleLab moves

| Declared | Bybit mechanism | Trigger | Note |
| --- | --- | --- | --- |
| `stop` (`closeAll`) | the position's own stop-loss, attached to the entry order (`stopLoss`, `slTriggerBy: MarkPrice`, `tpslMode: Full`, market) | mark | unchanged from the plain module. **Never placed, moved or cancelled by the staged executor**: the port it talks to has no method that could (no `trading-stop`, no `cancel-all`) |
| `target` (`closeAll`) | the position's own take-profit, attached to the entry order (`takeProfit`, `tpTriggerBy: LastPrice`, market) | last | the plan's FINAL target: the far target of a plan with a second target, resolved against the mark price before the order; after the fill the plan adopts exactly this price (`adoptTarget`). Absent when the rest rides. A missing take-profit is the old «Take-profit не підтверджено» fallback (the bot watches the mark price) |
| `tpN` (`partial`) | a reduce-only CONDITIONAL market Buy: `triggerPrice`, `triggerDirection: 2` (the price falls to it), `triggerBy: LastPrice`, `reduceOnly: true`, `closeOnTrigger: true`, `qty` | last | its own `orderLinkId`; the planned size never changes |
| `breakeven` | the same, `triggerDirection: 1` (the price rises to the entry), `MarkPrice`, `qty` = open quantity | mark | added after the first take-profit has filled; replaced (place, confirm, cancel) when a later one fills, because its key contains the quantity |
| `trailing` | the same as breakeven, `qty` = open quantity, at **best price · (1 + callback)** rounded down to the tick; **CandleLab places it once the activation price has been seen and moves it forward** | mark | see below |

**Why the trailing stop is not Bybit's own.** Bybit sets its own trailing stop with `/v5/position/trading-stop` (`trailingStop` as a price distance plus `activePrice`). That page (checked 13 October 2026) says that these parameters «create conditional orders internally», that changing only one side of a Full-mode TP/SL breaks the binding of the pair, and **does not say** whether setting `trailingStop` leaves an existing `stopLoss` alone, whether omitted fields stay unchanged, or whether a trailing stop can coexist with a stop-loss. Rule (4) of this task is that the original stop-loss cannot be touched, so `trading-stop` is not used at all (the client has no method for it; the fake records any use as a violation). The same reasoning keeps `cancel-all` out of the executor: its documentation says that without `orderFilter` it cancels every kind of order of the symbol, **TP/SL and trailing-stop orders included**, so it would strip the stop-loss of an open position; it stays what it was, the panic button's call after the position is flat. The alternative, refusing trailing for Bybit, would have made the owner's strategies with a trailing stop untradeable there; the emulation is a stop that is added (reduce-only, tighter than the stop-loss) and never replaces it.

How the emulation works (`observe`, `trailLevel`, `wantedOf`): every management tick (5 s) the lowest price since the last look is taken from the position's mark price (read just now), the feed's mark price and its range between two polls when the feed is fresh (never a stale feed: an old low would tighten the stop), and stored as `staged.trail.extreme` in the trade record (so a restart continues from it). When the extreme has touched the activation price (`staged.trail.armed`, never reset), the wanted level is `extreme · (1 + callback)` rounded down to the tick (towards the entry: it can only fire earlier); it is not placed while the position's own stop-loss is at least as tight. A stop that stands for the open quantity is kept while the ideal level is less than max(1 tick, 5 % of the callback distance) better; otherwise the new one is placed, confirmed by its id, and only then is the old one cancelled. If Bybit refuses the new stop because the market is already beyond its level (retCode 110092, a rising trigger not above the price), the rest is closed at the market at once and recorded as `trailing`, the same rule as breakeven.

### The order sequence

| Moment | What is on Bybit, in the order it is placed |
| --- | --- |
| Entry | leverage → **one market Sell that carries the stop-loss (Full, mark) and the final target (Full, last)** → the order and the position are read back and `protection()` confirms the stop-loss (unchanged: a missing, looser or beyond-liquidation stop ends in the protective close) → the plan is resolved against the REAL fill and stored in the same write that marks the trade OPEN (`LiveTrade.staged`) → one reconcile pass places the **take-profits**, nearest first, each confirmed by its id. Refused before any order: a trailing stop above 10 %, a plan with no stop. Nothing else is placed: the trailing stop waits for its activation price |
| Stage 0 | stop-loss · final target · tp1 … tpN |
| The activation price has been reached | the **trailing stop** at best·(1 + callback) for the open quantity |
| A new best price | the trailing stop is placed at the better level and confirmed, then the old one is cancelled |
| A take-profit has filled | the next pass (at once: the open quantity changed) places the **breakeven stop** and a trailing stop for the new quantity (same best price, so the same level or better), confirms them, and only then cancels the ones with the old quantity |
| Stage N | stop-loss · final target · breakeven(open) · trailing(open) · the take-profits that have not filled |
| Flat | `settle` reads the exit reason from the fill that took the last of the position, re-reads the position, and cancels what is left of the staged set (`cleanup`) |

Ids: `shotb_o_<8 hex of hash(tradeId)>_<code>_<generation>_<10 hex of hash(tradeId|key)>` (31–32 characters; Bybit allows 36 of `[A-Za-z0-9_-]`); the code is `b` breakeven, `t` trailing, `p1…p4` take-profit n. Entries are `shotb_<24 hex>`, closes `shotb_x_…`; none of the three matches another. Bybit's documentation says an `orderLinkId` «must always be unique» and does not say how long one is remembered, so the id is treated as taken for good: before a placement the id is looked up (open → done; fired → not placed again; ended → the next generation), after it the id is looked up again (up to three times, 0.4 s apart, because the order may be listed a moment after the answer), and a «duplicate» answer with the order not yet visible is a failure for now (retried later), never a second id.

### Where each invariant is enforced, and the test

| Invariant | Enforced in | Test |
| --- | --- | --- |
| A position never exists without the stop-loss the entry attached, at every instant, and it is never changed | `trading.ts`: the only creating method (`createConditional`) refuses any order that is not a reduce-only, close-on-trigger Buy under a `shotb_o_` id with no stop-loss or take-profit of its own; the only cancelling one (`cancelConditional`) refuses any other id; the executor's port has no `trading-stop` or `cancel-all`; `staged.ts: cancelOne` also refuses an id that is not this trade's; `trader.ts: manageOne` checks `protection()` on every pass before the staged pass | `staged.property.test.ts` (60 seeds by default; 5,000 ran clean with `STAGED_SEEDS=5000`: random price moves, passes, refused / dropped / lost-reply requests of every kind, cancellations by the owner, restarts, time jumps, a lagging order history, outside closes, gaps, and a directed «price crosses take-profits and the next look finds every placement refused» step, against exchanges that count reduce-only orders against each other or against a close and cancel the orders when the position is gone); the fake records a violation for a position without its stop-loss, a stop-loss that changed, a `cancel-all` while a position is open, and the property test also fails on any use of `trading-stop` or a cancel of an id that is not a staged id; `staged.test.ts` «notices a position without a stop-loss…» proves the check can fail |
| Breakeven and trailing do not replace the stop-loss | they are separate reduce-only conditional orders with their own ids | `staged.test.ts` stage 1 / stage 2 (exact request sequences), the property test |
| Nothing is cancelled on a guess | a stale order is cancelled only when every wanted order of its kind stands (`cancelReplaced`); an unreadable list ends the pass without a request; the property run audits that the last working stop-type order of an open position is never cancelled (except to release a refused close) | «nothing is cancelled on a guess» (three scenarios: a refused replacement, a trailing stop that cannot be moved, a lookup that fails); sabotaging `cancelReplaced` fails these and the property test |
| Leftovers are cancelled only when flat | `cleanup` is called from `settle` and from the flat branch of `reconcile`; it re-reads the position first (returns -1 and cancels nothing when it is open or unreadable) and reads the order list again after the cancels, because Bybit processes a cancel asynchronously | «the clean-up of leftovers happens only for a position that has been proved flat», time-exit, manual close, panic, outside close tests |
| A failure never touches the stop-loss and is never silent | `failed` journals, alerts once (and once more when it gives up after six refusals) and backs off 10 s → 30 s → 1 min → 2 min → 5 min | «failures leave the position covered…», `staged.i18n.test.ts` |
| Idempotent | `orderLinkId = hash(tradeId + key)` and its generation; lookups before and after every placement | «a reply that is lost…», «a request that never reached Bybit…», the owner-cancel and lagging-history tests |
| Restart at any point | nothing important lives in memory: the record has the resolved plan, the initial quantity, the contract rules and the trailing anchor; the stage comes from the position, the orders from `/v5/order/realtime`, the ids from the `shotb_o_<tag>_` prefix | the three «restart» tests, the property test |
| The stop-loss is looked at right after every staged request | `staged.ts: checkStop` after each create / cancel; `trader.ts: stopProblem` (two looks 0.5 s apart); `afterStaged` closes, disarms and alerts | `staged.review.test.ts` (hostile fake: `dropStopOnConditional`, `dropStopOnCancel`; a lagging list does not close a healthy position) |
| The panic button wins | `trader.ts: panic` raises a flag before it waits for the lock; a pass that is already placing orders places no more | «the panic button stops a staged pass that is already placing orders» |
| Plans without `exits` are unchanged | every staged line is guarded by `plan.exits` / `trade.staged`; the record of a plain trade has no `staged` key; the request sequence of an entry is pinned | «leaves the plain plan exactly as it was», the existing tests of the trader, unchanged except for the ones that pinned the old refusal (now they set the flag explicitly) |

Mutation check (on a scratch copy, then restored): cancelling stale orders without waiting for their replacement, calling `cancel-all` from the executor's cancel, dropping the give-up reset on a stage change, not dropping a problem whose order stands, and counting timeouts toward the six refusals were each caught by the tests above (the first two also by the property test alone, which needed a directed step «the price crosses take-profits and the next look finds every placement refused» to see the first).

One more rule found by the property test and kept: an entry on a contract is refused while an unfinished trade of that contract exists (`Попередня угода на цьому контракті ще не закрита.`) when either trade is staged, because every trade is matched to a position by its symbol and a second trade would otherwise adopt the first one's position and place a second set of orders. Two plain trades keep the old behaviour.

### Failure modes

| What fails | What happens |
| --- | --- |
| A take-profit, the breakeven or the trailing stop is **refused** | journal line + one `important` alert («Bybit: поетапний вихід не розставлено»), the sentence is stored in `staged.problems` and shown on the Live page; retried after 10 s, 30 s, 1 min, 2 min, 5 min; timeouts, rate limits and orders that could not be confirmed back off the same way but never count toward the six; after six refusals it stops until the stage changes (it then gets one more go) or the process restarts (second alert). A problem is dropped as soon as its order stands. The position keeps its stop-loss and final target |
| The reply is **lost or the request times out** | the order is looked up by its id: found → placed; not found after three looks → a failure, retried later under the same id, so never two orders |
| The **open-order list** cannot be read | nothing is placed or cancelled in that pass (warning once a minute) |
| The **breakeven stop would trigger at once** (110092: the price is already back at the entry) | the rest is closed with a reduce-only market order and recorded as `breakeven` (journal + alert «Bybit: безубиток, ринкове закриття») |
| The **trailing stop would trigger at once** (110092: the price bounced above its level between two looks) | the same, recorded as `trailing` |
| A take-profit's level was **passed** before it could be placed (110093) | not chased: reported as a problem (retried every 5 minutes); the stop-loss, the target, breakeven and trailing still apply |
| Bybit refuses a conditional order for **their number** (110009; the position's own stop-loss and take-profit count) | reported like any refusal; the set is at most 9–10 orders in the worst case (stop-loss, target, four take-profits, breakeven, trailing, and the old trailing while it is replaced) |
| **Bybit refuses the reduce-only market close** as a conflict with the extra reduce-only orders (110017) | if the position is still exactly the size the close was sent for (not a race with a take-profit that filled meanwhile), `releaseForClose` cancels the ADDITIONAL staged orders only and the close is retried on the next tick; the stop-loss and target are not orders of this trade and stay (the journal first shows the module's existing sentence for 110017, «позиції немає або вона вже закрита», which is not precise for this case; the line that follows says what was done) |
| **Leftover orders cannot be cancelled** after the position is flat | alert, `staged.cleanup = 'pending'` on the closed trade, retried quietly every 30 s; the pre-entry check refuses a new entry on that contract while any order is open |
| The **stop-loss disappears** | the existing path: disarm, close with a reduce-only order, `settle` cancels the staged leftovers |
| The owner **cancels a staged order by hand** | the next pass places it again under the next generation of its id (also when the history lags: first a «duplicate» failure, then the next generation) |
| The process **dies** at any point | next start: `OPENING` → `FAILED` (existing, press «Звірити з Bybit»); `OPEN` with `staged` → the next pass re-derives and completes the set; a reconciled entry whose plan was never resolved is adopted as a plain stop-and-target trade, which the journal says |

### Differences from the backtest and the model that Bybit live adds

Each is in addition to the tables above.

| # | Topic | Bybit live |
| --- | --- | --- |
| 15 | **Trailing granularity** | the best price is what CandleLab observed: the position's mark price every 5 s, plus the feed's range between polls when the feed runs (a WebSocket for the symbols of open staged trades, so a dip inside a poll is seen); a dip that is both made and recovered inside one look is invisible, which makes the stop looser than asked, never tighter. The stop is moved only for a gain of at least max(1 tick, 5 % of the callback distance): at most that much looser than asked |
| 16 | **Activation** | the trailing stop does not exist on the exchange until the activation price has been observed; a fall through the activation price and a rise above the future stop inside one look ends in a market close recorded as `trailing` |
| 17 | **Trailing anchor** | kept by CandleLab in the trade record: unlike Binance (#11) the anchor survives the replacement of the stop at a stage change, so the stop is not looser after a take-profit |
| 18 | **Final target** | the position's own take-profit, attached to the entry order (last price, market), computed from the mark price before the fill; the plan adopts it, so for a plan with a second target of the kind «percent» the far target is up to the slippage away from the one the model would resolve from the fill |
| 19 | **Minimum order** | conservative as above: Bybit merges more parts at small sizes than Binance does |
| 20 | **Conditional order kind** | take-profits and stops are conditional MARKET orders (IOC): they fill at the book after the trigger, like Binance's `*_MARKET` algo orders; a market order can fill in parts with a thin book (the executor sees a part-filled order as fired and does not place it again; the stage lags by that part until the next one fires) |

### Facts checked against Bybit's public documentation (13 October 2026) and facts that were not

Checked (`bybit-exchange.github.io/docs/v5`: Place Order, Set Trading Stop, Get Open Orders, Cancel Order, Cancel All Orders, Amend Order, Error Codes, Enums):

- `POST /v5/order/create`: `triggerPrice` turns an order into a conditional one («conditional orders do not occupy margin»); `triggerDirection` 1 = the market price rises to `triggerPrice`, 2 = falls to it; `triggerBy` is `LastPrice`, `IndexPrice` or `MarkPrice`; `reduceOnly: true` means the position can only shrink and **excludes take-profit and stop-loss on the same order**; `closeOnTrigger` is for closing orders, «ensures your stop loss reduces your position regardless of current available margin»; `orderLinkId` is at most 36 characters of letters, digits, `-` and `_` and «must always be unique»; for perpetuals the quantity is always in contracts and positive; a reduce-only order above the maximum order quantity is split by the exchange; the request is asynchronous and only acknowledged («use the WebSocket to confirm»); **at most 500 active orders and 10 active conditional orders per symbol**.
- `POST /v5/position/trading-stop`: see above for what it does not say. `tpslMode` is `Full` or `Partial`; partial TP/SL needs `tpSize` = `slSize`; in Partial mode at most 20 TP/SLs (error 110061).
- `GET /v5/order/realtime`: without `orderFilter` all kinds of orders are returned for linear contracts; `openOnly` 0 returns open statuses only (and is ignored when querying by `orderLinkId`); `limit` 1–50; the answer carries `triggerPrice`, `triggerDirection`, `triggerBy`, `reduceOnly`, `closeOnTrigger`, `stopOrderType`, `createType`, `cancelType`, `orderStatus` (`Untriggered`, `New`, `Triggered`, `Filled`, `Cancelled`, `Deactivated`, …).
- `POST /v5/order/cancel`: by `orderId` or `orderLinkId`; `orderFilter` is «spot trading only»; only unfilled or partly filled orders; asynchronous.
- `POST /v5/order/cancel-all`: for linear/inverse, with no `orderFilter`, «all kinds of orders will be cancelled, like active order, conditional order, TP/SL order and trailing stop order».
- Error codes (the table of the Error Codes page): 110001 order does not exist, 110008 completed or cancelled, 110009 too many stop orders, 110017 «orderQty will be truncated to zero» (the code Bybit uses for a reduce-only order that does not fit the position), 110072 `OrderLinkedID` is duplicate, 110092 «expect Rising, but trigger_price <= current», 110093 «expect Falling, but trigger_price >= current», 110094 below the minimum notional, 110057 «Conditional order or limit order contains TP/SL related params», 10001 request parameter error.
- Enums: `execType` (`Trade`, `AdlTrade`, `Funding`, `BustTrade`, …), `stopOrderType` (`TakeProfit`, `StopLoss`, `TrailingStop`, `Stop`, `PartialTakeProfit`, `PartialStopLoss`, …), `createType` (`CreateByStopLoss`, `CreateByTakeProfit`, `CreateByPartialStopLoss`, `CreateByPartialTakeProfit`, `CreateByTrailingStop`, `CreateByStopOrder`, `CreateByClosing`, …); `exitKindOf` maps them and `staged.test.ts` pins every value above.
- Bybit's help centre (read through a search summary, not the page): the total size of reduce-only orders is checked against the position, and the ones furthest from the market are reduced or cancelled by the system.

**Not verified without a real exchange** (each fails safe; the owner's testnet steps look at each):

1. Whether the position's own Full-mode stop-loss and take-profit are listed by `/v5/order/realtime` as `Untriggered` orders of type `StopLoss` / `TakeProfit` with no `orderLinkId` of CandleLab's. The executor ignores every order that does not carry its prefix, so it holds either way; the fake lists them, to prove it.
2. How the combined size of reduce-only CONDITIONAL orders is checked: at placement (the stage-0 set is only take-profits and fits; later the trailing stop and breakeven together with the remaining take-profits exceed the position and the later ones would be refused with 110017, which the fake reproduces with `strictReduceOnly`: reported as problems, never a risk to the stop-loss) or when an order triggers (an order larger than the position is trimmed or cancelled; the replacement at each stage change keeps the quantities right).
3. Whether the minimum order value applies to reduce-only conditional orders (assumed to; the effect is only more merging at small sizes).
4. The fields of the execution of a triggered conditional order: `orderLinkId`, `stopOrderType = Stop`, `createType = CreateByStopOrder` are assumed; a fill without a link id is joined to `GET /v5/order/history` by order id, and an unknown fill is `external`. The position's own stop-loss and take-profit are recognised by `StopLoss` / `TakeProfit` in either field.
5. Whether `POST /v5/order/cancel` accepts a linear conditional order by `orderLinkId` without `orderFilter` (the page marks the filter spot-only).
6. That the codes 110092 / 110093 are what Bybit answers for a trigger on the wrong side of the market, and 110017 for a reduce-only conflict, and 110009 for the number of conditional orders. Another code is a failed placement (retried with a back-off) instead of the immediate market close.
7. That `orderLinkId`s stay reserved after their order has ended (assumed; if they do not, the next generation is simply not needed), and how soon a new conditional order appears in `/v5/order/realtime` (three looks, 0.4 s apart).
8. That Bybit's `liqPrice` after a partial close does not move closer than `protection()` accepts (a failure is a protective close of the rest, a safe outcome).
9. Whether a conditional order with `closeOnTrigger: true` and a positive quantity is accepted on a unified account in ISOLATED_MARGIN mode (the documentation shows it for reduce-only orders in general).

## OKX live (15 October 2026)

Implemented once for every exchange of the generic live framework: `server/exchanges/live/staged.ts` (`ExchangeStagedExecutor`, a port of the Bybit executor to the normalised client contract: the same states, the same reconcile loop, the same invariants), the hooks in `server/exchanges/live/trader.ts`, and OKX's client methods `createConditional`, `cancelConditional` (`okx.ts`). `LIVE_STAGED_EXITS.okx` is on in `shared/exits.ts`; the blockers, «Підготувати live» and the module's own settings consult the flag of the strategy's own exchange. Test support: `fakeOkx.ts` on `fake.ts`, and three suites every exchange of the framework runs against its own client: `staged.conformance.testkit.ts` (the request sequences, stages, restarts, refusals, small sizes), `property.conformance.testkit.ts` (random faults, below) and `conformance.testkit.ts` (the plain module). **Nothing here has run against OKX, real or demo.**

### What stands where

| Declared | OKX mechanism | Trigger | Note |
| --- | --- | --- | --- |
| `stop` (`closeAll`) | the stop-loss **attached to the entry order** (`attachAlgoOrds`, `slTriggerPx`, `slOrdPx: -1` market, `slTriggerPxType: mark`, `attachAlgoClOrdId` = `shotoks…`) | mark | unchanged from the plain module. **Never placed, moved or cancelled by the staged executor**: its port has no method that could (no amend, no `cancel-all`; `cancelConditional` refuses any id that is not a staged id, so the attached id cannot be named) |
| `target` (`closeAll`) | the attached take-profit (`tpTriggerPx`, `tpOrdPx: -1`, `tpTriggerPxType: last`) | last | the plan's FINAL target, resolved against the mark before the order. Absent when the rest rides: the bot then watches the mark price |
| `tpN` (`partial`) | `order-algo`, `ordType: conditional`, `side: buy`, `reduceOnly: true`, `cxlOnClosePos: true`, **`tpTriggerPx`** (the price falls to it), `tpOrdPx: -1`, `tpTriggerPxType: last`, `sz` in contracts, `algoClOrdId` | last | its own id; the planned size never changes |
| `breakeven` | the same with **`slTriggerPx`** (the price rises to the entry), `slTriggerPxType: mark`, `sz` = the open quantity | mark | added after the first take-profit has filled; replaced (place, confirm, cancel) when a later one fills |
| `trailing` | the same as breakeven, `sz` = the open quantity, at **best price · (1 + callback)** rounded down to the tick; **CandleLab places it once the activation price has been seen and moves it forward** | mark | OKX has a trailing-stop order type (`move_order_stop`), but its documentation does not say it leaves a stop attached to the entry alone, so, as on Bybit, CandleLab moves a reduce-only stop itself (place new → confirm → cancel old). A dip and recovery inside the few seconds between two looks makes it looser than asked, never tighter |

Ids: `shotoko<8 hex of hash(tradeId)><code><generation><10 hex of hash(tradeId|key)>` (≤ 32 letters and digits, OKX's limit); the code is `b` breakeven, `t` trailing, `p1…p4` take-profit n. Entries are `shotok<24 hex>`, closes `shotokx…`, the attached stop `shotoks<the entry's hex>`: the kind is one letter after the prefix and none of the four matches another (`ids.ts`, tested). OKX's `clOrdId` / `algoClOrdId` are unique only among pending orders, so the id of an ended order may be used again by OKX: the executor treats an id as taken for good, looks it up before and after every placement, and keeps a generation number.

### The order sequence

Entry: leverage → **one market sell that carries the attached stop (and the final target)** → the order and the position are read back; `positions()` reports the stop that is LISTED; **four looks 0.4 s apart** are given to a stop that OKX has not activated yet, then `protection()` confirms it (a missing, looser or beyond-liquidation stop ends in the protective close, as everywhere) → the plan is resolved against the REAL fill and stored in the same write that marks the trade OPEN → one reconcile pass places the take-profits, nearest first, each confirmed by id. Then the same stages as on Bybit: stage 0 (stop · final target · tp1…tpN), the trailing stop once the activation price has been seen, the breakeven and a smaller trailing stop after a take-profit fills (new ones confirmed before the old ones are cancelled), flat → `settle` reads the exit reason from the fill that took the last of the position and cancels what is left of the staged set. A staged order that OKX refuses with a **reduce-only conflict** (51169 / 51170 …: OKX counts the sum of reduce-only orders against the position, and a close would be refused for the same reason) makes the executor cancel the extra staged orders so that the close can go through; the close is retried at the next pass.

### Where each invariant is enforced, and the test

The same table as «Bybit live» holds with the names of the generic files: the attached stop is never touched (`client.ts` `checkConditional` / `checkCancelConditional` refuse everything that is not a staged reduce-only buy under a staged id; `safety.test.ts` pins the endpoint list), breakeven and trailing are separate reduce-only orders, nothing is cancelled on a guess, leftovers are cancelled only when flat (`sweepAfterFlat` and `cancelResting` read the position first and cancel only SHOT-owned orders), a failure never touches the stop and is never silent (alerts, back-off), idempotent ids, restart at any point (the stage comes from the position, the orders from the pending algo list, the ids from the prefix), the stop looked at after every staged request (`checkStop`), the panic button wins, plans without `exits` unchanged. **The property test with random faults** (`stagedProperty`, `okx.property.test.ts`): random plans, sizes and price walks, faults injected into any operation (a lost answer, a timeout, a refusal, a silent error, a dropped stop, a partial fill, a lagging list), restarts at random moments; after every step it audits **no position without a stop on the exchange** (except while a fault deliberately dropped it and the executor is closing), **no second position for one signal**, no staged order on a flat contract after the cleanup, and at the end the faults are lifted and the exchange must converge to exactly the orders the model asks for. Result of 15 October 2026 (`STAGED_SEEDS=3000 STAGED_STATS=1`, OKX's real client over `fakeOkx.ts`): **3000 runs passed, no violation**: 4602 entries (none opened twice), 5735 take-profit orders placed and 3287 filled, 526 breakevens, 253 trailing stops (87 filled), 2942 trades closed, 323 order-id generations used, **428 deliberately dropped stops** (each ended in a protective close, never a position left bare) and **680 unknown outcomes** (lost answers, timeouts) all resolved by reading by id and never by resending; at most 37 mutations in one run. 60 seeds are the default of the suite (`STAGED_SEEDS=…` for a long run; a failing seed replays).

### Small sizes

OKX's minimum order is `minSz` contracts (a multiple of `lotSz`): on a small account no part is worth placing, every part merges into the next, and the trade says so in words (`Частину … об’єднано з наступним виходом`, `При вашому розмірі … часткові виходи зводяться до основного стопа й цілі`), exactly as on Bybit.

### Not verified (the facts that could not be checked from the public documentation, and cannot be without an OKX account)

1. Where OKX lists the stop attached to an entry, and how soon after the fill (the whole entry rests on it; if it is listed nowhere the executor can read, every entry is closed within seconds).
2. Whether `cxlOnClosePos: true` cancels a staged order when the position ends, and whether a stop attached to an entry stays listed afterwards (the executor cancels both when flat).
3. Whether a reduce-only conditional order counts against the position the way a resting reduce-only order does, and which code a conflicting close gets.
4. Whether a stop-loss trigger above the price of a short (breakeven, trailing) and a take-profit trigger below it are accepted as separate algo orders next to the attached pair (the codes 51278–51280 and 51300–51308 are mapped to «trigger passed»).
5. The size of the smallest accepted staged order (`minSz`) on the contracts the plans trade.

### Before you arm a staged strategy on OKX (owner's checklist)

Everything of the Bybit checklist applies, with OKX's names; in addition:

1. **Demo first, smallest size** ([MARKETS.md](MARKETS.md) «Live on OKX», «How the owner can try it, safely»): `OKX_ENV=demo`, a demo key with **Trade** only, Futures mode and net mode. «Підготувати live» on an OKX strategy selects the plan and arms nothing.
2. **Watch the first trade on OKX's own page**: the position must show a stop-loss (and the target) within a second or two; one reduce-only conditional order per take-profit (market, «falls to», the size of the part). If CandleLab closes the entry at once and says the stop was not found, write down where OKX shows the stop and stop there.
3. **Let a take-profit fill** (or put a level next to the market): the breakeven order must appear, and a trailing stop with the smaller quantity must replace the old one. **The stop-loss of the position must stay the same price the whole time.**
4. **Cross the activation price and rise a little**: the trailing order must appear and move while the price makes new lows; when the price rises to it the position must close and the trade say `trailing`.
5. **Press «Закрити» and «Стоп усе» on a trade with all orders open**: the position must be flat and **no conditional order of CandleLab may remain**. If OKX refuses the close because of the extra orders, the journal says so and the next attempt (5 s later) must succeed.
6. **A short time limit** must close the open quantity and clear the orders.
7. Only then a real account, with the smallest size; the typed `REAL MONEY` stays yours, and a restart drops the arming. **To flatten at any moment**: «Закрити» or «Стоп усе»; on OKX close the position and cancel every algo order of the contract by hand, then «Звірити з OKX» if the trade shows «Потрібна звірка».

## Bitget live (15 October 2026)

Implemented once for every exchange of the generic live framework (`server/exchanges/live/staged.ts`, see «OKX live» above for the executor); Bitget's part is the client methods `createConditional`, `cancelConditional` (`bitget.ts`). `LIVE_STAGED_EXITS.bitget` is on in `shared/exits.ts`; the blockers, «Підготувати live» and the module's own settings consult the flag of the strategy's own exchange. Test support: `fakeBitget.ts` on `fake.ts`, and the three suites every exchange of the framework runs against its own client. **Nothing here has run against Bitget, real or demo.**

### What stands where

| Declared | Bitget mechanism | Trigger | Note |
| --- | --- | --- | --- |
| `stop` (`closeAll`) | the stop-loss **preset on the entry order** (`presetStopLossPrice`, a market stop; no execution price) | the exchange's setting (the order endpoint has no parameter; the order detail reports `presetStopLossType` `mark_price` or `fill_price`) | unchanged from the plain module. **Never placed, moved or cancelled by the staged executor**: `cancelConditional` refuses any id that is not a staged id, and `cancel-plan-order` is built in one place that always sends an `orderIdList` |
| `target` (`closeAll`) | the preset take-profit (`presetStopSurplusPrice`) | the exchange's setting | the plan's FINAL target, resolved against the mark before the order. Absent when the rest rides: the bot then watches the mark price |
| `tpN` (`partial`) | `place-tpsl-order`, `planType profit_plan`, `holdSide sell`, `size` in base units, no `executePrice` (market), `triggerType` | last (`fill_price`) | its own client id; the planned size never changes |
| `breakeven` | the same with `planType loss_plan` (a rise to the entry), `size` = the open quantity | mark (`mark_price`) | added after the first take-profit has filled; replaced (place, confirm, cancel) when a later one fills |
| `trailing` | the same as breakeven, `size` = the open quantity, at **best price · (1 + callback)** rounded down to the tick; **CandleLab places it once the activation price has been seen and moves it forward** | mark | Bitget has a trailing plan (`moving_plan`, `track_plan`), but nothing documents that it leaves the preset stop alone, so, as on Bybit and OKX, CandleLab moves a partial stop itself (place new → confirm → cancel old). A dip and recovery inside the few seconds between two looks makes it looser than asked, never tighter |

Ids: `shotbgo<8 hex of hash(tradeId)><code><generation><10 hex of hash(tradeId|key)>` (≤ 40 letters and digits, well under Bitget's 50); the code is `b` breakeven, `t` trailing, `p1…p4` take-profit n. Entries are `shotbg<24 hex>`, closes `shotbgx…`: the kind is one letter after the prefix. The plan order Bitget creates has its own `orderId` (`P…` in the fake); the order it creates when it triggers has yet another (`executeOrderId`), which is what the fills carry, so the client joins `orders-plan-history` to name the staged order that produced a fill.

### The order sequence

Entry: the contract's margin mode and leverage (read, then only what differs is written) → **one market sell that carries the preset stop (and the final target)** → the order and the position are read back; `positions()` reports the stop that is LISTED (the row and the plan list, minus CandleLab's own staged orders); **four looks 0.4 s apart** are given to a stop that Bitget has not shown yet, then `protection()` confirms it (a missing, looser or beyond-liquidation stop ends in the protective close, as everywhere) → the plan is resolved against the REAL fill and stored in the same write that marks the trade OPEN → one reconcile pass places the take-profits, nearest first, each confirmed by id. Then the same stages as on Bybit and OKX: stage 0 (stop · final target · tp1…tpN), the trailing stop once the activation price has been seen, the breakeven and a smaller trailing stop after a take-profit fills (new ones confirmed before the old ones are cancelled), flat → `settle` reads the exit reason from the fill that took the last of the position and cancels what is left of the staged set. A staged order that Bitget refuses with a **reduce-only conflict** makes the executor cancel the extra staged orders so that the close can go through; the close is retried at the next pass.

### Where each invariant is enforced, and the test

The same table as «Bybit live» and «OKX live» holds with the names of the generic files: the preset stop is never touched (`client.ts` `checkConditional` / `checkCancelConditional`; `bitget.test.ts` pins the endpoint list, counts the call sites of `cancel-plan-order`, and asserts every cancel it sends has a one-order list and the matching `planType`), breakeven and trailing are separate partial stop orders, nothing is cancelled on a guess, leftovers are cancelled only when flat (`sweepAfterFlat` and `cancelResting` read the position first, cancel only what was created from this trade's entry on or carries CandleLab's prefix), a failure never touches the stop and is never silent, idempotent ids, restart at any point, the stop looked at after every staged request (`checkStop`), the panic button wins, plans without `exits` unchanged. **The property test with random faults** (`bitget.property.test.ts`): random plans, sizes and price walks, faults injected into any operation (a lost answer, a timeout, a refusal, a silent error, a dropped stop, a partial fill, a lagging list), restarts at random moments; after every step it audits **no position without a stop on the exchange** (except while a fault deliberately dropped it and the executor is closing), **no second position for one signal**, no staged order on a flat contract after the cleanup, and at the end the faults are lifted and the exchange must converge to exactly the orders the model asks for. Result of 15 October 2026 (`STAGED_SEEDS=3000 STAGED_STATS=1`, Bitget's real client over `fakeBitget.ts`), **in both readings** (the default one, and the harsh one: partial preset stops that appear 0.3 s late and linger, the position row showing the latest stop, a child order that carries the plan's client id, hedge-style bills, every contract starting in crossed margin): **3000 + 3000 runs passed, no violation**. Default reading: 4652 entries (none opened twice), 5793 take-profit orders placed and 3316 filled, 525 breakevens, 256 trailing stops (91 filled), 2977 trades closed, 321 order-id generations, **433 deliberately dropped stops** (each ended in a protective close) and **677 unknown outcomes** resolved by reading by id; at most 31 mutations in one run. Harsh reading: 4209 entries, 5632 take-profits placed and 3225 filled, 507 breakevens, 249 trailing stops, 2899 closed, 385 dropped stops, 616 unknown outcomes, at most 40 mutations. 60 seeds are the default of the suite (`STAGED_SEEDS=…` for a long run; a failing seed replays).

### Small sizes

Bitget's minimum order is `minTradeNum` in base units (a multiple of `sizeMultiplier`) and **5 USDT of value** (`minTradeUSDT`): on a small account no part is worth placing, every part merges into the next, and the trade says so in words (`Частину … об’єднано з наступним виходом`, `При вашому розмірі … часткові виходи зводяться до основного стопа й цілі`), exactly as on Bybit and OKX. Whether the 5 USDT minimum also applies to a TP/SL plan order is not stated (the fake applies it, the harsher reading).

### Not verified (the facts that could not be checked from the public documentation, and cannot be without a Bitget account)

1. Where Bitget lists the stop preset on an entry, how soon after the fill, and on which price (the whole entry rests on it; if it is listed nowhere the executor can read, every entry is closed within seconds).
2. **Whether a partial `loss_plan` placed next to the preset stop leaves it standing** (the check after every staged request closes the position if not), and whether a preset stop is itself a partial or a whole-position plan.
3. Whether `holdSide: sell` names the short in one-way mode, whether `triggerType` is honoured by a partial plan, and whether a stop-type trigger above the price of a short (breakeven, trailing) and a take-profit trigger below it are accepted next to the preset pair (the refusals read as «trigger passed» are by message: «stop loss price please > mark price»).
4. Whether the preset stop and target are cancelled by Bitget when the position ends, and whether Bitget cancels a staged plan order then (`expireOnFlat` in the fake is off: the harsher reading).
5. Whether `cancel-plan-order` accepts an item with a `clientOid` alone and requires the `planType` to match.
6. The size of the smallest accepted plan order, and the number of plan orders per contract (the fake counts the preset stop and target against a limit of 10, the harsher reading).

### Before you arm a staged strategy on Bitget (owner's checklist)

Everything of the Bybit checklist applies, with Bitget's names; in addition:

1. **Demo first, smallest size** ([MARKETS.md](MARKETS.md) «Live on Bitget», «How the owner can try it, safely»): `BITGET_ENV=demo`, a demo key with futures orders and positions (read/write), a classic account in one-way mode. Demo has BTC, ETH and XRP only. «Підготувати live» on a Bitget strategy selects the plan and arms nothing.
2. **Watch the first trade in Bitget's own app**: the position must show a stop-loss (and the target) within a second or two, with its trigger price type; one partial TP/SL plan order per take-profit (market, the size of the part). If CandleLab closes the entry at once and says the stop was not found, write down where Bitget shows the stop and stop there.
3. **Let a take-profit fill** (or put a level next to the market): the breakeven order must appear, and a trailing stop with the smaller quantity must replace the old one. **The stop-loss of the position must stay the same price the whole time, and must still be listed after each new plan order.**
4. **Cross the activation price and rise a little**: the trailing order must appear and move while the price makes new lows; when the price rises to it the position must close and the trade say `trailing`.
5. **Press «Закрити» and «Стоп усе» on a trade with all orders open**: the position must be flat and **no TP/SL plan order of CandleLab may remain** (open Bitget's TP/SL list). If Bitget refuses the close because of the extra orders, the journal says so and the next attempt (5 s later) must succeed.
6. **A short time limit** must close the open quantity and clear the orders.
7. Only then a real account, with the smallest size; the typed `REAL MONEY` stays yours, and a restart drops the arming. **To flatten at any moment**: «Закрити» or «Стоп усе»; on Bitget close the position and cancel every TP/SL plan order of the contract by hand, then «Звірити з Bitget» if the trade shows «Потрібна звірка».

## MEXC live (15 October 2026)

Implemented by the same generic executor (`server/exchanges/live/staged.ts`, [OKX live](#okx-live-15-october-2026)) over MEXC's client methods `createConditional` and `cancelConditional` (`mexc.ts`). `LIVE_STAGED_EXITS.mexc` is on in `shared/exits.ts` after `mexc.staged.test.ts` (49 checks) and the property test (3000 seeds of random faults) passed. **MEXC's plan orders have no client id at all**, and that is what is different here: see the ledger below. Nothing of this has run on MEXC.

### What stands where

| Declared | MEXC mechanism | Trigger | Note |
| --- | --- | --- | --- |
| `stop` (`closeAll`) | the stop-loss **attached to the entry order** (`stopLossPrice`, `lossTrend: 2` = the fair price) | fair (mark) | unchanged from the plain module. **Never placed, moved or cancelled by the staged executor**: its port has no method that could (`cancelConditional` refuses any id that is not a staged id, and MEXC's `stoporder/place` / `stoporder/change_*` are not in the client at all) |
| `target` (`closeAll`) | the attached take-profit (`takeProfitPrice`, `profitTrend: 1`) | last | the plan's FINAL target; absent when the rest rides (the bot then watches the mark price) |
| `tpN` (`partial`) | `planorder/place/v2`, `side: 2` (close short), `reduceOnly: true`, `orderType: 5` (market), **`triggerType: 2`** (the price falls to it), `trend: 1` (last), `vol` in contracts, 7-day cycle | last | its own ledger entry; the planned size never changes |
| `breakeven` | the same with **`triggerType: 1`** (the price rises to the entry), `trend: 2` (fair price), `vol` = the open quantity | mark | added after the first take-profit has filled; replaced (place, confirm, cancel) when a later one fills |
| `trailing` | the same as breakeven at **best price · (1 + callback)** rounded to the tick; **CandleLab places it once the activation price has been seen and moves it forward** | mark | MEXC's own trailing order is not used: it is not documented to leave an attached stop alone |

Ids: the staged ids are CandleLab's alone (`shotmxo<8 hex><code><generation><hash>`, ≤ 32 letters and digits) and **never reach MEXC**: the plan order has no field for them. The link is the ledger (`mexcLedger.ts`, MARKETS.md «Live on MEXC»): an entry per plan order (CandleLab's id, contract, direction, trigger price, quantity, the time of the request, MEXC's number once known, the number of the order it produced when it fired), written before the request, saved in the platform database, matched by its fingerprint when an answer is lost, forgotten three days after it ended. Everything else is the OKX sequence: place the missing order, confirm it by id (a listing of the plan orders of every state), only then cancel what is stale, leftovers only when the position is flat.

### The order sequence

Entry: leverage → **one market sell that carries the stop (and the final target)** → the order and the position are read back; `positions()` reports the stop that is LISTED in `stoporder/open_orders`; **four looks 0.5 s apart** are given to a stop that MEXC has not listed yet, then `protection()` confirms it → the plan is resolved against the REAL fill and stored in the same write that marks the trade OPEN → one reconcile pass places the take-profits, nearest first, each confirmed by id. Then the same stages as on Bybit and OKX.

### Where each invariant is enforced, and the test

The same table as «OKX live» holds: the attached stop is never touched (`checkConditional` / `checkCancelConditional`; `safety.test.ts` pins the endpoint list and forbids `stoporder/place`, `stoporder/change*`, `cancel_all`, MEXC's own trailing orders), breakeven and trailing are separate reduce-only orders, nothing is cancelled on a guess, leftovers are cancelled only when flat (`sweepAfterFlat`, `cancelResting` read the position first and cancel only SHOT-owned orders — ids with the prefix, plan orders the ledger owns), a failure never touches the stop and is never silent. What MEXC adds, with its tests (`mexc.test.ts`): the same id twice is refused locally (2042) and sends nothing; a request whose answer was lost is adopted by its fingerprint and not repeated; a request that may still be on its way is not repeated for 8 seconds; a refused request leaves no entry; a new client on the same memory still cancels by CandleLab's id; **without the memory the plan orders stand on MEXC with no id and nobody cancels them by mistake**; 18-digit numbers survive to the cancel body; the owner's own plan orders are never touched.

### Small sizes

MEXC's minimum is `minVol` contracts (1 for every crypto contract) of `contractSize` base units: a position too small for any part keeps its stop, its target and its trailing stop and says why, as on Bybit and OKX.

### Not verified (cannot be checked without a MEXC account)

1. Where and when MEXC lists the stop attached to an entry (the whole entry rests on it).
2. That a reduce-only market plan order (`side: 2`, `reduceOnly`, `triggerType`, `trend`, a 7-day cycle) is accepted next to the attached pair in one-way mode, that no `leverage` is demanded for it, and which code a trigger already passed gets (3004 is mapped to «trigger passed»).
3. That `planorder/list/orders` returns an order for the `start_time` / `end_time` window of its creation, that the number of the order an executed plan order placed (`orderId` of the row) is the order that shows in the deals, and whether a plan order is cancelled by MEXC when the position ends (the executor cancels the leftovers either way).
4. Whether a plan order that is cancelled or has fired is listed at once (the executor treats an order with a known number that is not yet listed as still working, and a listing that says otherwise wins).
5. The ledger under a real restart and a real lost answer: exercised only against the fake.

### Before you arm a staged strategy on MEXC (owner's checklist)

Everything of the OKX checklist applies, with MEXC's names, and **only after a plain plan (one stop, one target) has been through a whole trade**: watch the Plan orders tab of MEXC while the first staged trade lives; stop CandleLab and start it again once and check that no plan order was placed twice; note that plan orders expire after 7 days (the executor places the next incarnation of a take-profit that has expired).

## Gate live (15 October 2026)

Implemented once for every exchange of the generic live framework (`server/exchanges/live/staged.ts`, see «OKX live» above for the executor); Gate's part is the client methods `createConditional`, `cancelConditional` (`gate.ts`). `LIVE_STAGED_EXITS.gate` is on in `shared/exits.ts`; the blockers, «Підготувати live» and the module's own settings consult the flag of the strategy's own exchange. Test support: `fakeGate.ts` on `fake.ts`, and the three suites every exchange of the framework runs against its own client. **Nothing here has run against Gate, real or test network.**

Two things are different from every exchange before it. (1) **The position's own stop and target are price orders too**, placed by the client right after the entry (they are not attached to the entry order), so on Gate the stop, the target and the staged exits are all `price_orders`, told apart by their shape and their ids. (2) **Staged exits need Gate to keep the custom id (`text`) of a price order**, which its SDK page does not promise: the client reads each staged order back right after placing it, and if Gate wrote its own text the order is cancelled again and the staged exits are refused on Gate (`TEXT_NOT_KEPT`, a problem on the trade, no order left standing); the stop and the target of the entry are not affected.

### What stands where

| Declared | Gate mechanism | Trigger | Note |
| --- | --- | --- | --- |
| `stop` (`closeAll`) | a **position-wide price order** placed by the client right after the fill (`order_type close-short-position`, `initial.close true`, `size 0`, `rule 1`, id `shotgts…`) | mark | **Never placed, moved or cancelled by the staged executor**: `cancelConditional` refuses any id that is not a staged id, finds the numeric id by listing and cancels one order at a time. Because it closes "everything that is left", it covers the whole remaining position after any partial exit with no change |
| `target` (`closeAll`) | the same with `rule 2` and an id ending in `z` | last | the plan's FINAL target, resolved against the mark before the order. Not placed after a stop that failed; absent when the rest rides: the bot then watches the mark price |
| `tpN` (`partial`) | `price_orders` with `order_type plan-close-short-position`, `initial.size` = the part (positive), `reduce_only true`, `rule 2`, `price_type 0` | last | its own client id (`shotgto…`); the planned size never changes |
| `breakeven` | the same with `rule 1` (a rise to the entry), `price_type 1`, `size` = the open quantity | mark | added after the first take-profit has filled; replaced (place, confirm, cancel) when a later one fills |
| `trailing` | the same as breakeven, `size` = the open quantity, at **best price · (1 + callback)** rounded down to the tick; **CandleLab places it once the activation price has been seen and moves it forward** | mark | Gate has no trailing order of this kind, so, as on the other exchanges, CandleLab moves a reduce-only stop itself (place new → confirm → cancel old). A dip and recovery inside the few seconds between two looks makes it looser than asked, never tighter |

Ids: `shotgto<8 hex of hash(tradeId)><code><generation><10 hex of hash(tradeId|key)>` (28 characters, Gate's limit after the `t-` prefix); the code is `b` breakeven, `t` trailing, `p1…p4` take-profit n. Entries are `shotgt<22 hex>`, closes `shotgtx…`, the stop `shotgts<21 hex>`, the target the same ending in `z`: the kind is one letter after the prefix. Gate does not document that a custom id is unique, so the client looks the id up before it creates a staged order and refuses a duplicate itself (kind `duplicate-id`); the staged executor's own rule (an id is taken for good, the next generation is used) stays.

### The order sequence

Entry: leverage → **one market sell with no stop** → the order is read, the stop (and the final target) are placed as price orders → the order and the position are read back; `positions()` reports the stop that is LISTED; **three looks 0.4 s apart** are given to a stop that Gate has not listed yet, then `protection()` confirms it (a missing, looser or beyond-liquidation stop ends in the protective close, as everywhere) → the plan is resolved against the REAL fill and stored in the same write that marks the trade OPEN → one reconcile pass places the take-profits, nearest first, each confirmed by its id (read back by Gate's numeric id while this process remembers it, by the text after a restart). Then the same stages as on the other exchanges: stage 0 (stop · final target · tp1…tpN), the trailing stop once the activation price has been seen, the breakeven and a smaller trailing stop after a take-profit fills (new ones confirmed before the old ones are cancelled), flat → `settle` reads the exit reason from the fill that took the last of the position (joined to the finished price orders by `trade_id`) and cancels what is left of the staged set. Whatever is left of the position's own stop and target after it ends is swept by id (`sweepAfterFlat`), because Gate does not say whether it cancels them.

### Where each invariant is enforced, and the test

The same table as «Bybit live» and «OKX live» holds with the names of the generic files: the position's stop is never touched by the staged executor (`client.ts` `checkConditional` / `checkCancelConditional`; `gate.safety.test.ts` pins the endpoint list and fails on a bulk cancel; the fake's audit records a violation if a request removes or moves a standing stop), breakeven and trailing are separate partial stop orders, nothing is cancelled on a guess, leftovers are cancelled only when flat, a failure never touches the stop and is never silent, idempotent ids, restart at any point (the stage comes from the position, the orders from the list of price orders, the ids from the text), the stop looked at after every staged request (`checkStop`), the panic button wins, plans without `exits` unchanged. **The property test with random faults** (`stagedProperty`, `gate.property.test.ts`; run in two readings of what Gate leaves open: the default, and one where the stop and target stay listed when the position ends, the order a price order makes keeps its id, a finished order is found by its custom id for an hour and Gate takes a price order for a week at most): random plans, sizes and price walks, faults injected into any operation (a lost answer, a timeout, a refusal, a silent error, a dropped stop, a partial fill, a lagging list), restarts at random moments; after every step it audits **no position without a stop on the exchange** (except while a fault deliberately dropped it, or a position is awaiting its second request — Gate's `bare` state — and the executor is closing it), **no second position for one signal**, no staged order on a flat contract after the cleanup, and at the end the faults are lifted and the exchange must converge to exactly the orders the model asks for. Result of 15 October 2026 (`STAGED_SEEDS=3000 STAGED_STATS=1`, Gate's real client over `fakeGate.ts`): **3000 runs passed in each of the two readings, no violation** (default / the other readings): 4619 / 4257 entries (none opened twice), 5761 / 5697 take-profit orders placed and 3285 / 3247 filled, 529 / 521 breakevens, 258 / 255 trailing stops (89 / 88 filled), 2961 / 2930 trades closed, 317 / 312 order-id generations used, **427 / 388 deliberately dropped stops** (each ended in a protective close, never a position left bare) and **675 / 623 unknown outcomes** (lost answers, timeouts) all resolved by reading by id and never by resending; at most 37 / 42 mutations in one run. 60 seeds are the default of the suite (`STAGED_SEEDS=…` for a long run; a failing seed replays). The stop-is-a-second-order gap has its own tests (`gate.entry.test.ts`: every way the stop's request can fail, a lost entry answer, a late fill, an expired stop, a seeded random sequence over the requests of an entry; `GATE_ENTRY_SEEDS=2000` passed on 15 October 2026).

### Small sizes

Gate's minimum order is one contract (`order_size_min`, at least 1 here) of `quanto_multiplier` base units, and **a part is placed in whole contracts**: one contract is worth 0.43 USDT at the median, 3 USDT at the 90th percentile and more than 10 USDT for 1.2 % of the tokens ([MARKETS.md](MARKETS.md) «Paper on Gate»). On a small account no part is worth placing, every part merges into the next, and the trade says so in words (`Частину … об’єднано з наступним виходом`, `При вашому розмірі … часткові виходи зводяться до основного стопа й цілі`), exactly as on the other exchanges. Gate has no minimum order value.

### Not verified (the facts that could not be checked from the public documentation, and cannot be without a Gate account)

1. **Whether Gate accepts the position's stop as built** (`order_type close-short-position`, `initial.close true`, `size 0`, a trigger ≥ the mark price, an expiration of 30 days) — if it does not, every entry is closed within seconds and the journal names Gate's label — and where Gate lists it (the client reads the open price orders of the contract).
2. **Whether Gate keeps the custom id of a price order** (staged exits depend on it, the stop does not), and whether a staged order made by `plan-close-short-position` with `reduce_only` is accepted next to the position-wide pair.
3. Whether a stop-type trigger above the price of a short (breakeven, trailing) and a take-profit trigger below it are accepted as separate price orders next to the position-wide pair (the refusals read as «trigger passed» are by label `AUTO_TRIGGER_PRICE_*` or by the message of INVALID_PARAM_VALUE).
4. Whether Gate cancels the position-wide stop and target, and the staged orders, when the position ends (the fake runs both readings; the client sweeps by id).
5. The longest `expiration` of a price order, and how many price orders one contract may hold (the fake counts the position's stop and target against a limit of 10, the harsher reading).
6. Whether the order a price order makes keeps its custom id (the client joins by `trade_id` and works either way).

### Before you arm a staged strategy on Gate (owner's checklist)

Everything of the Bybit checklist applies, with Gate's names; in addition:

1. **TestNet first, smallest size** ([MARKETS.md](MARKETS.md) «Live on Gate», «How the owner can try it, safely»): `GATE_ENV=testnet`, a TestNet key with Perpetual Futures read-write, a classic account in one-way mode, **BTC_USDT** (the TestNet lists few contracts). «Підготувати live» on a Gate strategy selects the plan and arms nothing.
2. **Watch the first trade in Gate's own TestNet page**: the position must show a position-wide stop-loss (and the target) within a second or two; one price order per take-profit (market, the size of the part, «reduce only»). If CandleLab closes the entry at once and says the stop was not placed, write down Gate's label and message and where Gate shows the stop, and stop there.
3. **If the journal says `TEXT_NOT_KEPT`** the staged exits do not work on Gate and nothing was left standing (check the list of price orders); plain strategies are not affected. Write it down.
4. **Let a take-profit fill** (or put a level next to the market): the breakeven order must appear, and a trailing stop with the smaller quantity must replace the old one. **The stop-loss of the position must stay the same price the whole time, and must still be listed after each new price order.**
5. **Cross the activation price and rise a little**: the trailing order must appear and move while the price makes new lows; when the price rises to it the position must close and the trade say `trailing`.
6. **Press «Закрити» and «Стоп усе» on a trade with all orders open**: the position must be flat and **no price order of CandleLab's may remain** (open the list of conditional orders on Gate). If Gate refuses the close because of the extra orders, the journal says so and the next attempt (5 s later) must succeed.
7. **A short time limit** must close the open quantity and clear the orders.
8. Only then a real account, with the smallest size; the typed `REAL MONEY` stays yours, and a restart drops the arming. **To flatten at any moment**: «Закрити» or «Стоп усе»; on Gate close the position and cancel every price order of the contract by hand, then «Звірити з Gate» if the trade shows «Потрібна звірка».

## Not done

- A run of any live executor against a real or test exchange. All of them (Binance, Bybit, and the generic one that serves OKX, Gate, Bitget and MEXC) are implemented and tested against fake exchanges only; the facts that could not be verified from the public documentation are listed in each section («Binance live», «Bybit live», «OKX live», «Gate live», «Bitget live»), and the owner's testnet / demo checklists are there too.
- The long side for the spike type (the model is direction-aware and tested against the backtest for longs, but no runner opens a long).
- A minimum-notional rule for reduce-only exits in paper (the exchanges' rules differ; the model accepts `facts.minNotional` for an executor that needs it).
