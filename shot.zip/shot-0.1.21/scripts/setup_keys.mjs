// Puts exchange API keys into the local .env without the browser ever seeing them:   npm run keys   (node scripts/setup_keys.mjs)
// Asks in the terminal with the input hidden, writes ONLY the key and secret lines of the chosen exchange (and that exchange's environment line),
// never prints a value, never touches any other line, and never changes a trading flag (ENABLE_*): CandleLab reads the account until YOU switch trading on.
// Option 3 (or --helper) adds the FREE model keys of the chat helper (Gemini, Groq, Cerebras) the same way (docs/ASSISTANT.md).
import nodeFs from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { envValue, freshEnvText, setEnvValues } from './lib/env.mjs';
import { isMain } from './lib/main.mjs';
import { msg, pickLang } from './lib/messages.mjs';
import { createService } from './service.mjs';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
/** Keys the two exchanges issue are letters and digits (sometimes with `-` or `_`); anything else would also break a `.env` line. */
export const KEY_PATTERN = /^[A-Za-z0-9_-]{8,256}$/;
/**
 * The exchanges whose keys this script writes. `passphrase`: the exchange asks for a third secret (OKX). `testWord`: what its `.env` environment line calls the test network (`testnet`, or `demo` for OKX). The menu numbers
 * are the order of `MENU` below (1, 2 and 3 never move; an exchange added later takes the next number). Only the key, the secret, the passphrase and the environment line are ever written: never an ENABLE_* flag.
 */
export const EXCHANGES = {
  binance: { name: 'Binance', key: 'BINANCE_API_KEY', secret: 'BINANCE_API_SECRET', env: 'BINANCE_ENV', defaultEnv: 'testnet', testWord: 'testnet' },
  bybit: { name: 'Bybit', key: 'BYBIT_API_KEY', secret: 'BYBIT_API_SECRET', env: 'BYBIT_ENV', defaultEnv: 'testnet', testWord: 'testnet' },
  okx: { name: 'OKX', key: 'OKX_API_KEY', secret: 'OKX_API_SECRET', passphrase: 'OKX_API_PASSPHRASE', env: 'OKX_ENV', defaultEnv: 'demo', testWord: 'demo', advice: 'keys.advice.okx' },
  gate: { name: 'Gate', key: 'GATE_API_KEY', secret: 'GATE_API_SECRET', env: 'GATE_ENV', defaultEnv: 'testnet', testWord: 'testnet', advice: 'keys.advice.gate' },
  bitget: { name: 'Bitget', key: 'BITGET_API_KEY', secret: 'BITGET_API_SECRET', passphrase: 'BITGET_API_PASSPHRASE', env: 'BITGET_ENV', defaultEnv: 'demo', testWord: 'demo', advice: 'keys.advice.bitget' },
};
EXCHANGES.mexc = { name: 'MEXC', key: 'MEXC_API_KEY', secret: 'MEXC_API_SECRET', env: 'MEXC_ENV', defaultEnv: 'mainnet', testWord: 'testnet', noTest: true, advice: 'keys.advice.mexc' }; // one row per exchange, after the table: no test network for the API
/**
 * The practice key of Paper → Testnet (docs/TESTNET.md): its own slot next to the real-money key, so both can be set at once. `practice`: it has no environment line (it is always the exchange's test network), and a real-money key
 * is never accepted here by design: the practice executor only ever talks to the demo hosts.
 */
EXCHANGES['binance-testnet'] = { name: 'Binance Testnet (practice money)', key: 'BINANCE_TESTNET_API_KEY', secret: 'BINANCE_TESTNET_API_SECRET', env: null, practice: true, advice: 'keys.advice.testnet' };
/** Menu number -> what the person chose (3 is the chat helper's free keys; 8 is the practice key of Paper → Testnet). */
export const MENU = { 1: 'binance', 2: 'bybit', 3: 'helper', 4: 'okx', 5: 'gate', 6: 'bitget', 7: 'mexc', 8: 'binance-testnet' };
/** A passphrase is written unquoted, so it must be made of the characters a `.env` line keeps as they are (OKX lets the person choose it when the key is created). */
export const PASSPHRASE_PATTERN = /^[A-Za-z0-9_.:@/+=,-]{4,128}$/;

/**
 * The chat helper's FREE model keys (docs/ASSISTANT.md): one variable per provider, one key or several separated by commas (separate free accounts, used in turn). A key is letters, digits,
 * `-`, `_` and `.` (the same shape server/assistant/keys.ts accepts). They are the person's own: this file never ships with a value and never prints one.
 */
export const HELPER_KEY_PATTERN = /^[A-Za-z0-9_.-]{16,200}$/;
export const HELPER_PROVIDERS = {
  gemini: { name: 'Gemini', variable: 'GEMINI_API_KEY', where: 'aistudio.google.com/apikey' },
  groq: { name: 'Groq', variable: 'GROQ_API_KEY', where: 'console.groq.com/keys' },
  cerebras: { name: 'Cerebras', variable: 'CEREBRAS_API_KEY', where: 'cloud.cerebras.ai' },
};
const splitKeys = text => String(text ?? '').split(/[,;\s]+/).map(k => k.trim().replace(/^["']|["']$/g, '')).filter(Boolean);

export function parseKeysArgs(argv) {
  const out = { exchange: undefined, environment: undefined, provider: undefined, restart: undefined, lang: undefined, unknown: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i], [flag, inline] = a.startsWith('--') && a.includes('=') ? [a.slice(0, a.indexOf('=')), a.slice(a.indexOf('=') + 1)] : [a, undefined];
    const value = () => inline ?? argv[++i];
    if (flag === '--exchange') out.exchange = value();
    else if (flag === '--env' || flag === '--environment') out.environment = value();
    else if (flag === '--restart') out.restart = true;
    else if (flag === '--no-restart') out.restart = false;
    else if (flag === '--lang') out.lang = value();
    else if (flag === '--helper') { out.exchange = 'helper'; if (inline !== undefined || (argv[i + 1] && !argv[i + 1].startsWith('--'))) out.provider = value(); }
    else out.unknown.push(a);
  }
  return out;
}

/** Reads one line from a terminal in raw mode, hiding it when `hidden`. Handles backspace, Ctrl+U, Ctrl+C, pasted text and stray escape sequences. */
function readRaw(stdin, stdout, prompt, hidden) {
  return new Promise((done, fail) => {
    stdout.write(`${prompt}: `);
    let buf = '', escape = false;
    const finish = (error) => {
      stdin.removeListener('data', onData); stdin.setRawMode(false); stdin.pause(); stdout.write('\n');
      if (error) fail(error); else done(buf);
    };
    const onData = chunk => {
      for (const ch of String(chunk)) {
        if (escape) { if (/[A-Za-z~]/.test(ch)) escape = false; continue; }
        if (ch === '\u001b') { escape = true; continue; }
        if (ch === '\r' || ch === '\n') return finish();
        if (ch === '\u0003') return finish(new Error('cancelled'));
        if (ch === '\u007f' || ch === '\b') { if (buf) { buf = buf.slice(0, -1); if (!hidden) stdout.write('\b \b'); } continue; }
        if (ch === '\u0015') { if (!hidden) stdout.write('\b \b'.repeat(buf.length)); buf = ''; continue; }
        if (ch >= ' ') { buf += ch; if (!hidden) stdout.write(ch); }
      }
    };
    stdin.setEncoding('utf8'); stdin.setRawMode(true); stdin.resume(); stdin.on('data', onData);
  });
}

/** Terminal prompts: `ask` shows what is typed, `askSecret` does not. Without a terminal (a pipe) the answers are read line by line from the stream. */
export function createTerminalIo({ stdin = process.stdin, stdout = process.stdout } = {}) {
  let queue = null;
  const piped = async () => {
    if (queue) return queue;
    let text = '';
    stdin.setEncoding('utf8');
    for await (const chunk of stdin) text += chunk;
    queue = text.split(/\r?\n/);
    return queue;
  };
  const line = async prompt => { stdout.write(`${prompt}: `); const q = await piped(); const v = q.shift() ?? ''; stdout.write('\n'); return v; };
  return {
    tty: Boolean(stdin.isTTY),
    out: text => stdout.write(`${text}\n`),
    ask: prompt => (stdin.isTTY ? readRaw(stdin, stdout, prompt, false) : line(prompt)),
    askSecret: prompt => (stdin.isTTY ? readRaw(stdin, stdout, prompt, true) : line(prompt)),
  };
}

/** The whole flow with injected `io` (tests answer the prompts), `fs`, `service`. Returns `{ ok, exchange, written }`; never returns or logs a key. */
export async function runKeys(options = {}, deps = {}) {
  const d = { root: ROOT, fs: nodeFs, env: process.env, io: createTerminalIo(), service: undefined, ...deps };
  const lang = options.lang === 'uk' || options.lang === 'en' ? options.lang : pickLang(d.env, '');
  const say = (key, vars) => msg(lang, key, vars);
  const { io } = d;
  const envPath = join(d.root, '.env'), examplePath = join(d.root, '.env.example');
  try {
    io.out(`CandleLab: ${say('keys.title')}\n`);
    if (!io.tty) io.out(say('keys.tty'));
    let id = options.exchange?.toLowerCase();
    if (id === 'testnet' || id === 'practice') id = 'binance-testnet';
    if (!id) {
      io.out(say('keys.exchange'));
      id = MENU[(await io.ask(say('keys.choice'))).trim()];
    }
    if (id === 'helper') return await runHelperKeys(options, d, say, envPath, examplePath);
    const ex = EXCHANGES[id];
    if (!ex) { io.out(say('keys.cancel')); return { ok: false, written: [] }; }

    const existing = readText(d.fs, envPath);
    const current = ex.env ? envValue(existing, ex.env) : '';
    let environment = options.environment?.toLowerCase();
    if (ex.practice) { // the practice slot is the test network by definition: no question about it, and no other network is accepted
      if (environment !== undefined && environment !== 'testnet' && environment !== 'demo') { io.out(say('keys.env.practiceonly')); return { ok: false, written: [] }; }
      io.out(say('keys.practice.info'));
      environment = 'practice';
    }
    if (environment === 'testnet' || environment === 'demo') environment = ex.testWord; // the test network is called what the exchange calls it
    if (ex.noTest) { // an exchange with no test network for its API (MEXC): the key is for the real account, and the person is told so instead of being asked
      if (environment !== undefined && environment !== 'mainnet') { io.out(say('keys.env.notest', { name: ex.name })); return { ok: false, written: [] }; }
      if (!environment) { io.out(say('keys.env.notest.info', { name: ex.name })); environment = 'mainnet'; }
    }
    if (!environment) {
      io.out(say(ex.testWord === 'demo' ? 'keys.env.demo' : 'keys.env'));
      const answer = (await io.ask(`${say('keys.choice')} [${current === 'mainnet' ? 2 : 1}]`)).trim();
      environment = answer === '' ? (current === 'mainnet' ? 'mainnet' : ex.defaultEnv) : { 1: ex.testWord, 2: 'mainnet' }[answer];
    }
    if (!ex.practice && environment !== ex.testWord && environment !== 'mainnet') { io.out(say('keys.cancel')); return { ok: false, written: [] }; }

    const key = (await io.askSecret(say('keys.key'))).trim();
    const secret = (await io.askSecret(say('keys.secret'))).trim();
    if (!KEY_PATTERN.test(key) || !KEY_PATTERN.test(secret)) { io.out(say('keys.badchars')); return { ok: false, written: [] }; }
    let passphrase = '';
    if (ex.passphrase) {
      passphrase = (await io.askSecret(say('keys.passphrase'))).trim();
      if (!PASSPHRASE_PATTERN.test(passphrase)) { io.out(say('keys.badpass')); return { ok: false, written: [] }; }
    }

    // the file: the existing one, or a fresh safe one made from the example; only the three lines below change
    let base = existing;
    if (!d.fs.existsSync(envPath)) base = d.fs.existsSync(examplePath) ? freshEnvText(readText(d.fs, examplePath)).text : '';
    const updates = { [ex.key]: key, [ex.secret]: secret, ...(ex.passphrase ? { [ex.passphrase]: passphrase } : {}) };
    if (ex.env && current !== environment) updates[ex.env] = environment;
    const done = setEnvValues(base, updates);
    const tmp = `${envPath}.${process.pid}.tmp`;
    d.fs.writeFileSync(tmp, done.text, { mode: 0o600 });
    d.fs.renameSync(tmp, envPath);
    try { d.fs.chmodSync(envPath, 0o600); } catch { /* not supported on this system */ }

    io.out(say('keys.saved', { names: [ex.key, ex.secret, ...(ex.passphrase ? [ex.passphrase] : [])].join(', ') }));
    if (ex.env && updates[ex.env]) io.out(say('keys.env.set', { line: `${ex.env}=${environment}` }));
    io.out(say('keys.noflags'));
    if (ex.advice) io.out(say(ex.advice)); // advice about the key's rights, never about its value

    // apply: the server reads .env only when it starts
    const service = d.service ?? createService({ root: d.root, log: () => undefined });
    const running = (await service.status().catch(() => null))?.managedProcessRunning === true;
    if (running) {
      const yes = options.restart ?? !/^n/i.test((await io.ask(say('keys.restart.ask'))).trim());
      if (yes) { await service.restart(); io.out(say('keys.restart.done')); return { ok: true, exchange: id, written: Object.keys(updates), restarted: true }; }
    }
    io.out(say('keys.restart.manual'));
    return { ok: true, exchange: id, written: Object.keys(updates), restarted: false };
  } catch (error) {
    io.out(error instanceof Error && error.message === 'cancelled' ? say('keys.cancel') : `${say('fail.title', { reason: 'unexpected error' })}`);
    return { ok: false, written: [] };
  }
}

/** The chat helper's keys: a free key (or several) of Gemini, Groq or Cerebras into the matching variable. No secret prompt, no environment, no trading flag. */
async function runHelperKeys(options, d, say, envPath, examplePath) {
  const { io } = d;
  io.out(say('keys.helper.intro'));
  let pid = options.provider?.toLowerCase();
  if (!pid) {
    io.out(say('keys.helper.which'));
    pid = { 1: 'gemini', 2: 'groq', 3: 'cerebras' }[(await io.ask(say('keys.choice'))).trim()];
  }
  const pv = HELPER_PROVIDERS[pid];
  if (!pv) { io.out(say('keys.cancel')); return { ok: false, written: [] }; }
  io.out(say('keys.helper.where', { name: pv.name, where: pv.where }));
  const existing = readText(d.fs, envPath);
  const have = splitKeys(envValue(existing, pv.variable));
  let mode = 'replace';
  if (have.length) {
    io.out(say('keys.helper.have', { n: have.length, name: pv.name }));
    mode = (await io.ask(`${say('keys.choice')} [1]`)).trim() === '2' ? 'replace' : 'add';
  }
  const typed = splitKeys(await io.askSecret(say('keys.helper.key', { name: pv.name })));
  if (!typed.length || !typed.every(k => HELPER_KEY_PATTERN.test(k))) { io.out(say('keys.badchars')); return { ok: false, written: [] }; }
  const all = [...new Set(mode === 'add' ? [...have, ...typed] : typed)];

  let base = existing;
  if (!d.fs.existsSync(envPath)) base = d.fs.existsSync(examplePath) ? freshEnvText(readText(d.fs, examplePath)).text : '';
  const done = setEnvValues(base, { [pv.variable]: all.join(',') });
  const tmp = `${envPath}.${process.pid}.tmp`;
  d.fs.writeFileSync(tmp, done.text, { mode: 0o600 });
  d.fs.renameSync(tmp, envPath);
  try { d.fs.chmodSync(envPath, 0o600); } catch { /* not supported on this system */ }

  io.out(say('keys.helper.saved', { name: pv.variable, n: all.length }));
  io.out(say('keys.helper.privacy'));
  const service = d.service ?? createService({ root: d.root, log: () => undefined });
  const running = (await service.status().catch(() => null))?.managedProcessRunning === true;
  if (running) {
    const yes = options.restart ?? !/^n/i.test((await io.ask(say('keys.restart.ask'))).trim());
    if (yes) { await service.restart(); io.out(say('keys.restart.done')); return { ok: true, exchange: 'helper', provider: pid, written: [pv.variable], restarted: true }; }
  }
  io.out(say('keys.restart.manual'));
  return { ok: true, exchange: 'helper', provider: pid, written: [pv.variable], restarted: false };
}

function readText(fs, path) { try { return fs.readFileSync(path, 'utf8'); } catch { return ''; } }

if (isMain(import.meta.url)) {
  const options = parseKeysArgs(process.argv.slice(2));
  if (options.unknown.length) { console.error('Usage: node scripts/setup_keys.mjs [--exchange binance|binance-testnet|bybit|okx|gate | --helper [gemini|groq|cerebras]] [--env testnet|demo|mainnet] [--restart|--no-restart] [--lang uk|en]'); process.exit(2); }
  runKeys(options).then(r => process.exit(r.ok ? 0 : 1));
}
