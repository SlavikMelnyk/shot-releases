// The one entry point behind the `shot` launcher that the installer writes (`<install>/shot` on macOS and Linux, `shot.cmd` on Windows):
//   shot [start|open|stop|restart|status|update|keys|doctor] [options of that command]
// Keeping the mapping here, in plain Node, means the two launchers are one line each (no batch-file argument juggling) and this part is tested.
import { spawn as nodeSpawn } from 'node:child_process';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { isMain } from './lib/main.mjs';

const HERE = dirname(fileURLToPath(import.meta.url));
/** command -> script and fixed leading arguments. `start` and `open` are the same thing: start CandleLab if it is not running, and show it in the browser. */
export const COMMANDS = Object.freeze({
  start: ['setup.mjs'], open: ['setup.mjs'], stop: ['service.mjs', 'stop'], status: ['service.mjs', 'status'], restart: ['service.mjs', 'restart'],
  update: ['update.mjs'], keys: ['setup_keys.mjs'], doctor: ['doctor.mjs'],
});
export const USAGE = `Usage: shot [${Object.keys(COMMANDS).join('|')}] [options]`;

/** The command line to run for `argv`, or null for an unknown command. No command means `start`. */
export function plan(argv, here = HERE) {
  const [command = 'start', ...rest] = argv;
  const entry = COMMANDS[command];
  return entry ? { script: join(here, entry[0]), args: [...entry.slice(1), ...rest] } : null;
}
export async function main(argv = process.argv.slice(2), { spawn = nodeSpawn, log = console.error, here = HERE, node = process.execPath } = {}) {
  const p = plan(argv, here);
  if (!p) { log(USAGE); return 2; }
  return new Promise(done => {
    const child = spawn(node, [p.script, ...p.args], { stdio: 'inherit', windowsHide: false });
    child.on('error', () => done(1));
    child.on('close', code => done(code ?? 1));
  });
}
if (isMain(import.meta.url)) main().then(code => process.exit(code), () => process.exit(1));
