// Keeps the local CandleLab service running independently of a terminal: start, stop, restart, status. Plain Node (no dependencies), macOS, Linux and Windows.
// A port of the former scripts/local_service.py with the same state file (data/local-service.json), log (data/server.log) and messages.
//   node scripts/service.mjs start|stop|restart|status [--port N]        (npm run app:up | app:down | app:status)
import { execFileSync, spawn as nodeSpawn } from 'node:child_process';
import nodeFs from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { envValue } from './lib/env.mjs';
import { isMain } from './lib/main.mjs';

export const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
export const DEFAULT_PORT = 3001;

// ---------------------------------------------------------------------------------------------- keeping the computer awake (docs/LAPTOP.md)
// While CandleLab runs, a small keeper asks the operating system not to fall asleep. It is tied to the server's pid and ends with it. It changes no system setting, needs no administrator, and
// is NOT a way around the lid: closing the lid of a laptop sleeps it whatever a program asks (see docs/LAPTOP.md).

/** The PowerShell that holds the «system required» state of Windows for as long as process `pid` lives. `0x80000001` is ES_CONTINUOUS | ES_SYSTEM_REQUIRED (written as a decimal UInt32: PowerShell reads a hex literal that big as a negative number). */
export function windowsKeeperScript(pid) {
  if (!Number.isInteger(pid) || pid <= 0) throw new Error('A process id is required.');
  return [
    '$ErrorActionPreference = "Stop"',
    "Add-Type -Namespace Shot -Name Power -MemberDefinition '[DllImport(\"kernel32.dll\")] public static extern uint SetThreadExecutionState(uint esFlags);'",
    '[void][Shot.Power]::SetThreadExecutionState([uint32]2147483649)',
    `while (Get-Process -Id ${pid} -ErrorAction SilentlyContinue) { Start-Sleep -Seconds 5 }`,
  ].join('\n');
}
/** `-EncodedCommand` takes the script as base64 of UTF-16LE: no quoting problems whatever the path or the shell. */
export const encodePowerShell = script => Buffer.from(script, 'utf16le').toString('base64');

/**
 * The command that keeps the computer awake while process `pid` lives, or null when this system has no way without extra tools.
 *   macOS    caffeinate -i -s -w <pid>   -i: no idle sleep (on battery too); -s: no system sleep, but ONLY on AC power (man caffeinate); -w: end when the process ends
 *   Linux    systemd-inhibit --what=sleep:idle … (waits for the pid)
 *   Windows  a hidden PowerShell holding SetThreadExecutionState(ES_CONTINUOUS | ES_SYSTEM_REQUIRED)
 * `tools` says what exists on this machine: { caffeinate, inhibit, powershell } as paths/names or falsy.
 */
export function keepAwakeSpec(platform, pid, tools = {}) {
  if (platform === 'darwin') return tools.caffeinate ? { method: 'caffeinate', command: tools.caffeinate, args: ['-i', '-s', '-w', String(pid)] } : null;
  if (platform === 'linux') {
    return tools.inhibit ? { method: 'systemd-inhibit', command: tools.inhibit, args: ['--what=sleep:idle', '--who=CandleLab', '--why=CandleLab is running and looking after open positions', '--mode=block', 'sh', '-c', 'while kill -0 "$1" 2>/dev/null; do sleep 5; done', 'sh', String(pid)] } : null;
  }
  if (platform === 'win32') {
    return tools.powershell ? { method: 'powershell', command: tools.powershell, args: ['-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-EncodedCommand', encodePowerShell(windowsKeeperScript(pid))] } : null;
  }
  return null;
}

/** The first directory of PATH that holds `name` (and `name.exe` on Windows), or null. */
export function findOnPath(name, { env = process.env, exists = nodeFs.existsSync, platform = process.platform } = {}) {
  const sep = platform === 'win32' ? ';' : ':';
  for (const dir of String(env.PATH ?? env.Path ?? '').split(sep).filter(Boolean)) {
    for (const file of platform === 'win32' ? [`${name}.exe`, name] : [name]) { const full = join(dir, file); if (exists(full)) return full; }
  }
  return null;
}

/** Exit codes of the supervised run (docs/LAPTOP.md): 0 = do not restart me (a normal stop, or a problem a restart cannot fix); anything else = the supervisor restarts me. */
export const EXIT_CORRUPT_DB = 78;
export function runExitCode({ code, stopRequested }) {
  if (stopRequested) return 0;
  if (code === 0) return 0;
  if (code === EXIT_CORRUPT_DB) return 0; // a corrupt database: restarting in a loop would only print the same message
  return 1; // a crash, a kill, a failed stop: the job restarts it
}

/** Port to use: `--port`, then the PORT environment variable, then PORT in `.env`, then 3001. The server accepts 1024-65535 only. */
export function resolvePort({ cli, env = {}, envFileText = '' } = {}) {
  const raw = cli ?? env.PORT ?? envValue(envFileText, 'PORT') ?? String(DEFAULT_PORT);
  const port = Number(raw);
  if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error(`Invalid port "${String(raw).slice(0, 12)}": use a number from 1024 to 65535.`);
  return port;
}

/** The command line of a process, or null when no such process exists (or it cannot be read). `ps` on macOS and Linux, PowerShell on Windows. */
export function commandOfProcess(pid, platform = process.platform) {
  if (!Number.isInteger(pid) || pid <= 0) return null;
  try {
    if (platform === 'win32') {
      const out = execFileSync('powershell', ['-NoProfile', '-NonInteractive', '-Command', `(Get-CimInstance Win32_Process -Filter "ProcessId=${pid}").CommandLine`], { encoding: 'utf8', timeout: 10_000, windowsHide: true, stdio: ['ignore', 'pipe', 'ignore'] });
      return out.trim() || null;
    }
    const out = execFileSync('ps', ['-p', String(pid), '-o', 'command='], { encoding: 'utf8', timeout: 5000, stdio: ['ignore', 'pipe', 'ignore'] });
    return out.trim() || null;
  } catch { return null; }
}

async function healthy(port) {
  try {
    const response = await fetch(`http://127.0.0.1:${port}/api/health`, { signal: AbortSignal.timeout(2000) });
    return Boolean((await response.json()).ok);
  } catch { return false; }
}

/** Builds the service manager. Everything that touches the outside world can be replaced (tests inject a fake child, fake health and a temp directory). */
export function createService(overrides = {}) {
  const d = {
    root: ROOT, fs: nodeFs, spawn: nodeSpawn, platform: process.platform, nodePath: process.execPath, env: process.env, log: console.log,
    sleep: ms => new Promise(done => setTimeout(done, ms)), health: healthy, commandOf: pid => commandOfProcess(pid, overrides.platform ?? process.platform),
    kill: (pid, signal) => process.kill(pid, signal), tries: 30, stopTries: 40, interval: 500, caffeinate: '/usr/bin/caffeinate', now: Date.now,
    onSignal: (signal, handler) => process.on(signal, handler),
    which: name => findOnPath(name, { env: overrides.env ?? process.env, platform: overrides.platform ?? process.platform }),
    ...overrides,
  };
  const stateFile = join(d.root, 'data', 'local-service.json'), entry = join(d.root, 'dist', 'server', 'index.js'), logFile = join(d.root, 'data', 'server.log');
  const readText = path => { try { return d.fs.readFileSync(path, 'utf8'); } catch { return ''; } };
  const readState = () => {
    try { const s = JSON.parse(readText(stateFile)); return s && Number.isInteger(s.pid) ? s : null; } catch { return null; }
  };
  const envPort = cli => resolvePort({ cli, env: d.env, envFileText: readText(join(d.root, '.env')) });
  const urlOf = port => `http://127.0.0.1:${port}`;
  /** A process counts as ours only when it is alive and its command line contains our entry file: a recycled pid is never signalled. */
  const owned = state => {
    if (!state) return false;
    const command = d.commandOf(state.pid);
    return typeof command === 'string' && command.includes(entry);
  };

  /** Starts the keep-awake keeper for the server `pid` (see keepAwakeSpec). Returns { method, pid } for the state file, or null when this system has none. Never throws: a missing keeper is only a warning in the doctor. */
  function startKeeper(pid) {
    try {
      const tools = d.platform === 'darwin' ? { caffeinate: d.fs.existsSync(d.caffeinate) ? d.caffeinate : null } : d.platform === 'linux' ? { inhibit: d.which('systemd-inhibit') } : d.platform === 'win32' ? { powershell: d.which('powershell') ?? 'powershell' } : {};
      const spec = keepAwakeSpec(d.platform, pid, tools);
      if (!spec) return null;
      const keeper = d.spawn(spec.command, spec.args, { stdio: 'ignore', detached: true, windowsHide: true });
      keeper.on?.('error', () => undefined);
      keeper.unref?.();
      return Number.isInteger(keeper.pid) ? { method: spec.method, pid: keeper.pid } : null;
    } catch { return null; }
  }
  /** When «follow main» is on (scripts/follow.mjs), a start also makes sure its watcher is alive. Nothing happens without data/follow.json saying `enabled`. */
  function ensureFollower() {
    try {
      const f = JSON.parse(readText(join(d.root, 'data', 'follow.json')) || '{}'), script = join(d.root, 'scripts', 'follow.mjs');
      if (!f.enabled || !d.fs.existsSync(script)) return;
      const child = d.spawn(d.nodePath, [script, 'ensure'], { cwd: d.root, stdio: 'ignore', detached: true, windowsHide: true });
      child.on?.('error', () => undefined);
      child.unref?.();
    } catch { /* the watcher is a convenience */ }
  }
  const writeState = patch => { const s = readState() ?? {}; d.fs.writeFileSync(stateFile, JSON.stringify({ ...s, ...patch })); };

  async function status(opts = {}) {
    const state = readState(), port = opts.port ?? state?.port ?? envPort();
    const result = { managedProcessRunning: owned(state), dashboardResponding: await d.health(port), url: urlOf(port) };
    return result;
  }

  async function start(opts = {}) {
    const state = readState(), port = opts.port ?? envPort();
    if (await d.health(port)) { d.log(`CandleLab already responds at ${urlOf(port)}`); return { started: false, already: true, port, url: urlOf(port) }; }
    if (owned(state)) throw new Error('CandleLab process exists but does not respond. Inspect data/server.log.');
    if (!d.fs.existsSync(entry)) throw new Error('Run npm run build first.');
    d.fs.mkdirSync(dirname(stateFile), { recursive: true });
    const fd = d.fs.openSync(logFile, 'a');
    let child;
    try {
      child = d.spawn(d.nodePath, ['--env-file-if-exists=.env', entry], { cwd: d.root, stdio: ['ignore', fd, fd], detached: true, windowsHide: true, env: { ...d.env, PORT: String(port) } });
    } finally { d.fs.closeSync(fd); }
    let exited = false;
    child.on?.('exit', () => { exited = true; });
    child.on?.('error', () => { exited = true; });
    if (!Number.isInteger(child.pid)) throw new Error('CandleLab exited. Inspect data/server.log.');
    child.unref?.();
    const keeper = startKeeper(child.pid);
    d.fs.writeFileSync(stateFile, JSON.stringify({ pid: child.pid, startedAt: d.now(), entry, port, ...(keeper ? { keepAwake: keeper } : {}) }));
    for (let i = 0; i < d.tries; i++) {
      if (exited) throw new Error('CandleLab exited. Inspect data/server.log.');
      if (await d.health(port)) { ensureFollower(); d.log(`CandleLab running at ${urlOf(port)}; logs: data/server.log`); return { started: true, already: false, port, url: urlOf(port) }; }
      await d.sleep(d.interval);
    }
    throw new Error('CandleLab did not become ready. Inspect data/server.log.');
  }

  async function stop() {
    const state = readState();
    if (!owned(state)) {
      if (state) { try { d.fs.unlinkSync(stateFile); } catch { /* already gone */ } }
      d.log('No managed CandleLab process to stop.');
      return { stopped: false };
    }
    if (state.supervised) { try { writeState({ stopRequested: 'stop' }); } catch { /* the supervisor then sees an ordinary exit */ } } // the supervised run (below) must not treat this as a crash
    d.kill(state.pid, 'SIGTERM');
    for (let i = 0; i < d.stopTries; i++) {
      if (!owned(state)) {
        try { d.fs.unlinkSync(stateFile); } catch { /* already gone */ }
        d.log('CandleLab stopped. Paper sessions will resume on the next start.');
        return { stopped: true };
      }
      await d.sleep(d.interval);
    }
    throw new Error('CandleLab has not exited yet. No unrelated process was terminated.');
  }

  async function restart(opts = {}) {
    const state = readState();
    if (state?.supervised && owned(state)) {
      // Run under the autostart supervisor: it relaunches the server itself when asked, so supervision is not lost. Ask, then wait for the NEW process to answer.
      const port = opts.port ?? state.port ?? envPort();
      writeState({ stopRequested: 'restart' });
      d.kill(state.pid, 'SIGTERM');
      for (let i = 0; i < d.tries + d.stopTries; i++) {
        await d.sleep(d.interval);
        const now = readState();
        if (now && now.pid !== state.pid && owned(now) && await d.health(port)) { d.log(`CandleLab running at ${urlOf(port)}; logs: data/server.log`); return { started: true, already: false, port, url: urlOf(port) }; }
      }
      throw new Error('CandleLab did not come back. Inspect data/server.log.');
    }
    await stop();
    return start({ ...opts, port: opts.port ?? state?.port });
  }

  /**
   * The supervised run (`node scripts/service.mjs run`): the server is a CHILD of this process, which stays in the foreground so that the autostart job (launchd, systemd, Task Scheduler) can watch it.
   * A normal stop (npm run app:down, a signal to this process) and a corrupt database end with exit code 0, so nothing restarts CandleLab in a loop; a crash ends with 1, and the job restarts it. `npm run app:restart`
   * is handled here: the server is started again without leaving. Returns the exit code.
   */
  async function run(opts = {}) {
    const port = opts.port ?? envPort();
    if (await d.health(port)) { d.log(`CandleLab already responds at ${urlOf(port)}; nothing to supervise.`); return 0; }
    if (!d.fs.existsSync(entry)) throw new Error('Run npm run build first.');
    d.fs.mkdirSync(dirname(stateFile), { recursive: true });
    let stopping = false, current = null;
    const forward = () => { stopping = true; try { current?.kill?.('SIGTERM'); } catch { /* already gone */ } };
    for (const signal of ['SIGTERM', 'SIGINT', 'SIGHUP']) d.onSignal(signal, forward);
    ensureFollower();
    for (;;) {
      const fd = d.fs.openSync(logFile, 'a');
      let child;
      try {
        child = d.spawn(d.nodePath, ['--env-file-if-exists=.env', entry], { cwd: d.root, stdio: ['ignore', fd, fd], windowsHide: true, env: { ...d.env, PORT: String(port) } });
      } finally { d.fs.closeSync(fd); }
      current = child;
      const exited = new Promise(done => { child.on?.('exit', (code, signal) => done({ code, signal })); child.on?.('error', () => done({ code: 1, signal: null })); });
      if (!Number.isInteger(child.pid)) throw new Error('CandleLab exited. Inspect data/server.log.');
      const keeper = startKeeper(child.pid);
      d.fs.writeFileSync(stateFile, JSON.stringify({ pid: child.pid, startedAt: d.now(), entry, port, supervised: true, ...(keeper ? { keepAwake: keeper } : {}) }));
      if (stopping) forward();
      const { code, signal } = await exited;
      const marker = readState()?.stopRequested ?? null;
      d.log(`CandleLab ended (${signal ?? `code ${code}`})${marker ? `, requested: ${marker}` : ''}.`);
      if (marker === 'restart' && !stopping) continue; // app:restart: the same job starts the server again
      try { d.fs.unlinkSync(stateFile); } catch { /* already gone */ }
      return runExitCode({ code, stopRequested: marker === 'stop' || stopping });
    }
  }

  return { status, start, stop, restart, run, paths: { stateFile, entry, logFile } };
}

/** `--port N` / `--port=N` anywhere in the arguments. */
export function parseArgs(argv) {
  const out = { command: 'status', port: undefined };
  const rest = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--port') out.port = argv[++i];
    else if (a.startsWith('--port=')) out.port = a.slice(7);
    else rest.push(a);
  }
  if (rest[0]) out.command = rest[0];
  return out;
}

export async function main(argv = process.argv.slice(2), overrides = {}) {
  const { command, port } = parseArgs(argv);
  const service = createService(overrides);
  const opts = port === undefined ? {} : { port: resolvePort({ cli: port }) };
  if (command === 'status') console.log(JSON.stringify(await service.status(opts), null, 2));
  else if (command === 'start') await service.start(opts);
  else if (command === 'stop') await service.stop();
  else if (command === 'restart') await service.restart(opts);
  else if (command === 'run') process.exitCode = await service.run(opts);
  else throw new Error('Use start, stop, restart, run or status.');
}

if (isMain(import.meta.url)) {
  main().catch(error => { console.error(`Error: ${error instanceof Error ? error.message : String(error)}`); process.exit(1); });
}
