// One command to install and start CandleLab on macOS, Linux and Windows:   node scripts/setup.mjs
// Checks Node.js, installs the dependencies, creates a SAFE .env (only if there is none), builds, starts the service in the background,
// waits until it answers and opens the browser. Safe to run again: every step that has nothing to do says so and takes no time.
// Plain Node, no dependencies (it runs before `npm ci`). Nothing is installed on the system outside this folder; a missing Node gets a printed hint.
// In an installed release (a `VERSION` file and no source) the dependencies and the build are part of the folder: those two steps are skipped and the rest is the same.
// Python is not needed (the candle downloader is part of the app); it is only used by the research scripts of a source checkout.
import { spawn as nodeSpawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import nodeFs from 'node:fs';
import { dirname, join, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { freshEnvText } from './lib/env.mjs';
import { isMain } from './lib/main.mjs';
import { msg, pickLang } from './lib/messages.mjs';
import { installHint, nodeStatus, osOf } from './lib/runtime.mjs';
import { createService, DEFAULT_PORT, resolvePort } from './service.mjs';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const TOTAL = 6;
/** What the build reads. A change in any of these (size or modification time) means the app has to be built again. */
const BUILD_INPUTS = ['server', 'shared', 'src', 'landing', 'public', 'index.html', 'vite.config.ts', 'tsconfig.json', 'tsconfig.server.json', 'package.json', 'package-lock.json'];
const SKIP_DIRS = new Set(['node_modules', '.git', 'dist', 'data']);

/** Arguments of the command. Unknown ones are reported, not ignored. */
export function parseSetupArgs(argv) {
  const out = { open: true, start: true, check: false, help: false, port: undefined, lang: undefined, unknown: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--no-open') out.open = false;
    else if (a === '--no-start') out.start = false;
    else if (a === '--check') out.check = true;
    else if (a === '--help' || a === '-h') out.help = true;
    else if (a === '--port') out.port = argv[++i];
    else if (a.startsWith('--port=')) out.port = a.slice(7);
    else if (a === '--lang') out.lang = argv[++i];
    else if (a.startsWith('--lang=')) out.lang = a.slice(7);
    else out.unknown.push(a);
  }
  return out;
}

const sha = data => createHash('sha256').update(data).digest('hex');

/** A cheap fingerprint of the files the build reads: path, size and modification time of each (no contents), so "nothing changed" is decided in milliseconds. */
export function treeFingerprint(root, fs = nodeFs, inputs = BUILD_INPUTS) {
  const hash = createHash('sha256');
  const walk = path => {
    let stat;
    try { stat = fs.statSync(path); } catch { return; }
    if (stat.isDirectory()) {
      for (const name of fs.readdirSync(path).sort()) if (!SKIP_DIRS.has(name)) walk(join(path, name));
    } else hash.update(`${relative(root, path)}:${stat.size}:${Math.floor(stat.mtimeMs)}\n`);
  };
  for (const input of inputs) walk(join(root, input));
  return hash.digest('hex');
}

/** True in an installed release: it carries its dependencies and its build and has no source to build (scripts/release.mjs, docs/DISTRIBUTION.md). */
export function isPackaged(root, fs = nodeFs) {
  return fs.existsSync(join(root, 'VERSION')) && fs.existsSync(join(root, 'dist', 'server', 'index.js')) && !fs.existsSync(join(root, 'vite.config.ts'));
}
/** Runs a command with its output on this terminal (npm). Resolves with the exit code. */
export function visible(command, args, { cwd, shell = false } = {}) {
  return new Promise((done, fail) => {
    let child;
    try { child = nodeSpawn(command, args, { cwd, shell, stdio: 'inherit', windowsHide: false }); } catch (error) { fail(error); return; }
    child.on('error', fail);
    child.on('close', code => done(code ?? 1));
  });
}

/** Opens a page in the default browser. Never throws; returns whether a launcher was started. */
export function openBrowser(url, { platform = process.platform, env = process.env, spawn = nodeSpawn } = {}) {
  try {
    let command, args;
    if (platform === 'darwin') { command = 'open'; args = [url]; }
    else if (platform === 'win32') { command = 'cmd'; args = ['/c', 'start', '""', url]; }
    else {
      if (!env.DISPLAY && !env.WAYLAND_DISPLAY) return false; // no desktop session (a server): the URL is printed instead
      command = 'xdg-open'; args = [url];
    }
    const child = spawn(command, args, { stdio: 'ignore', detached: true, windowsHide: true });
    child.on?.('error', () => undefined);
    child.unref?.();
    return true;
  } catch { return false; }
}

class SetupFailure extends Error {}

/**
 * The whole flow. Every outside effect is injected: `fs`, `visible` (processes), `service` (start), `open`, `log`. Returns `{ ok, port, url, steps }`.
 * `options.check` only reports; it installs, writes and starts nothing.
 */
export async function runSetup(options = {}, deps = {}) {
  const d = {
    root: ROOT, fs: nodeFs, platform: process.platform, nodeVersion: process.version, env: process.env, visible, open: openBrowser, log: console.log,
    service: undefined, ...deps,
  };
  const lang = options.lang === 'uk' || options.lang === 'en' ? options.lang : pickLang(d.env, safeLocale());
  const os = osOf(d.platform), win = d.platform === 'win32';
  const say = (key, vars) => msg(lang, key, vars);
  const steps = [];
  let current = 0;
  const begin = key => { current++; d.log(`[${current}/${TOTAL}] ${say(key)}`); };
  const ok = (text) => d.log(`      + ${text}`);
  const warn = text => d.log(`      ! ${text}`);
  const info = text => d.log(`      - ${text}`);
  const lines = list => list.forEach(l => d.log(`        ${l}`));
  const record = (id, status, extra = {}) => steps.push({ id, status, ...extra });
  const npmCommand = win ? 'npm.cmd' : 'npm';
  const npmOpts = { cwd: d.root, shell: win }; // .cmd files need a shell on Windows; the arguments below are fixed strings

  let port;
  try {
    port = resolvePort({ cli: options.port, env: d.env, envFileText: readText(d.fs, join(d.root, '.env')) });
  } catch (error) { d.log(say('fail.title', { reason: error.message })); return { ok: false, steps }; }
  const url = `http://127.0.0.1:${port}/app/`;

  d.log(`CandleLab: ${say(options.check ? 'check.title' : 'setup.title')}\n`);
  try {
    // 1. tools
    begin('step.tools');
    const node = nodeStatus(d.nodeVersion);
    if (!node.ok) {
      d.log(`      x ${node.version ? say('tools.node.old', { version: node.version }) : say('tools.node.none')}`);
      lines(installHint('node', os, lang));
      record('tools', 'failed', { node: node.version });
      throw new SetupFailure(node.version ? say('tools.node.old', { version: node.version }) : say('tools.node.none'));
    }
    ok(say('tools.node.ok', { version: node.version }));
    if (node.tooNew) warn(say('tools.node.new', { version: node.version }));
    record('tools', 'ok', { node: node.version });
    const packaged = isPackaged(d.root, d.fs);

    // 2. dependencies
    begin('step.install');
    const nodeModules = join(d.root, 'node_modules'), stampFile = join(nodeModules, '.shot-install.json');
    const lockPath = join(d.root, 'package-lock.json'), hasLock = d.fs.existsSync(lockPath);
    const depsHash = sha(`${hasLock ? readText(d.fs, lockPath) : ''}\n${readText(d.fs, join(d.root, 'package.json'))}`);
    const hasModules = d.fs.existsSync(nodeModules);
    const stamp = readJson(d.fs, stampFile);
    if (packaged) { info(say('install.packaged')); record('install', 'skipped'); }
    else if (hasModules && stamp?.hash === depsHash) { info(say('install.skip')); record('install', 'skipped'); }
    else if (options.check) { info(hasModules ? 'node_modules: needs an update' : 'node_modules: missing'); record('install', 'pending'); }
    else {
      // A clean folder gets the exact lockfile (npm ci). An existing node_modules is updated in place (npm install), never wiped.
      const sub = !hasModules && hasLock ? 'ci' : 'install';
      info(say('install.run', { command: `npm ${sub}` }));
      const code = await d.visible(npmCommand, [sub], npmOpts).catch(() => null);
      if (code === null) throw new SetupFailure(say('tools.npm.none'));
      if (code !== 0) throw new SetupFailure(say('fail.exit', { command: `npm ${sub}`, code }));
      d.fs.mkdirSync(nodeModules, { recursive: true });
      d.fs.writeFileSync(stampFile, JSON.stringify({ hash: depsHash, at: new Date().toISOString() }));
      ok(say('install.done')); record('install', 'done');
    }

    // 3. .env (created only when it does not exist; an existing file is never read for values or changed here)
    begin('step.env');
    const envPath = join(d.root, '.env'), examplePath = join(d.root, '.env.example');
    if (d.fs.existsSync(envPath)) { info(say('env.exists')); record('env', 'skipped'); }
    else if (options.check) { info('.env: missing'); record('env', 'pending'); }
    else {
      const hasExample = d.fs.existsSync(examplePath);
      const fresh = hasExample ? freshEnvText(readText(d.fs, examplePath)) : { text: 'BINANCE_ENV=testnet\nENABLE_ORDER_EXECUTION=false\nENABLE_LIVE_TRADING=false\n', corrected: [] };
      d.fs.writeFileSync(envPath, fresh.text, { mode: 0o600, flag: 'wx' }); // 'wx': fails rather than overwrite, even if the file appeared a moment ago
      ok(say(hasExample ? 'env.created' : 'env.noexample'));
      if (fresh.corrected.length) warn(say('env.fixed', { keys: fresh.corrected.join(', ') }));
      record('env', 'created');
    }

    // 4. build
    begin('step.build');
    const outputs = [join(d.root, 'dist', 'server', 'index.js'), join(d.root, 'dist', 'client', 'index.html')];
    const builtFile = join(d.root, 'dist', '.shot-build.json');
    const fingerprint = treeFingerprint(d.root, d.fs);
    const built = outputs.every(p => d.fs.existsSync(p)) && readJson(d.fs, builtFile)?.fingerprint === fingerprint;
    if (packaged) { info(say('build.packaged')); record('build', 'skipped'); }
    else if (built) { info(say('build.skip')); record('build', 'skipped'); }
    else if (options.check) { info('dist: needs a build'); record('build', 'pending'); }
    else {
      info(say('build.run'));
      const code = await d.visible(npmCommand, ['run', 'build:app'], npmOpts).catch(() => null);
      if (code === null) throw new SetupFailure(say('tools.npm.none'));
      if (code !== 0) throw new SetupFailure(say('fail.exit', { command: 'npm run build:app', code }));
      d.fs.mkdirSync(join(d.root, 'dist'), { recursive: true });
      d.fs.writeFileSync(builtFile, JSON.stringify({ fingerprint, at: new Date().toISOString() }));
      ok(say('build.done')); record('build', 'done');
    }

    // 5. start
    begin('step.start');
    if (options.check) { info('-'); record('start', 'pending'); }
    else if (options.start === false) { info(say('start.skip')); record('start', 'skipped'); }
    else {
      const service = d.service ?? createService({ root: d.root, log: () => undefined });
      const result = await service.start({ port });
      ok(say(result.already ? 'start.already' : 'start.ok', { url }));
      record('start', result.already ? 'already' : 'done');
    }

    // 6. browser
    begin('step.open');
    if (options.check || options.start === false) { info(say('open.manual', { url })); record('open', 'skipped'); }
    else if (options.open === false) { info(say('open.skip', { url })); record('open', 'skipped'); }
    else if (d.open(url, { platform: d.platform, env: d.env })) { ok(say('open.done', { url })); record('open', 'done'); }
    else { info(say('open.manual', { url })); record('open', 'manual'); }

    d.log(`\n${say('done.title')} ${url}`);
    if (!options.check) { d.log(say('done.wizard')); d.log(say('done.next')); }
    return { ok: true, port, url, steps };
  } catch (error) {
    const reason = error instanceof Error ? error.message : String(error);
    d.log(`\n${say('fail.title', { reason })}`);
    d.log(say('fail.again'));
    return { ok: false, port, url, steps, error: reason };
  }
}

function safeLocale() { try { return Intl.DateTimeFormat().resolvedOptions().locale; } catch { return ''; } }
function readText(fs, path) { try { return fs.readFileSync(path, 'utf8'); } catch { return ''; } }
function readJson(fs, path) { try { return JSON.parse(readText(fs, path)); } catch { return null; } }

export async function main(argv = process.argv.slice(2)) {
  const options = parseSetupArgs(argv);
  const lang = options.lang === 'uk' || options.lang === 'en' ? options.lang : pickLang(process.env, safeLocale());
  if (options.help) { console.log(msg(lang, 'help')); return 0; }
  if (options.unknown.length) { console.error(`${msg(lang, 'help')}\n(?) ${options.unknown.join(' ').slice(0, 80)}`); return 2; }
  const result = await runSetup(options);
  return result.ok ? 0 : 1;
}

if (isMain(import.meta.url)) {
  main().then(code => process.exit(code), error => { console.error(error); process.exit(1); });
}
export { DEFAULT_PORT };
