// `npm run doctor`: reads the facts about power, sleep, the lid, the clock, the network and the disk of THIS computer and prints a green / amber / red list with the exact fix (docs/LAPTOP.md).
// It changes nothing. The checks live in server/health/ (also used by the panel «Стан комп'ютера»); this file only finds a way to run them:
// the built app (dist/) when it exists, otherwise the TypeScript sources through tsx (a development checkout).
//   node scripts/doctor.mjs [--lang uk|en] [--json]
import { spawnSync } from 'node:child_process';
import nodeFs from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

export const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');

/** How to run the doctor: the built file, the sources through tsx, or nothing (say what to do). */
export function plan({ root = ROOT, exists = nodeFs.existsSync, nodePath = process.execPath, args = [] } = {}) {
  const built = join(root, 'dist', 'server', 'health', 'doctorCli.js'), source = join(root, 'server', 'health', 'doctorCli.ts'), tsx = join(root, 'node_modules', 'tsx');
  if (exists(built)) return { command: nodePath, args: ['--env-file-if-exists=.env', built, ...args], cwd: root };
  if (exists(source) && exists(tsx)) return { command: nodePath, args: ['--env-file-if-exists=.env', '--import', 'tsx', source, ...args], cwd: root };
  return null;
}

export function main(argv = process.argv.slice(2), { spawn = spawnSync, log = console.error, ...rest } = {}) {
  const p = plan({ ...rest, args: argv });
  if (!p) { log('The doctor needs the built app. Run: node scripts/setup.mjs (or npm run build:app)  ·  Лікарю потрібна зібрана програма. Виконайте: node scripts/setup.mjs (або npm run build:app)'); return 2; }
  const r = spawn(p.command, p.args, { cwd: p.cwd, stdio: 'inherit' });
  return typeof r.status === 'number' ? r.status : 2;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) process.exitCode = main();
