// Updates an installed CandleLab in place:   npm run update     (or:  <install folder>/shot update)
// The same verified update the installer does (scripts/lib/installer-core.mjs): it reads the newest release list from the address in config/release.public.json (or SHOT_DIST_URL),
// checks its signature with the release key built into this copy, checks the archive's SHA-256, stops CandleLab, replaces the app files and starts it again. Your data and settings
// (`data/`, `.env`, `runtime/`) are never touched. It sends nothing but plain GET requests for the release list, its signature and the archive.
//   node scripts/update.mjs [--check] [--force] [--dry-run] [--no-start] [--no-open] [--base URL] [--lang uk|en]
import nodeFs from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

import { isMain } from './lib/main.mjs';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');

/** The shared installer core: shipped as lib/installer-core.mjs in a release, scripts/installer/core.mjs in the source repo. */
async function loadCore(here = dirname(fileURLToPath(import.meta.url)), fs = nodeFs) {
  for (const rel of ['lib/installer-core.mjs', 'installer/core.mjs']) if (fs.existsSync(join(here, rel))) return import(pathToFileURL(join(here, rel)).href);
  throw new Error('scripts/lib/installer-core.mjs is missing: reinstall CandleLab.');
}
export function readReleaseConfig(root = ROOT, fs = nodeFs) {
  try { const c = JSON.parse(fs.readFileSync(join(root, 'config', 'release.public.json'), 'utf8')); return c && typeof c === 'object' ? c : {}; } catch { return {}; }
}
/** An installed release has a VERSION file and no source; anything else is a source checkout. */
export const isInstalledRelease = (root = ROOT, fs = nodeFs) => fs.existsSync(join(root, 'VERSION')) && !fs.existsSync(join(root, 'vite.config.ts'));

export function parseUpdateArgs(argv) {
  const out = { check: false, force: false, dryRun: false, start: true, open: true, base: undefined, lang: undefined, unknown: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i], eq = a.startsWith('--') ? a.indexOf('=') : -1, flag = eq > 0 ? a.slice(0, eq) : a, inline = eq > 0 ? a.slice(eq + 1) : undefined;
    if (flag === '--check') out.check = true; else if (flag === '--force') out.force = true; else if (flag === '--dry-run') out.dryRun = true; else if (flag === '--no-start') out.start = false;
    else if (flag === '--no-open') out.open = false; else if (flag === '--base') out.base = inline ?? argv[++i]; else if (flag === '--lang') out.lang = inline ?? argv[++i]; else out.unknown.push(a);
  }
  return out;
}

export async function main(argv = process.argv.slice(2), deps = {}) {
  const o = parseUpdateArgs(argv), log = deps.log ?? console.log, root = deps.root ?? ROOT, fs = deps.fs ?? nodeFs, env = deps.env ?? process.env;
  const core = deps.core ?? await loadCore(undefined, fs);
  const lang = o.lang === 'uk' || o.lang === 'en' ? o.lang : core.pickLang(env);
  if (o.unknown.length) { log(`Unknown option: ${o.unknown.join(' ').slice(0, 60)}\nUsage: node scripts/update.mjs [--check] [--force] [--dry-run] [--no-start] [--no-open] [--base URL] [--lang uk|en]`); return 2; }
  if (!isInstalledRelease(root, fs)) { log(core.say(lang, 'sourceCheckout')); return 0; }
  const config = readReleaseConfig(root, fs);
  const base = String(o.base ?? env.SHOT_DIST_URL ?? config.baseUrl ?? '').replace(/\/+$/, '');
  if (!base) { log(core.say(lang, 'noBase')); return 1; }
  const key = config.publicKey;
  if (o.check) {
    try {
      const r = await core.fetchRelease({ base, publicKey: key, fetch: deps.fetch });
      const current = core.installedVersion(root, fs) ?? '0.0.0';
      log(core.compareVersions(current, r.manifest.version) < 0 ? core.say(lang, 'checkNew', { current, latest: r.manifest.version, cmd: 'npm run update' }) : core.say(lang, 'checkSame', { current }));
      return 0;
    } catch (error) { log(core.say(lang, error.key ?? 'fail.net', error.vars ?? { url: base, reason: String(error?.message ?? error) })); return 1; }
  }
  const result = await core.runInstall({ dir: root, base, key, node: process.execPath, lang, force: o.force, dryRun: o.dryRun, start: o.start, open: o.open }, { log, fetch: deps.fetch, env, ...(deps.install ?? {}) });
  return result.ok ? 0 : 1;
}

if (isMain(import.meta.url)) {
  main().then(code => process.exit(code), error => { console.error(error?.message ?? error); process.exit(1); });
}
