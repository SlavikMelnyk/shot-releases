// Safe phone control for CandleLab (docs/MOBILE.md):
//   npm run remote:setup     checks Tailscale, publishes CandleLab on your PRIVATE tailnet (never the open internet), asks for a password (hidden), writes ONLY
//                            REMOTE_PASSWORD_HASH and REMOTE_HOSTS into .env, restarts CandleLab, prints the address and a QR code to open on the phone
//   npm run remote:status    is it on, which address, how many phone sessions
//   npm run remote:off       removes the two lines, turns off OUR Tailscale publication only, restarts
//   npm run remote:hash      only prints the REMOTE_PASSWORD_HASH line for a password (Docker or another machine); touches nothing
// Plain Node (the QR code uses the optional `uqr` package). Everything that touches the world (tailscale, files, the service, the terminal) is injectable for tests.
import { execFile } from 'node:child_process';
import nodeFs from 'node:fs';
import http from 'node:http';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { envValue, freshEnvText, setEnvValues } from './lib/env.mjs';
import { pickLang } from './lib/messages.mjs';
import * as R from './lib/remote.mjs';
import { rmsg } from './lib/remoteMessages.mjs';
import { osOf } from './lib/runtime.mjs';
import { createService, resolvePort } from './service.mjs';
import { createTerminalIo } from './setup_keys.mjs';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const TOTAL = 6;
const KEYS = ['REMOTE_PASSWORD_HASH', 'REMOTE_HOSTS'];

export function parseRemoteArgs(argv) {
  const out = { command: 'setup', port: undefined, httpsPort: undefined, lang: undefined, restart: true, help: false, unknown: [] };
  const rest = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i], [flag, inline] = a.startsWith('--') && a.includes('=') ? [a.slice(0, a.indexOf('=')), a.slice(a.indexOf('=') + 1)] : [a, undefined];
    const value = () => inline ?? argv[++i];
    if (flag === '--port') out.port = value();
    else if (flag === '--https-port') out.httpsPort = value();
    else if (flag === '--lang') out.lang = value();
    else if (flag === '--no-restart') out.restart = false;
    else if (flag === '--help' || flag === '-h') out.help = true;
    else if (a.startsWith('-')) out.unknown.push(a);
    else rest.push(a);
  }
  if (rest[0]) out.command = rest[0];
  if (rest.length > 1) out.unknown.push(...rest.slice(1));
  return out;
}

/** Runs a command and collects its output. Rejects when the command does not exist; a timeout still returns what was printed (`tailscale serve` waits for a person on a first run). */
export function capture(command, args, { env = {}, timeout = 25_000 } = {}) {
  return new Promise((done, fail) => {
    execFile(command, args, { env: { ...process.env, ...env }, timeout, windowsHide: true, maxBuffer: 1024 * 1024 }, (error, stdout, stderr) => {
      if (error && (error.code === 'ENOENT' || error.code === 'EACCES')) return fail(error);
      done({ code: error ? (typeof error.code === 'number' ? error.code : 1) : 0, stdout: String(stdout ?? ''), stderr: String(stderr ?? ''), timedOut: Boolean(error?.killed) });
    });
  });
}

/** One request to the local CandleLab with a chosen Host header (Node's fetch will not set it): resolves `{ status, code }` or null when nothing answers. */
export function probeHost({ port, host, path = '/api/session' }) {
  return new Promise(done => {
    const req = http.request({ host: '127.0.0.1', port, path, method: 'GET', headers: { Host: host }, timeout: 4000 }, res => {
      let body = '';
      res.on('data', c => { body += c; });
      res.on('end', () => { let code = null; try { code = JSON.parse(body).code ?? null; } catch { /* not JSON */ } done({ status: res.statusCode ?? 0, code }); });
    });
    req.on('error', () => done(null)); req.on('timeout', () => { req.destroy(); done(null); });
    req.end();
  });
}

const readText = (fs, path) => { try { return fs.readFileSync(path, 'utf8'); } catch { return ''; } };
/** Replaces the .env atomically (mode 0600), like `npm run keys`. */
function writeEnv(fs, path, text) {
  const tmp = `${path}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, text, { mode: 0o600 });
  fs.renameSync(tmp, path);
  try { fs.chmodSync(path, 0o600); } catch { /* not supported on this system */ }
}

function context(options, deps) {
  const d = { root: ROOT, fs: nodeFs, env: process.env, platform: process.platform, io: undefined, exec: capture, service: undefined, probe: probeHost, qr: R.renderQr, fetch: globalThis.fetch, ...deps };
  d.io ??= createTerminalIo();
  const lang = options.lang === 'uk' || options.lang === 'en' ? options.lang : pickLang(d.env, '');
  const say = (key, vars) => rmsg(lang, key, vars);
  const envPath = join(d.root, '.env'), examplePath = join(d.root, '.env.example');
  const envText = () => readText(d.fs, envPath);
  const step = (n, key) => d.io.out(`\n[${n}/${TOTAL}] ${say(key)}`);
  const service = () => d.service ?? createService({ root: d.root, log: () => undefined, env: d.env });
  return { d, lang, say, envPath, examplePath, envText, step, service };
}

async function locateTailscale(d) {
  for (const c of R.tailscaleCandidates(osOf(d.platform))) {
    try { const r = await d.exec(c.command, ['version'], { env: c.env }); if (r.code === 0) return c; } catch { /* not installed under this name */ }
  }
  return null;
}

/** Asks twice for the password with hidden input; up to three tries. Returns the password or null (nothing is written then). */
async function askPassword(c) {
  const { d, say } = c, { io } = d;
  io.out(say('pw.intro', { min: R.PASSWORD_MIN }));
  if (!io.tty) io.out(say('pw.tty'));
  for (let attempt = 0; attempt < 3; attempt++) {
    const first = await io.askSecret(say('pw.ask'));
    const verdict = R.checkNewPassword(first);
    if (!verdict.ok) { io.out(say(`pw.${verdict.reason}`, { min: R.PASSWORD_MIN, max: R.PASSWORD_MAX })); continue; }
    if ((await io.askSecret(say('pw.again'))) !== first) { io.out(say('pw.mismatch')); continue; }
    return first;
  }
  io.out(say('pw.giveup'));
  return null;
}

/** The whole `npm run remote:setup` flow. Returns `{ ok, url?, entry?, reason? }`; never returns, prints or logs the password. */
export async function runSetup(options = {}, deps = {}) {
  const c = context(options, deps), { d, say } = c, { io } = d;
  const fail = (reason, text) => { io.out(`\n${say('fail.title', { reason: text ?? reason })}\n${say('fail.again')}`); return { ok: false, reason }; };
  try {
    io.out(`CandleLab: ${say('title')}`);
    const httpsPort = options.httpsPort === undefined ? 443 : Number(options.httpsPort);
    if (!Number.isInteger(httpsPort) || httpsPort < 1 || httpsPort > 65535) return fail('https-port', `--https-port ${String(options.httpsPort).slice(0, 12)}`);
    const port = resolvePort({ cli: options.port, env: d.env, envFileText: c.envText() });

    // 1. Tailscale installed, signed in, running, with a name for this computer
    c.step(1, 'step.tailscale');
    const ts = await locateTailscale(d);
    if (!ts) { io.out(say('ts.none')); io.out(say(`ts.install.${osOf(d.platform)}`)); io.out(say('ts.install.after')); return { ok: false, reason: 'no-tailscale' }; }
    io.out(say('ts.found'));
    const status = R.parseTailscaleStatus((await d.exec(ts.command, ['status', '--json'], { env: ts.env }).catch(() => ({ stdout: '' }))).stdout);
    if (status.state !== 'running') return fail(`tailscale-${status.state}`, say(`ts.${status.state === 'needs-login' ? 'login' : status.state}`));
    if (!status.dnsName) return fail('no-dns-name', say('ts.noname'));
    if (status.certs === false) return fail('no-certs', say('ts.certs'));
    io.out(say('ts.name', { host: status.dnsName }));
    const entry = R.hostEntry(status.dnsName, httpsPort), portText = httpsPort === 443 ? '' : `:${httpsPort}`;

    // 2. publish our port on the tailnet (not the internet): only OUR https port is touched
    c.step(2, 'step.serve');
    const serveJson = (await d.exec(ts.command, ['serve', 'status', '--json'], { env: ts.env }).catch(() => ({ stdout: '' }))).stdout;
    const serving = R.serveState(serveJson, status.dnsName, httpsPort, port), exposure = R.exposureOf(serveJson, port);
    if (exposure.tcp) return fail('serve-tcp', say('serve.tcp', { local: port }));
    if (exposure.funnel) return fail('serve-funnel', say('serve.funnel', { https: httpsPort }));
    if (serving.busy) return fail('serve-busy', say('serve.busy', { https: httpsPort, other: String(serving.other).slice(0, 80) }));
    if (serving.ours) io.out(say('serve.already', { host: status.dnsName, port: portText, local: port }));
    else {
      const r = await d.exec(ts.command, R.serveArgs(port, httpsPort), { env: ts.env });
      if (r.code !== 0) {
        const output = `${r.stdout}\n${r.stderr}`, why = R.explainServeFailure(output);
        if (why.kind === 'not-enabled') return fail('serve-not-enabled', why.url ? say('serve.notEnabled', { url: why.url }) : say('serve.notEnabled.nourl'));
        if (why.kind === 'https-off') return fail('serve-https-off', say('serve.httpsOff'));
        return fail('serve-failed', say('serve.failed', { reason: output.trim().split(/\r?\n/)[0]?.slice(0, 200) || `exit ${r.code}` }));
      }
      io.out(say('serve.done', { host: status.dnsName, port: portText }));
    }

    // 3. the password (kept when one is already set and the person agrees)
    c.step(3, 'step.password');
    const existing = c.envText();
    let hash = envValue(existing, 'REMOTE_PASSWORD_HASH');
    if (hash && R.isPasswordHash(hash)) {
      const keep = (await io.ask(say('pw.keep'))).trim();
      if (/^n/i.test(keep)) hash = null;
    } else hash = null;
    if (!hash) {
      const password = await askPassword(c);
      if (password === null) return { ok: false, reason: 'no-password' };
      hash = await R.hashPassword(password);
    }

    // 4. .env: only the two lines
    c.step(4, 'step.env');
    let base = existing;
    if (!d.fs.existsSync(c.envPath)) base = d.fs.existsSync(c.examplePath) ? freshEnvText(readText(d.fs, c.examplePath)).text : '';
    const hosts = R.mergeHosts(envValue(base, 'REMOTE_HOSTS'), entry);
    writeEnv(d.fs, c.envPath, setEnvValues(base, { REMOTE_PASSWORD_HASH: hash, REMOTE_HOSTS: hosts }).text);
    io.out(say('env.saved', { hosts }));

    // 5. restart so the server reads it
    c.step(5, 'step.restart');
    if (options.restart === false) io.out(say('restart.manual'));
    else {
      try {
        const service = c.service(), st = await service.status({ port });
        if (st.managedProcessRunning) { await service.restart({ port }); io.out(say('restart.done')); }
        else if (st.dashboardResponding) io.out(say('restart.manual')); // running, but not started by app:up (for example npm run dev)
        else { await service.start({ port }); io.out(say('restart.started')); }
      } catch (error) { io.out(say('restart.failed', { reason: error instanceof Error ? error.message : 'unknown' })); }
    }

    // 6. prove that the door is locked: a request for the remote name without signing in must be refused, and the local address must still work
    c.step(6, 'step.check');
    const remote = await d.probe({ port, host: entry }), local = await d.probe({ port, host: `127.0.0.1:${port}` });
    if (!remote || !local) io.out(say('check.skip'));
    else if (remote.status === 401 && local.status === 200) io.out(say('check.ok', { host: entry }));
    else if (remote.status === 403) io.out(say('check.skip'));
    else io.out(say('check.bad', { host: entry, status: remote.status }));

    const url = R.urlOf(entry), appUrl = `${url}/app/`; // the app lives under /app (the root address is the landing page)
    io.out(`\n${say('done.title')}\n\n    ${appUrl}\n`);
    const qr = await d.qr(appUrl);
    if (qr) io.out(`${say('done.qr')}\n${qr}`);
    io.out(say('done.next')); io.out(say('done.awake'));
    return { ok: true, url, entry };
  } catch (error) {
    return fail('unexpected', error instanceof Error ? error.message.slice(0, 200) : 'unexpected error');
  }
}

/** `npm run remote:status`: reads .env (the two names, never the hash), asks the running CandleLab how many sessions there are, and asks Tailscale whether our port is published. */
export async function runStatus(options = {}, deps = {}) {
  const c = context(options, deps), { d, say } = c, { io } = d;
  io.out(`CandleLab: ${say('status.title')}`);
  const text = c.envText(), hash = envValue(text, 'REMOTE_PASSWORD_HASH'), hosts = (envValue(text, 'REMOTE_HOSTS') ?? '').split(',').map(s => s.trim()).filter(Boolean);
  const hasHash = Boolean(hash && R.isPasswordHash(hash));
  if (!hasHash && !hosts.length) { io.out(say('status.off')); return { on: false }; }
  if (hasHash && !hosts.length) { io.out(say('status.partial.hosts')); return { on: false, partial: 'hosts' }; }
  if (!hasHash) { io.out(say('status.partial.password')); return { on: false, partial: 'password' }; }
  io.out(say('status.on', { hosts: hosts.join(', ') }));
  const port = resolvePort({ cli: options.port, env: d.env, envFileText: text });
  let sessions = null, logins = null;
  try {
    const base = `http://127.0.0.1:${port}`;
    const { token } = await (await d.fetch(`${base}/api/session`, { signal: AbortSignal.timeout(3000) })).json();
    const s = await (await d.fetch(`${base}/api/remote/status`, { headers: { 'x-shot-token': token }, signal: AbortSignal.timeout(3000) })).json();
    sessions = s.sessions; logins = s.logins;
  } catch { /* not running */ }
  io.out(sessions === null ? say('status.notRunning') : say('status.running', { port, sessions, logins }));
  const ts = await locateTailscale(d);
  const first = hosts[0], entryPort = R.httpsPortOf(first), name = first.replace(/:\d+$/, '');
  if (ts) {
    const json = (await d.exec(ts.command, ['serve', 'status', '--json'], { env: ts.env }).catch(() => ({ stdout: '' }))).stdout;
    const state = R.serveState(json, name, entryPort, port), exposure = R.exposureOf(json, port);
    io.out(state.ours ? say('status.serve.on', { host: name, port: entryPort === 443 ? '' : `:${entryPort}` }) : say('status.serve.off'));
    if (exposure.funnel) io.out(say('status.serve.funnel', { https: entryPort }));
    if (exposure.tcp) io.out(say('status.serve.tcp', { local: port }));
  } else io.out(say('status.serve.unknown'));
  return { on: true, hosts, sessions, logins };
}

/** `npm run remote:off`: removes the two lines, turns off OUR Tailscale publication (never `serve reset`), restarts. Safe to run twice. */
export async function runOff(options = {}, deps = {}) {
  const c = context(options, deps), { d, say } = c, { io } = d;
  io.out(`CandleLab: ${say('off.title')}`);
  const text = c.envText(), hosts = (envValue(text, 'REMOTE_HOSTS') ?? '').split(',').map(s => s.trim()).filter(Boolean);
  const port = resolvePort({ cli: options.port, env: d.env, envFileText: text });
  const removed = R.removeEnvKeys(text, KEYS);
  if (removed.removed.length) { writeEnv(d.fs, c.envPath, removed.text); io.out(say('off.env')); }
  else if (!hosts.length) io.out(say('off.nothing'));
  // turn off the publication of every configured name that Tailscale serves for this port
  const ts = await locateTailscale(d), httpsPorts = [...new Set(hosts.map(R.httpsPortOf))];
  if (ts) {
    // `serve --https=N off` removes whatever the root of that port serves, so it is only run when that is CandleLab (or when Tailscale could not tell us); another service on the port is left alone
    const json = (await d.exec(ts.command, ['serve', 'status', '--json'], { env: ts.env }).catch(() => ({ stdout: '' }))).stdout;
    for (const https of httpsPorts) {
      const name = (hosts.find(h => R.httpsPortOf(h) === https) ?? '').replace(/:\d+$/, '').toLowerCase(), state = R.serveState(json, name, https, port);
      if (state.busy) { io.out(say('off.serve.other', { https, other: String(state.other).slice(0, 80) })); continue; }
      const r = await d.exec(ts.command, R.serveOffArgs(port, https), { env: ts.env }).catch(() => ({ code: 1 }));
      io.out(r.code === 0 ? say('off.serve', { https }) : say('off.serve.failed', { https, local: port }));
    }
  }
  if (options.restart !== false && removed.removed.length) {
    try {
      const service = c.service(), st = await service.status({ port });
      if (st.managedProcessRunning) { await service.restart({ port }); io.out(say('restart.done')); } else io.out(say('restart.manual'));
    } catch (error) { io.out(say('restart.failed', { reason: error instanceof Error ? error.message : 'unknown' })); }
  } else if (removed.removed.length) io.out(say('restart.manual'));
  io.out(say('off.done'));
  return { ok: true, removed: removed.removed };
}

/** `npm run remote:hash`: only asks for a password (hidden, twice) and prints the `REMOTE_PASSWORD_HASH=…` line, for a machine where the full setup cannot run (Docker). Touches no file and no service. */
export async function runHash(options = {}, deps = {}) {
  const c = context(options, deps), { d, say } = c;
  d.io.out(`CandleLab: ${say('title')}`);
  const password = await askPassword(c);
  if (password === null) return { ok: false, reason: 'no-password' };
  const hash = await R.hashPassword(password);
  d.io.out(`\n${say('hash.out')}\n\nREMOTE_PASSWORD_HASH=${hash}\n`);
  return { ok: true };
}

export async function main(argv = process.argv.slice(2), deps = {}) {
  const options = parseRemoteArgs(argv), lang = options.lang === 'uk' || options.lang === 'en' ? options.lang : pickLang(process.env, '');
  if (options.help || options.unknown.length || !['setup', 'status', 'off', 'hash'].includes(options.command)) { console.log(rmsg(lang, 'help')); return options.help ? 0 : 2; }
  const result = await ({ status: runStatus, off: runOff, hash: runHash }[options.command] ?? runSetup)(options, deps);
  return result.ok === false ? 1 : 0;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) main().then(code => process.exit(code));
