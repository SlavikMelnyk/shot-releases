## The one thing to know

**No hub address, no hub.** `config/hub.public.json` is committed as `{ "url": "" }` and `SHOT_HUB_URL` overrides it. With an empty address every hub feature says «Центр спільноти ще не підключено» and **nothing is ever sent anywhere** (`HubClient.ensureEnabled()` throws before a request is built; a test counts the network calls: zero, even when the person had said yes before the address was removed). Nothing in the repository creates an account, deploys anything or calls a service: the owner deploys the hub (steps below) and then writes its address into that file.

## What exists

| Piece | Where | Job |
|---|---|---|
| Protocol | `shared/hub.ts` | limits, error codes with short Ukrainian sentences, the zod schemas of every body, query and answer, `readRulesFile` (the same checks as an import), `SUBMISSION_FIELDS` (the pinned list of what a submission may contain), `cleanHandle`, `csvCell` |
| Crypto | `shared/hubCrypto.ts` | ed25519 device keys, request signing, request codes, admin grants, revocations (Crockford base32 with a checksum, like billing's codes). Never imported by the browser bundle |
| Roles | `shared/roles.ts` | the grant payload, domain strings, messages |
| Strong bar | `shared/strongBar.ts` | the thresholds, `strongReasons`, `claimedMetricsFromRun` |
| Fingerprint | `shared/fingerprint.ts` | the same 12-hex fingerprint of the rules as the local library (pinned by a test) |
| **The hub** | `hub/` (`app.ts`, `store.ts`, `sqliteStore.ts`, `mongoStore.ts`, `limits.ts`, `config.ts`, `index.ts`) | a separate small Node 24 process: Express, JSON, and one `HubStore` interface (every method may answer with a promise) with two stores: SQLite (`node:sqlite`, a file on a volume, the default) and MongoDB (the official driver, for MongoDB Atlas' free tier; chosen by `HUB_MONGODB_URI`). The HTTP layer does not know which one runs |
| App side | `server/hub/` (`identity.ts`, `client.ts`, `service.ts`, `routes.ts`, `fixed.ts`, `cli.ts`, `publicFile.ts`) | the device key, the signed client, the settings, publishing, the strong-strategy outbox, the admin proxy, the operator commands |
| UI | `src/components/community/`, `src/community.css`, `src/i18n/en/hub.ts` | Settings → «Спільнота та дані» and «Роль адміністратора», the tabs «Публічні» and «Адмін», the publish dialog, the wizard question |
| Operator | `scripts/admin_*.ts` → `npm run admin:request | grant | revoke | list` | see the cheat sheet |
| Deploy | `Dockerfile.hub`, `render.yaml`, `hub/fly.example.toml` | the container, a Render blueprint (a free web service with MongoDB Atlas) and an example Fly.io config (none of them used by anything in the repository) |

`npm run hub:start` (compiled: `dist/hub/index.js`) and `npm run hub:dev` start the hub; `npm run hub:build` compiles it; it is part of `npm run build` and `npm run typecheck` (its own `tsconfig.hub.json`).

## Identity without accounts

Each installation makes an **ed25519 key pair** the first time something needs it (`data/identity.json`, directory 0700, file 0600, never in git, never sent: only the public half). Every hub write is a **signed request**:

```
x-shot-key    the public key (64 hex)         x-shot-nonce  16–64 chars, never reused
x-shot-ts     milliseconds since the epoch    x-shot-sig    ed25519 over
              "shot-hub-request/1" 0 METHOD 0 PATH 0 TS 0 NONCE 0 SHA-256(BODY)
```

`PATH` is the part of the URL from `/v1/` on (query included), so a hub behind a path prefix signs the same text. The hub checks the signature, refuses a clock off by more than **5 minutes** (`STALE`) and a nonce it has already seen (`REPLAY`; nonces are kept 10 minutes: SQLite prunes them on a timer, MongoDB expires them with a TTL index), rate-limits per key, and refuses writes from a **blocked** key (which may still read and delete its own data). The author of a public strategy is that key plus an **optional display handle** (default «анонім»; no links). Unpublishing and updating work only for the same key; for anyone else the hub answers «not found», as for a missing entry.

Losing `data/identity.json` loses the right to edit or unpublish what that key published; nothing else.

## Public strategies

- **Publish.** A saved strategy gets «Зробити публічною». The dialog shows **exactly** what is sent (the preview is built by the same function that sends it: name, notes, the optional handle, the `shot.strategy/1` file in a collapsible block; and the list of what is never sent) and needs a tick. It sends the **rules file** only: no results, trades, keys, balances, account ids or paths, and the account size of the test is replaced by the default 10 000. The hub validates it with the **same schemas the app uses for strategy files** (`parseStrategyFile`, the spec schema), requires exactly the fields an export writes (anything else is refused, not trimmed), writes name, notes and handle down as plain text (control and direction characters and `<>` and backticks removed, lengths capped) and stores one entry per (device, rules): publishing the same rules again updates it. At most 50 per device.
- **Browse** (`Стратегії → Публічні`): newest or most imported, text search (name, notes, handle), exchange, type, direction, 20 per page. Each entry shows the rules in plain words (`shared/strategyText.ts`), the handle, a short anonymous tag, the date and the number of imports. A public entry **never carries claimed results**.
- **Import** makes an **untested** imported strategy exactly like a file import (`runId: null`, the «З файлу · не тестувалось» badge, nothing switched on; live still needs an exchange stop-loss and the typed `REAL MONEY`). The import counts once per device. **«Перевірити у себе»** imports and then asks the leaderboard (docs/LEADERBOARD.md) to run the rules on its **fixed conditions** over this computer's own candles, and shows the person their own verified numbers.
- **Report** an entry (spam, abuse, copyright, other): one report per device and entry; admins see the flagged list. There is no automatic hiding (keys are free, so a count of reports could be brigaded).

## Strong strategies → the owner's database (opt-in, off by default)

After every finished test **and** after its reliability check, `StrategyLab` notifies `HubService.observeRun`. It does nothing, and touches no network, unless a hub is set **and** the person switched on «Надсилати сильні стратегії до CandleLab» (asked once, neutrally, with two buttons of the same weight, in the wizard's extras step when the build has a hub; always changeable in Settings → «Спільнота та дані»). It is never "on" for a hub that does not exist yet (a hub added later needs its own yes), and only **new** results are sent.

### The strong bar (`shared/strongBar.ts`, shown in the Settings card)

A result is «strong» only if **all** of these hold. Every threshold is at least as demanding as the library's (`LIBRARY_BAR`, which only keeps a lead on this computer); a test pins that.

| Rule | Value | Library | Why |
|---|---|---|---|
| exchange stop-loss | required | required | live needs it anyway |
| account survived (cross) | required | required | a liquidated account is not a result |
| trades | **≥ 100** | 30 | the error of a mean over fewer than ~100 trades is wide (a 30-trade win rate is ±18 points) |
| period of the test | **≥ 90 days** | – | a test shorter than a quarter says nothing about regimes |
| return **after stress costs** (fee 0.07 %, slippage 0.2 % a fill, from the reliability check) | **≥ 10 %** | 5 % before stress | the lab's own pessimistic costs; profit that exists only at the friendly costs does not count |
| stress return per unit of drawdown | **≥ 0.5** | – | a return that barely clears zero with a deep drawdown is not strong |
| max drawdown | **≤ 25 %** | 35 % | |
| liquidations | **< 2 %** of trades | 5 % | |
| profit factor | **≥ 1.3** | 1.2 | |
| share of the profit from one token | **≤ 50 %** | 70 % | one token carrying the result is a story about that token |
| reliability check | level «витримує перевірки» (`consistent`), **≥ 7 of the 10 checks passed, none failed** | – | the check's own verdict already needs no failed check and passes on sample, risk and other periods |
| **fixed conditions** (leaderboard `lb1`, computed on this computer) | **positive after stress costs, ≥ 30 trades, not «thin»** | – | the same account, size, leverage, costs and window for every strategy, so claims are comparable |

The cheap gate runs first; the fixed-conditions run (minutes) is only made for rules that already clear everything above. If it cannot be computed (no candles, a failure) **nothing is sent** and the journal says why. When the fixed result exists, **its numbers are the claimed ones** (`conditions: "lb1"`, comparable between strategies); otherwise (a build without a leaderboard) they are the author's own test (`conditions: "own"`).

These numbers are **judgement, chosen to be conservative, not fitted to data**. Nobody has shown that clearing them predicts forward results; a pool of many people trying many ideas will contain lucky ones (multiple testing), which is why the admin re-tests on their own candles and why paper/live evidence, not this bar, is what matters before real money. It is a filter for a human's attention.

### Exactly what is sent (pinned by `SUBMISSION_FIELDS`, the schema and a test that reads docs/PRIVACY.md)

One record per rules fingerprint per device (a better result replaces it): `file` (`shot.strategy/1`, name kept, **notes and tags dropped**, test account size replaced) · `metrics`: `conditions`, `periodFrom`, `periodTo`, `trades`, `roiPct`, `stressRoiPct`, `maxDrawdownPct`, `winRatePct`, `profitFactor`, `liquidations`, `level`, `checksPassed`, `checksTotal` · `appVersion` · the anonymous install key (header `x-shot-key`). The hub adds only the time of receipt. **Never:** keys, balances, trades, candles, local paths, exchange account ids, notes, paper or live results. The hub also refuses obvious filler (fewer than the library's 30 trades or a stress return that is not positive). Anything not in this list makes the request fail validation.

A failed send stays in an outbox and is retried every 10 minutes; a send the hub will never accept (bad request, blocked key) is dropped. «Видалити мої надіслані» deletes everything tied to the key (`DELETE /v1/me?scope=submissions`), «Видалити все, пов’язане з цим пристроєм» also the public entries, import marks and reports (`scope=all`); the block record stays. «Показати, що вже в центрі» lists what the hub holds for this key.

## The admin page («Адмін», visible only with a valid grant)

- **Сильні стратегії:** one row per fingerprint, represented by its best claim, with the number of installs that sent the same rules; sort by stress ROI / ROI / drawdown / evidence / trades / installs / newest; filters: exchange, type, evidence level, test period, «new in the last 1 / 7 / 30 days», text; pages of 20; **CSV and JSON export** (formula-defusing: a cell that starts with `= + - @` gets a leading quote). Submissions of blocked keys are left out of the ranking.
- **Detail:** the rules in plain words, who sent them (short tags), and **claimed vs verified side by side**: «Перевірити у себе» imports the rules **untested** and runs the leaderboard test on the admin's own candles; the table shows the claim and the verified numbers in two columns with a verdict (confirmed at ≥ 70 % of the claimed stress ROI under the same conditions; weaker; not confirmed; if the conditions differ only the sign is compared). A client's claim is never evidence.
- **Публічні й скарги:** hide / unhide, delete, block the author's key (and hide all their entries). A key with a valid grant cannot be blocked (`CANNOT_BLOCK_ADMIN`: revoke first).
- **Ключі та дозволи:** blocked keys (unblock) and the grants the hub has seen (an owner can revoke a plain admin's grant). An audit log of admin actions (grant id, action, target, time; last 5000) is in the database.

## API (`/v1`, JSON; errors are `{ "error": "<short Ukrainian sentence>", "code": "<CODE>" }`)

| | Route | Who |
|---|---|---|
| read | `GET /v1/health` (`/healthz`), `GET /v1/public?q&venue&family&side&sort=new|imports&limit&offset`, `GET /v1/public/:id` | anyone (per-address limit) |
| device | `GET /v1/public/mine`, `POST /v1/public`, `DELETE /v1/public/:id`, `POST /v1/public/:id/import`, `POST /v1/public/:id/report`, `POST /v1/submissions`, `GET /v1/submissions/mine`, `DELETE /v1/me?scope=submissions|all` | signed |
| admin | `GET /v1/admin/me|stats|submissions|submissions/export|submissions/:fp|public|keys|grants|audit`, `POST /v1/admin/public/:id/hide`, `DELETE /v1/admin/public/:id`, `POST /v1/admin/keys/block`, `DELETE /v1/admin/keys/:key` | signed + grant |
| owner | `POST /v1/admin/grants/:id/revoke` | signed + owner grant |
| operator | `POST /v1/operator/revocations` `{ id, revokedAt, sig }` | the operator's signature only |

Limits: bodies 8 KB (small), 48 KB (publish), 64 KB (submission), 1 KB where none is expected; per address 240 reads and 60 writes a minute; per key 1200 requests an hour, 20 publications, 200 submissions, 30 reports and 300 imports an hour (in memory; a restart forgets them). Codes: `DISABLED, ADMIN_DISABLED, UNREACHABLE, BAD_RESPONSE, BAD_REQUEST, INVALID_STRATEGY, TOO_LARGE, UNSIGNED, STALE, REPLAY, KEY_BLOCKED, NOT_ADMIN, NOT_OWNER, OWNER_PROTECTED, GRANT_INVALID, NOT_FOUND, RATE_LIMITED, LIMIT_REACHED, CANNOT_BLOCK_ADMIN, INTERNAL`. A validation failure never echoes its detail.

**No CORS** headers are sent unless `HUB_CORS_ORIGINS` lists an origin, and then only on public reads. The app talks to the hub server-to-server, never from the browser. **The log** has the method, the path (no query), the status, the time and the first 8 characters of the key: never a body, a query, an address or a full key. The hub stores no IP address.

## The app's API (`/api/hub/…`) and the remote policy

`GET /hub` (state) · `PUT /hub/settings` · `GET /hub/preview/:strategyId` · `POST /hub/publish` (needs `confirm: true`) · `DELETE /hub/published/:strategyId` · `GET /hub/public[/:id]` · `POST /hub/public/:id/import|report` · `GET|DELETE /hub/mine` · `POST /hub/sync` · `GET /hub/admin` · `POST /hub/admin/request|grant` · `DELETE /hub/admin/grant` · the admin proxies. In `server/remote/policy.ts` (phone control) **publishing, the settings, pasting or removing a grant and every admin write ask for the password again** (`stepup`: settings-like, not real money); taking something back (unpublish, delete what was sent), importing, reporting, retrying a send, making a request code and importing for a check are `free`. A test fails on an unclassified route.

## Deploying the hub (one page; nothing here has been done)

Two shapes. **(a) A host with a volume** (this section): the hub is one Node process and one SQLite file; Fly.io, Railway or a VPS; about 256 MB of memory is plenty. **(b) A host without a disk of its own** (the next section): the hub keeps everything in **MongoDB Atlas** (free tier) and runs on a free web service such as Render's, where the disk does not survive a deploy. Both run the same image and the same code; only `HUB_MONGODB_URI` differs.

1. **Build the image:** `docker build -f Dockerfile.hub -t shot-hub .` (it contains `dist/hub`, the shared code and `config/billing.public.json`, which gives the hub the operator's PUBLIC key; **no secret goes in the image**).
2. **Give it a volume at `/data`** (the database is `/data/hub.sqlite`) and set the environment: `HUB_TRUST_PROXY=1` (one proxy in front: Fly, Railway, most hosts), optionally `HUB_OPERATOR_PUBKEY=<64 hex>` (otherwise `config/billing.public.json` in the image is used), `HUB_CORS_ORIGINS` (leave empty). The host terminates **HTTPS**; the hub itself speaks plain HTTP on port 8787.
   - **Fly.io:** `fly launch --no-deploy --dockerfile Dockerfile.hub` (see `hub/fly.example.toml`), `fly volumes create hub_data --size 1`, `fly deploy`.
   - **Railway:** a service from this repository with the Dockerfile path `Dockerfile.hub`, a volume mounted at `/data`, the variables above.
   - **A VPS:** `docker run -d --restart unless-stopped -p 127.0.0.1:8787:8787 -v shot-hub:/data -e HUB_TRUST_PROXY=1 shot-hub` behind Caddy or nginx with HTTPS; or without Docker `npm ci --omit=dev && npm run hub:build` and run `node dist/hub/index.js` under systemd with `HUB_DB=/var/lib/shot-hub/hub.sqlite`.
3. **Check:** `curl https://<host>/v1/health` → `{"ok":true,…,"admin":true}`. `"admin":false` means the hub has no operator key (it still serves the public list and submissions, but no admin route works).
4. **Point the app at it:** put the address in `config/hub.public.json` (`{ "url": "https://<host>" }`), commit, and make a release (docs/DISTRIBUTION.md); or set `SHOT_HUB_URL` in `.env` of one installation to try it first. Until then nobody sends anything.
5. **Your own admin role:** on the computer where you keep your keys, with the app's `data/` folder: `npm run admin:grant -- --self`, paste the printed `SHOTADM1-…` into Settings → «Роль адміністратора». Then give it to someone else with the cheat sheet below.
6. **Back up** `/data/hub.sqlite` (it is the whole state; `sqlite3 hub.sqlite ".backup copy.sqlite"` while running is safe). Nothing in it is a secret, but it is people's data: see PRIVACY.md.

## Tests

`hub/conformance.testkit.ts` (the hub's conformance suite: an in-process hub over a store the caller gives, signed requests: signatures, replays, stale clocks, validation and size limits, sanitising, rate limits, the role chain, expiry, revocation by the operator and by an owner, admin enforcement on every admin route, filters / sorting / paging, CSV defusing, moderation, no secrets in the log, CORS), run by `hub/hub.test.ts` over SQLite (always) and by `hub/hub.mongo.test.ts` over `MongoHubStore` (plus the TTL index, idempotent indexes and the fail-fast start) **only when a MongoDB is at hand**: `HUB_TEST_MONGODB_URI=mongodb://…` (a server of yours; the test makes and drops `shot_hub_test_*` databases) or `HUB_TEST_MONGO_MEMORY=1` (`mongodb-memory-server-core` starts a mongod; its binary must already be cached, because no test may download anything: `npm run hub:test:mongo` fetches it once outside vitest, then runs the suite). Without either the file is skipped, so CI needs no MongoDB and downloads nothing. `hub/config.test.ts` (the settings, the `PORT` fallback, the connection string: parsed, validated and redacted, never echoed), `shared/hubCrypto.test.ts` (domain separation: forged grants from customer, voucher, revocation and request signatures all fail), `shared/strongBar.test.ts` (each threshold alone, stricter than the library), `shared/hub.test.ts` (the field list against the schemas and PRIVACY.md), `server/hub/service.test.ts` (against a **real hub on a random local port**: zero requests with no hub, publish / unpublish / import end to end, the sent body equals the preview, the pinned submission fields, retries, hostile hub answers), `server/hub/routes.test.ts` (the whole app, including the admin chain), `server/hub/cli.test.ts` (the operator commands with a temporary HOME and temporary keys), `server/hub/fixed.test.ts` (the real leaderboard's fixed result), `server/hub/i18n.test.ts`, `src/components/community/*.test.ts` (logic, both-language rendering), and the pinned remote policy.
