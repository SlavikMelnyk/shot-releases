# Trust-first Strategy Lab

Added 13 October 2026 on branch `feature/trust-first-lab`, from the product discussion the user shared (a ChatGPT conversation about a crypto strategy-builder app: «describe → test → trade», exchange coverage, competitors, pricing, performance fees). That conversation is a business discussion, not a specification, so this document records **which ideas were turned into code, which were adapted to a single-user local app, and which were deliberately left out**.

The thesis of the discussion, and of this change: *a backtest that looks good is the cheapest thing to produce; the valuable part of a strategy tool is helping a trader find out honestly whether the result deserves trust.* Everything below serves that. Nothing here arms live trading, places an order, or changes the capital guard (`server/broker/plan.ts`): live remains a manual, typed-`REAL MONEY` action.

## What the discussion asked for, and where it lives

| Idea in the discussion | Implementation |
|---|---|
| Describe a strategy by text or **voice**, AI builds the parameters or asks questions | **«Опишіть своїми словами»** — `server/lab/assistant.ts`, `src/components/lab/Assistant.tsx`, `POST /api/strategy-lab/assistant`. A keyword parser works offline; with `ANTHROPIC_API_KEY` a model reads the text with a strict schema. Voice uses the browser's speech recognition. Shows the rules in words, the **assumptions** it made, **questions** with one-click answers, and what it **cannot model** (longs, grids, indicator crossovers…). It only authors parameters; the deterministic engine evaluates them |
| «Make reliable testing the central product»: untouched period, walk-forward, cost and parameter stress | **Перевірка надійності** — `server/lab/reliability.ts` (10 checks, below) |
| «Track strategy versions and optimization attempts» (repeatedly tuning on the "untouched" period makes it training data) | `Lineage` on every test: rule **family** (`name · variant`), attempt number and how many attempts used overlapping data; periods already spent by earlier checks are marked "not fresh" (`lab.touched` in the platform db) |
| «A backtest can accidentally produce impressive results through unrealistic fills… state assumptions» | Up-front **«Як ми рахували»** panel (`shared/strategyText.ts`: modelled / simplified / not modelled) and a count of trades where stop and target shared one 1m candle (stop counted first) |
| «Display data coverage and quality explicitly» | Per-test data quality (`result.data.quality`: % of forward-filled minutes, tokens with gaps, tokens with short history) and the **Дані** tab (coverage table, per-token measured quality, exchange instrument card) |
| «Normalize instruments, not just tokens» (venue, market type, settlement, contract size, precision, fees, listing date) | `shared/instrument.ts`, `server/instruments/*`: `Instrument` ids look like `binance:usdm-perp:BTCUSDT`; Binance exchangeInfo is mapped and cached in `data/instruments.json`; a `Venue` interface keeps the lab independent of the exchange |
| «Three performance records: backtested, forward paper, live» — never added together | `StrategyTracks` on every saved version (`server/lab/tracks.ts`); shown side by side on the version card and in the ranking |
| «Freeze published versions; unsuccessful versions should remain visible» | A saved version is immutable (changing a rule = new version with an empty forward record); archived versions stay readable in the list, the ranking and reports |
| «Leaderboards that are difficult to manipulate: net return alongside drawdown, leverage, trade count, track-record length, open losses, a benchmark» | **Рейтинг** tab (`Ranking.tsx`). Default order is *evidence level, then record length*, not profit. Columns: return, max drawdown, trades, record length, open loss, leverage, period, BTC move. Warns when tests cover different periods |
| «AI hints should explain weaknesses and create a candidate version evaluated under the same rules» | Weaknesses are computed (concentration, costs, parameter fragility, regime, fills vs. signal) and written in plain words; AI suggestions and what-if variants run as new attempts (counted in the lineage) and are tested with the same engine |
| «Shareable, versioned strategy reports» | `GET /api/strategy-lab/runs/:id/report` and `…/strategies/:id/report` → Markdown (rules, assumptions, result, checks, three records, parameters) |
| «Let users reach their first useful backtest before connecting an exchange account» | Already true (public data, no keys). New: a **guided first-run download** of candle history |
| «Responsive web; phone for review and notifications» | The lab is usable at 375 px: tabs and sub-tabs scroll, steps stack, tables scroll, touch targets ≥ 40 px |
| Weekly/monthly **performance fee** with a high-water mark, subscriptions, tiers, marketplace, creator payouts, legal classification, other exchanges, native apps | **Not implemented, on purpose** — see below |

## Reliability checks (`server/lab/reliability.ts`)

Run on demand from the result («Перевірити надійність») as a background job (`POST /api/strategy-lab/runs/:id/check`, same queue and progress as a test). All checks are deterministic. For a losing or tiny result the heavy runs are skipped (nothing to stress).

| Check | Question | Pass / warn / fail |
|---|---|---|
| `risk` | Lives on the edge of liquidation? | Liquidated share ≥ 25 % or drawdown ≥ 60 % or a wiped cross account → fail; ≥ 5 % / ≥ 30 % / no stop-loss / margin use ≥ 90 % → warn. A strategy with a warning here can never be «consistent» |
| `sample` | Enough trades? | ≥ 100 trades and ≥ 8 tokens / 30–99 or few tokens / < 30 (→ level «Замало даних») |
| `consistency` | Stable over time? | The period is cut into 2/4/6 equal windows read from the daily P&L; pass ≥ 75 % windows in profit, warn ≥ 50 %, fail below |
| `otherPeriods` | Works on data nobody touched? | Re-runs the same rules on up to 3 other periods (earlier/later, ≤ 90 days, fresh first). Pass: all periods with ≥ 10 trades in profit and not much weaker; fail: most in loss. «N/A» when the test already spans all the data |
| `costs` | Profit survives worse costs? | Re-run with fee 0.07 % and slippage 0.2 % (`STRESS_COSTS`, the same stress values as `docs/LIVE_STRATEGY.md`): pass keeps ≥ ½ of ROI, fail ≤ 0 |
| `neighbours` | Survives small changes? | Up to 10 variants with key numbers shifted by 20–25 % (rise, drop/pullback, target, stop, hold time): pass ≥ 75 % in profit. These are a stability test, **not** a search for a better set |
| `concentration` | One lucky trade/token? | Profit without the best trade (and best 3), share of the top 3 tokens; fail if the best trade is all the profit |
| `regime` | Different market weather? | Windows labelled by BTC move (> +5 % up, < −5 % down, else flat); warns when a type loses money; N/A when the period was one type |
| `execution` | Order inside the minute? | Share of trades where stop and target are in one 1m candle: ≤ 2 % pass, ≤ 10 % warn |
| `data` | Candles complete? | Forward-filled minutes ≤ 0.2 % pass, ≤ 2 % warn |

**Evidence level** (never "proven"): `insufficient` (< 30 trades) → `failing` (unprofitable, or any of risk/consistency/otherPeriods/costs/neighbours/concentration fails) → `consistent` (no failures, risk passes, ≥ 70 % of applicable checks pass and other data existed) → otherwise `mixed`. The best label is «Витримує перевірки», and the text says it is not a forecast and that the next step is forward paper. Repeated attempts on the same data are listed as a caveat.

## Records, readiness and the ranking

- **Backtest** — the saved evidence of the test. **Paper** — virtual shorts at real prices after the version was switched on (`SpikePaper.forward`; the entry now stores `signalClose`). **Live** — real fills of the plan (`SpikeTrader.tradesOf`, newest 500 trades). Each has trades, P&L, return (on start balance for paper; on margin at risk for live), max drawdown, record length, open positions with unrealized P&L (paper) and the **fill drift** (entry price vs. signal price: how much worse real fills are than the simulation's slippage assumption).
- **Readiness** (advice only): test done → reliability checked → ≥ 40 closed paper trades over ≥ 14 days with a positive result after costs (`readinessOf` in `server/lab/tracks.ts`) → live compatible. The hard guards (mandatory stop-loss, limits, typed confirmation, capital guard) are unchanged and unrelated to this advice.
- **Ranking** sorts by evidence level, then record length; alternatives: return/drawdown, return, drawdown, trades, record length. Forward records can be ranked separately from backtests.

## Assistant limits

The rule-based parser understands the common phrasing for the supported spike-short model in Ukrainian, Russian and English; it asks instead of guessing when the stop, the size of the spike or the entry style is missing. The AI path adds interpretation but is validated field by field against `strategyParamsSchema`; invalid values are dropped, never passed on. AI use is recorded in the AI ledger (role `brief`) and shown with its cost. The proposal is never evidence and never starts anything by itself.

## API added (`/api/strategy-lab/*`)

`POST runs/:id/check` (202, job kind `check`), `GET runs/:id/report`, `GET strategies?archived=1`, `GET strategies/:id/report`, `POST assistant`, `GET data/overview`, `GET data/symbols/:symbol`, `POST instruments/refresh`, `POST data/history {months: 3|12}`, `POST data/topup {symbols, from}`. `GET meta` now includes `history`.

## Known limits (from the independent review)

- **«Untouched» is relative to this app's records.** `lab.touched` is filled from the first test after this release and seeded once from the tests and saved versions that already existed. Anything you tested elsewhere, or under a renamed family (the family is the name before « · »), counts as fresh.
- **Re-run, not replay.** The cost, parameter and other-period checks re-run the rules on the current candle store and token list, together with a fresh run of the base rules for an apples-to-apples cost comparison. If the store changed since the test, the check says so.
- **One writer at a time.** A history download, the newest-minutes refresh and a test/check never run together (the lab refuses with a message); the download script writes through per-process temporary files and an atomic manifest, skips unreadable shards when it rebuilds the index, and completes a previous-month shard that was saved before the month ended.
- **Live return basis.** The live record's return is measured against the margin at risk in the *current* live settings, so it moves if those settings change. Paper uses the strategy's start balance.
- **No download cancel.** A running history download can only be waited for (or ended by stopping the server); Binance rate-limit pauses can make it slow. Tokens that left the exchange list are not fetched by the script (the archive of delisted tokens is `scripts/backfill_delisted.py`).
- **Assistant.** Partial exits, break-even and trailing stops are flagged, not parsed: add them in «Усі параметри».

## Added venues later

Implement `Venue.fetchInstruments()` (normalised `Instrument`s) in `server/instruments/`, add a candle-archive adapter that writes the same `SC1M` shards under a venue-prefixed directory, and register it in `venues`. The lab, reliability checks, records and ranking are independent of the exchange; only the live/paper execution modules are Binance-specific.

**Bybit USDT linear perpetuals were added on 13 October 2026** this way (`server/instruments/bybit.ts`, `server/lab/download/bybit.ts` (first written as `scripts/backfill_bybit.py`), `data/candles/bybit/`); the steps and the specifics are in [MARKETS.md](MARKETS.md). Every run, check, data page, library entry and report uses the store of the market the strategy names (`venue`, default Binance).

## Deliberately not implemented

- **Subscriptions, free/premium tiers, pricing, marketplace, creator payouts.** CandleLab is a single-user, local, loopback-only app; there is no second user, no account system and no hosting. Nothing real can be sold or gated here.
- **A 9 % performance fee with a high-water mark.** Collecting a fee needs a counterparty, an authorised payment method or an exchange-native profit-sharing program; none exists for a personal tool, and the discussion itself concluded the legal classification must be checked first. (Design notes from the discussion, should it ever be built: charge only on net new profit above the high-water mark, measure a dedicated sub-account, settle monthly, never hold withdrawal rights.)
- **More exchanges, as an execution venue.** The first release was Binance-only. On 13 October 2026 Bybit was added **for testing only** (rules can be tried on its tokens and on another exchange's prices; [MARKETS.md](MARKETS.md)). Paper was then added for Bybit as well (own runner on Bybit prices), and live (a separate Bybit module, Isolated margin only); a strategy runs only on its own exchange's runner and live module, in code, whatever the page shows. Any further market would be added the same way ([MARKETS.md](MARKETS.md)).
- **Native mobile apps.** The panel is responsive; native apps would need hosting and authentication that this app intentionally does not have (see README).
- **Long, grid, DCA and indicator-crossover strategies.** The engine models short entries after a spike only; the assistant says so instead of pretending.
