# Spike-fade research, 12 October 2026

Question (user): *"those tokens almost every time get back to the bottom, sometimes in a day, sometimes in a few days: how long does it take, can a multi-day strategy be made profitable, find the optimal strategy on spike tokens."* Everything below is simulation on historical 1m candles with real funding. Costs: stress (0.07% fee and 0.2% slippage each way) in the research tables, except where a row says the saved run, which uses the lab's default 0.05% + 0.05%. Nothing here is a forecast; nothing was traded.

## Data

`data/candles` now holds 1m candles and funding for **674 USDT perpetuals from January 2023 to October 2026** (523 listed today from `backfill_candles.py`, plus 151 delisted ones from `backfill_delisted.py`, so tokens that spiked and then died are included; TradFi/stock perps are excluded). Event tables for the research live in `data/lab/research` (git-ignored): 98k spike events (rollover entries 6/8/12/16/20% under the peak), with features known at the entry bar and the net outcome of 15 exit styles simulated by the lab engine.

## How fast do spiked tokens return to the pre-spike low?

Return = price back within +10% of the pre-spike 24h low; entry = 12% below the spike peak; 3.8 years, events at least 31 days before the end of the data.

| Spike size (24h) | Events | 1 day | 3 days | 7 days | 14 days | 30 days | Median |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| ≥ +20% | 17,546 | 61% | 72% | 80% | 85% | 90% | 0.1 d |
| ≥ +50% | 4,374 | 16% | 31% | 46% | 58% | 69% | 3.7 d |
| ≥ +100% | 1,099 | 7% | 15% | 25% | 34% | 45% | 5.9 d |

The user's observation is right for ordinary spikes and wrong for the big ones: of +50% spikes, 31% had **not** returned after 30 days, and on the way back the price first went against a short by +13% (median), +33% (p75), **+74% (p90)**, +136% (p95). That squeeze is what makes "they always come back" unprofitable to trade naively.

## What was tested and what it showed

| Idea | Result |
| --- | --- |
| Rollover shorts with 648 rule variants, 3 periods | none positive in all three; the best Mar–Jun set was −3.4% and −2.4% per trade in the other periods |
| 15 exit styles on 98k events (stops 5–40%, targets, scale-out, trailing, 12 h to 7 days) | every one negative on average in nearly every half-year; multi-day holds win 70–85% of the time and still lose on average |
| 1× no-stop holds of 7/14/30 days, ladders (add as it rises) | looked positive at event level, but that ignored liquidation on the way; with it, equity ends 0.1–0.9× |
| Regime filters (BTC trend, market breadth, trailing performance of the strategy) | no stable effect; only "BTC fell > 3% in 24h" is consistently bad |
| Cross-sectional daily reversal (short the top gainers) | negative net of costs in every year |
| Momentum long at the spike trigger | flips sign by period (continuation in autumn 2025, reversion in 2026) |
| Equal-weight short basket of all alts | loses: the mean alt return is positive (the median decays, the mean does not) |
| Gradient-boosted model (walk-forward, 34 months, 2024-01 → 2026-10) | selected events beat the average by 1–2 points; borderline significance, positive in 21 of 34 months |
| The same model trained on 2025-09+ and applied to 2023-02 → 2025-09 | wide-stop multi-day exits: +2.5% per trade (95% CI +0.5…+4.5) in the top 5% |

The model's strongest inputs were the size and freshness of the spike, its volume surge, and BTC's 24h move. That pointed at a transparent pocket, which was then tested without the model.

## The one thing that survived: loud, fresh blow-off tops

Rule («Гучний спайк» in the lab): a spike of at least +50% over the 24h low, **24h volume at least 12× the average day of the previous week, the peak at most 1 hour old**, entry when price has fallen 12% from the peak (first qualifying bar only), then a short with a wide stop and a multi-day hold. New engine fields: `minVolSurge`, `maxHoursSincePeak`, `minPeakRisePct`, `minRsi` (shared by backtest, paper and live code, `server/trading/spike/signal.ts`).

Selection honesty: 1,800 rule combinations × 4 exits were searched on one half of the history and scored on the other half, both ways round. Selected on 2023–Sep 2025, the best rule made +3.5% per trade in training and **+3.7% per trade on 2025–26 (499 events; all events of that depth: −1.05%)**; selected on 2025–26, +9.0% in training and +5.2% on the older years (45 events; baseline −0.2%). Short exits (stop 8%, 24 h) do not survive (−1.3% and −0.2%).

In the lab engine, 1× isolated, 50 USDT margin per trade on a 1000 USDT account, ≤ 10 open, stop +25%, target pre-spike low +25%, 5 days max, 12 h pause per token after a stop:

| Period | Trades | P&L on 1000 USDT | Win | PF | Max drawdown |
| --- | ---: | ---: | ---: | ---: | ---: |
| 2023 (Feb–Dec) | 29 | +117 | 83% | 3.15 | 3% |
| 2024 | 30 | +14 | 60% | 1.09 | 13% |
| 2025 Jan – mid Sep | 80 | +34 | 62% | 1.09 | 10% |
| mid Sep 2025 – Mar 2026 | 154 | +240 | 64% | 1.36 | 9% |
| Apr – Oct 2026 | 256 | +341 | 64% | 1.28 | 11% |
| last 12 months, stress costs | 385 | **+503 (+50%)** | 63% | 1.28 | 9.5% |
| last 12 months, saved run `u-1-2` (default costs 0.05% fee + 0.05% slippage per side) | 385 | +553 (+55%), worst trade −16 | 63% | 1.31 | 9% |

The neighbourhood is broadly positive: of 108 variants (volume surge 8/12/20×, peak age 1/2 h, spike size 40/50/70%, depth 8/12/16%, two exits) 99 are profitable in total, 73 in at least 4 of the 5 periods, 23 in all 5. Depth 8% and a 2-hour peak age are the weak corner. The 2× variant doubles profit and drawdown (+111%, drawdown 15%, no liquidation: stop 25% is inside the 49% liquidation distance).

## Reversal catching: what the top of a spike looks like (12 October 2026, second round)

Question (user): at the very top of a spike there is often a violent push, probably squeezing shorts, before it turns; can that be turned into rules? `scripts/lab_climax_events.ts` built 37k top-of-spike candidates at 1m and 5m resolution (a bar printing a high within 1% of the 24h high during a ≥ +30% spike, with a ≥ 2% push in the last 5 minutes): features known at the bar's close (push size, upper wick, volume climax, taker-buy share, spike size, ...), first-passage labels (does it fall 10–30% before it prints 3–10% above the bar high) and the simulated outcome of 11 exits (`scripts/lab_climax_analyze.py`).

**The upper wick is the signal.** The share of candidates where the price did not print another +5% high within 24h (a real top) rises monotonically with the wick of the bar (5m bars, high-to-close as a share of the high): 33% for all candidates, 38% (≥ 2%), 49% (≥ 4%), 58% (≥ 6%), 65% (≥ 8%), 71% (≥ 10%), 80% (≥ 15%); "falls 10% before +3% above the high" goes 31% → 58% → 75%. Same in every half-year (52–65% vs a base of 28–33%). Push size, volume climax and a low taker-buy share add a little; each alone is weak (a 30% push in 15 minutes: 55% real tops, a 60× volume bar: 61%). Funding, hour of day and BTC trend show no stable effect.

**Entering on the wick bar does not by itself make money.** After the wick bar closes the price is already a median 8.4% below its high, so a stop above the wick is 10%+ from the entry; with the exits tested the average trade is −0.6% to +0.3% (stress costs). A micro-rollover entry (first 1m/5m close 3–8% under the push top) is better, and a rule such as «spike ≥ +100%, top-bar wick ≥ 6%, push ≥ 12%, 5% under the top» looked like +4% per trade in the event table, but in the lab engine as a portfolio it is regime-dependent: 2023 +11%, 2024 −5%, 2025 −10%, 2026 +4% of 1000 USDT for the broad version, and +4%/+3%/+43%/−1% for the violent-push version; event-level means overstated it.

**What worked: the wick as a gate on the validated pocket.** New lab entry gate `minPeakWickPct` (the upper wick of the 15m bar that printed the peak) on top of «Гучний спайк» (rollover −12% from the peak, peak ≤ 1 h old, spike ≥ +50%), 1× isolated, 50 USDT margin, stop +25%, target base +25%, ≤ 5 days, stress costs:

| Wick of the peak bar | 2023 | 2024 | 2025 | 2026 to 11 Oct | Trades (4 yrs) |
| --- | ---: | ---: | ---: | ---: | ---: |
| none (v1, surge ≥ 12×) | +117 | +14 | +346 | +224 | 550 |
| ≥ 4% | +140 | +29 | +274 | +402 | 402 |
| ≥ 6% (v2, surge ≥ 8×) | +104 | +74 | +341 | +441 | 409 |

Across a 384-variant neighbourhood (wick 0/4/6/8%, volume surge 4/8/12/20×, peak age 1/2/4 h, spike 50/70%, depth 12/16%, two exits) the wick levels ≥ 4% are positive in all four years in 68–75 of 96 variants against 64 without the gate, with a higher median total and a higher worst-year profit factor (≈ 1.3–1.5 against ≈ 1.0–1.1 for the best neighbours). v2 saved as strategy `u-v2-3`: calendar years, stress costs, 1000 USDT with 50 margin (not compounded): **2023 +10.4%, 2024 +7.4%, 2025 +34.1%, 2026 (to 11 Oct) +44.1%**, last 12 months +78% (279 trades, 68% wins, profit factor 1.7, max drawdown 10%; default costs +82%); at 2× the same years are +21%, +15%, +68%, +88%. The wick gate was found on the same history as the pocket, so v2 is also a forward-paper candidate, not proven.

New lab fields: `minPeakWickPct`, and an experimental entry mode `turn` (`turnDropPct`, `turnWickPct`, `turnPushPct`, `turnPushBars`, `turnMaxBarsSinceTop`, `turnTopVolMult`) that catches the first close under a wicked top; it is available in the lab, paper and live code but did not beat the pocket. Exits (hold to the bottom, partial closes, re-shorting waves) were left for a later round at the user's request and tested in the fourth round below.

## Research program, fourth round (12 October 2026): six parallel studies

At the owner's request ("spend a few hours testing different scenarios related to shorts, also find working strategies on the internet") six agents studied, on the local 1m store and with the stress cost model: new-listing/age effects and delistings, funding and crowding, ideas from the literature and the internet, overextension/parabolic shorts at multi-day horizons, trend/momentum shorts of decliners, and exits for the pocket (hold to the bottom, partials, wave re-shorts, leverage). The consolidated, ranked result with exact rules, yearly numbers and caveats is in **[SHORT_STRATEGIES.md](SHORT_STRATEGIES.md)**; the six full reports are in [research/](research/).

In one paragraph: nothing generic works; the loud-spike pocket remains the only strategy positive in all calendar years, and no overlay made its entry measurably better. Exits do not add return (hold-to-bottom, scale-outs and wave re-shorts lose); the one supported change is risk: a peak-based stop (`LIVE-1`: stop peak +5%, cap 25%, cooldown 24 h, 5 slots → +10.7 / +6.9 / +35.1 / +40.4% = +93.1%, DD 11.7%, inside the noise of the baseline's +86.6% at the same caps) and, backtest-only, a profit-lock (stop to entry after −15%: DD 14.0 → 9–11%, worst trade −22.6 → −14.6 USDT). Three weaker post-hoc candidates are paper/shadow only: the daily volume-climax short (H3c, +30.5%, interval includes zero), the MA50 cross-down trend short with BTC > SMA100 (+8.7% per trade in-sample, +4.5% walk-forward) and the day-1 «no pump» listing short. Saved as strategy `u-v2-live-1-4` and lab preset `loudLive1`; paper stays off.

## Limits and risks

- The pocket was found on the same history it is tested on (cross-half tests above shrink but do not remove that). **It is a candidate for forward paper, not a proven strategy.** The bar before real money stays: ≥ 40 closed paper trades with a positive average after costs.
- Tails: a third of the events in the pocket would be liquidated at 3× (hence 1–2× only); the worst single event moved +460% against the short. Costs on freshly pumped tokens can be worse than the 0.27% per side of the stress model; funding on them is often very negative (−140 USDT over the 12 months at 1×).
- A BTC-fall pause (skip entries when BTC fell more than 3% in 24h: −1.4…−2.9% per trade in the pocket, 39 events) is not implemented; the fourth round found no dependence of the pocket's trade result on the BTC move over the holding period (correlation −0.03) and no gain from a BTC hedge.
- Delisted tokens are included from the archive, but for 146 of 151 of them the stored «last candle» is a flat zero-volume forward fill; the real last trade is the last candle with volume (months to years earlier). A short held through the tail settles at the last price, so results are unaffected, but the settlement is not necessarily the price the exchange paid out.

## Reproduce

`python3 scripts/backfill_candles.py backfill --from 2023-01` · `funding --from 2023-01` · `python3 scripts/backfill_delisted.py` · `npx tsx scripts/lab_market.ts` · `npx tsx scripts/lab_events.ts [--from … --to … --out …]` · `python3 scripts/lab_events_analyze.py return|menu` · `npx tsx scripts/lab_gbm.ts --files … [--apply old.jsonl]` · `python3 scripts/lab_validate.py` · `npx tsx scripts/lab_sweep.ts <specs.json> --periods …` · `scripts/lab_ladder.ts`, `lab_trigger_study.ts`, `lab_xsec.ts`, `lab_basket.ts`, `lab_portfolio.py` (the side studies in the table).

## Case study: DOSUSDT, 12–13 October 2026 (what the rules would have done)

DOSUSDT rose from ~0.32 (20:00 UTC) to a 0.8542 high at 21:40 UTC (+160% in under two hours) and then fell 66% inside one minute (21:45, 8.6M USDT traded in that minute) to a 0.1456 low (the +480% shown by the scanner is that low to the high). From public 1m klines (`scripts/research/cases/dos_20261012.ts`, stress costs 0.07% + 0.2% per side, 1×):

| Rule set | Result |
| --- | --- |
| `LIVE-1` (volume surge ≥ 8×, peak-bar wick ≥ 6%, peak ≤ 1 h old, entry on the first 15m close ≥ 12% under the peak, stop peak +5% capped at 25%, target base +25%) | one trade: entry 0.5353 at 21:45 (the peak bar itself closed 37% under its high, wick 37%), target 0.3354 hit in the next minute: **+37.2% on notional** (≈ +37 USDT per 100 USDT position at 1×) |
| the same without the 1-hour peak-age gate | identical: the gate played no role, the signal came on the peak bar |
| no quality gates at all | the same trade plus a worthless re-entry at 23:00 (+0.6%) |
| short immediately at +50% (spike mode, stop +25%) | stopped out at +25%: **−25.4%** (the price kept rising for another hour) |

Reading: the rules do not catch the top (0.8542) and cannot; they enter after the first 15m close well under it, so about half of the move (0.535 → 0.335 of a 0.854 → 0.146 move) was captured, and shorting earlier would have been stopped out. The backtest fill is the next bar's open (0.5364 less 0.2% slippage); live orders are sent a few seconds after the bar closes, and in that minute the price fell from 0.536 to 0.175, so the real fill and the real exit of such a vertical move are the largest uncertainty (one trade, one event: not evidence of an edge). This is what forward paper with the fill-drift record measures.
