## Who needs what

| Stage | What the person needs | Why |
|---|---|---|
| Try | **Nothing.** No account, no keys | Tests, checks and reports run on public data |
| Keep and follow | **An account: email only** (magic link or passkey, no password) | 24/7 paper and live, statements, alerts, saved strategies across devices |
| Trade | **An exchange key as a connection** | Reads the account and, for live, places orders |

So: accounts are needed, but late and light; an exchange key alone cannot replace them (a key is not an identity: it cannot receive a statement, be paused, or be asked to pay).

### Exchange keys: advice, not rejection

People create keys fast and tick everything. CandleLab therefore **accepts a key with any rights** and never refuses one for having more than it needs. What it does:

- recommends **Reading + Futures** and an **IP allow-list**;
- on mainnet it reads the key's own restrictions (`GET /sapi/v1/account/apiRestrictions`, a signed read-only call, at most every 10 minutes) and, if the key can withdraw, make transfers, trade spot/margin or is not IP-restricted, shows a list of **suggestions** with the exact place to change them (`shared/keyAdvice.ts`, Settings → «Поради щодо ключа»). Wording is always "safer to turn off", never "will not work";
- never calls a withdrawal or transfer endpoint, whatever the key allows. That is the real guarantee, and the copy says so ("CandleLab never withdraws your funds").

In the hosted version keys are stored encrypted in a vault, can be revoked in one click, and every request goes out from fixed IPs so a user can allow-list them.

## The fee: 9 % of net profit, never of the balance

`shared/performanceFee.ts` (the same code the landing calculator uses):

- **Base: the net profit** of the SHOT-originated trades in a period: realized P&L, funding and exchange commissions, plus the change of unrealized P&L. Deposits and withdrawals are not results. Orders carry a CandleLab `clientOrderId` prefix so the base is the strategies' result, not the person's manual trading.
- **High-water mark** per customer (one customer code, across the connected exchanges): only profit above the best cumulative result so far is chargeable; a loss is recovered first; the same money is never charged twice.
- A losing or flat period costs **0**; there is never a credit or a refund, the mark just stays.
- **Weekly statement, monthly invoice.** Fees under a small minimum roll over to the next month.
- The landing says it in numbers: «Не 9% від балансу. Це 9% від того, що ви заробили» (an interactive example: balance 1 000, profit 100 → fee 9, never 90), and the app's **Settings → «Комісія CandleLab»** shows the same on the user's own closed live trades. It is a preview until the operator's build carries the two public keys **and** the person enters a customer code the operator issued (the first live arming on a real account then shows the versioned terms); with a code the card issues monthly invoices, watches them, keeps receipts and checks every month against the exchange's own income (implemented 14 Oct 2026, stage 1: see [BILLING.md](BILLING.md) and [BILLING_FLOW.md](BILLING_FLOW.md)).

### Paying in USDT only (no company, no card processor)

> Built: [BILLING.md](BILLING.md) is how the code does it (monthly statements from closed mainnet live trades of Binance and Bybit, `BillingService`, TronGrid and BSC RPC readers, the Settings card, the pause of new entries on both exchanges). Differences from the sketch below: **identity is an operator-issued customer code plus the exchange account id(s), not an email account**; deposit addresses are at `m/44'/60'/0'/<customer>/<month>` (enumerable by the operator) instead of an index hashed from an installation id; statements are monthly (no weekly one); the base is the realized result of closed live trades (net of commission and funding); the watcher decides «paid» by the confirmed **balance** of the invoice's address and then reads the transfers for the receipt.

To avoid a merchant account and a registered company in the early stage, the fee is paid **only in USDT**, outside the exchange (`shared/invoice.ts`):

1. Each month the statement becomes an **invoice**: one exact amount (cents) to a **one-time deposit address** derived from an xpub (the seed stays offline with the operator; the server only derives addresses and watches them). Networks: **TRON (TRC-20)** and **BNB Smart Chain (BEP-20)**.
2. A watcher reads transfers to open invoices from a public chain explorer or node and feeds them to `matchPayment`: right network, the USDT contract, the invoice's address (case-insensitive on EVM only), not before the invoice, amount ≥ invoice (a cent of rounding forgiven), enough confirmations (TRON 20, BSC 15). An overpayment settles the invoice and the surplus is a credit; an underpayment does not settle it.
3. **Due in 7 days; 7 more of grace.** After that, and only then, CandleLab **pauses its own new entries** (`entriesPaused`). Open positions and the user's funds are never touched.
4. There are no subscriptions and no auto-debit: the user always sees the amount before sending it.

What this does *not* remove: receiving USDT is still income. The operator's **tax, reporting and AML obligations, consumer-protection rules and the terms of service** apply wherever they live, and "performance fee on someone else's trading" may be regulated as a service in some jurisdictions. This needs a lawyer and an accountant before the first charge; it is a design note, not legal advice.

## Data: where candles live

- **Hosted:** one shared, central candle store (a year of 1m candles for every USDT perpetual is a few GB); cached backtest jobs keyed by the parameters hash plus a data version, so identical tests are free. Live and paper need **no** historical candles at all: they read recent bars from the exchange.
- **Local (today):** the person's own archive in `data/candles/1m`. Never forced: the guided download offers **last 3 months, all tokens** (≈ 10 min), **12 months** (≈ 25 min), and **only the tokens you will test** (a few megabytes, `POST /strategy-lab/data/topup`). Tests never call the exchange API.
- **A strategy someone else made needs no candles:** import it (a file, see STRATEGY_SPEC.md) and follow it in paper, or run it live behind the same guards (exchange stop-loss, typed confirmation, capital limits). Testing it on history is optional.

## The library

Qualifying tests are kept automatically as candidates (local; see STRATEGY_SPEC.md). A shared pool is opt-in, rules only, ranked by forward evidence.

## Hosting

The **landing** is a static site (`npm run landing:build` → `dist/landing`). `vercel.json` makes Vercel build exactly that: `buildCommand: npm run landing:build`, `outputDirectory: dist/landing`, security headers, immutable asset caching. Set `VITE_APP_URL` in the Vercel project to point the «Спробувати» buttons at the app (or a waitlist) once there is one; without it a hosted page sends visitors to the «Запустіть CandleLab на своєму комп’ютері» section. The app itself is not hosted yet: it needs the server (API keys, SQLite, background jobs).
