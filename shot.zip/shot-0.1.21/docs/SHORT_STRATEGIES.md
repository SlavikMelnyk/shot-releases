# Short strategies: result of the multi-study research program (12 October 2026)

The owner asked for a few hours of testing "different scenarios related to shorts", internet ideas included, and for the best optimal strategies at the end. Six independent studies ran in parallel on the local 1m store (674 USDT perpetuals incl. 151 delisted, 2023-01 → 2026-10-12; no Binance calls). Their full reports are in [docs/research/](research/) (copies of the git-ignored `data/lab/research/reports/`), the scripts in `scripts/research/<topic>/`, and the shared brief with the cost model and validation protocol in [research/BRIEF.md](research/BRIEF.md).

**Cost model everywhere ("stress")**: taker fee 0.07% + slippage 0.2% per side, real funding (a short receives positive rates), 1× isolated, 1m exits with adverse-first ordering, entry at the next bar's open. Account views: 1000 USDT, 50 USDT (5%) margin per trade, one position per token, fixed margin (not compounded), results by exit year. The lab's default costs (0.05% + 0.05%) are kinder; do not mix the two.

## 1. Answer in short

1. **One strategy family is worth a forward-paper test: the loud-spike pocket**, now with better exits (`LIVE-1`). It is the only thing found that is positive in every calendar year after stress costs, and nothing tried made its entry measurably better. It was found on the same history it is tested on, 337 of its 410 trades fall after mid-2025, and 2023/2024 have only 28/21 trades. **It is a candidate, not a proven edge.**
2. **Exits do not add return; they can lower risk.** Holding to the bottom, scale-outs and wave re-shorts all lose against the plain «one stop + one target» exit. The only supported change is a profit-lock (stop to entry after a 15% fall): same return, drawdown 14.0 → 11.3% and worst trade −22.6 → −14.9 USDT. It is backtest-only until the paper/live runner can replace a stop.
3. **Three weaker, post-hoc candidates** (paper/shadow only): the daily volume-climax short (H3c), the MA50 cross-down trend short, and the day-1 «no pump» listing short. Their monthly P&L is nearly uncorrelated with the pocket (correlation +0.21, −0.01, −0.23 with each other), which is the one good reason to track them, but each was found after many looks and none has a confidence interval that excludes zero after selection.
4. **Everything generic loses after costs**: funding/carry shorts, crowding, listing decay, delisting proxies, overextension/RSI/Bollinger shorts at multi-day horizons, breakdown and dead-cat shorts, cross-sectional weakest-decile shorts, calendar effects, BTC-hedged baskets (the profit is BTC beta). Roughly 10,000 variants were counted across the studies (overextension ~8,600, trend ~800, listing subgroup scan ~800, web ideas ~300, exits ~235, funding/crowding 83 stand-alone signals), so any single «winner» among them needs a forward test before it means anything.
5. Nothing here has been armed. The owner's bar before real money stays: **≥ 40 closed forward-paper trades per variant with a positive average after costs.**

## 2. Ranked list

| # | Strategy | Status | 2023 / 2024 / 2025 / 2026-ytd | Total | Max DD | Worst trade | Live-compatible |
| --- | --- | --- | --- | ---: | ---: | ---: | --- |
| 1 | **Loud-spike pocket v2 + `LIVE-1` exits** | forward-paper candidate | +10.7 / +6.9 / +35.1 / +40.4% (388 trades) | +93.1% | 11.7% | −19.8 USDT | yes |
| 1b | same + profit-lock after −15% (`BT-1`) | backtest only | +12.0 / +7.3 / +34.9 / +37.7% | +91.9% | 9.1% | −14.6 USDT | no (needs stop replacement) |
| 2 | Daily volume-climax short (H3c, k = 20) | shadow / paper only | −0.7 / +4.9 / +10.8 / +15.6% (449 trades) | +30.5% | 13.2% | −38% of notional | not implemented |
| 3 | MA50 cross-down trend short (BTC > SMA100, ATR trail) | shadow / paper only | +3.8 / +6.1 / +53.9 / +3.3% (max 10 open) | +67.0% | 31.6% | −100% of notional (one liquidation-size trade) | not implemented |
| 4 | Day-1 «no pump» new-listing short | shadow only | −5.9 / +16.7 / +43.2 / +7.4% (296 trades) | +61.4% | n/a | −35% of notional | not implemented |

Reference: the previous baseline (`u-v2-3`, stop 25%, cooldown 12 h, 10 slots) is +10.4 / +7.4 / +33.3 / +42.9 = +94.0% (410 trades, DD 14.0%). At the live cap (5 open, cooldown 24 h) it is +86.6% (`LIVE-0`).

### 2.1 Loud-spike pocket v2 with `LIVE-1` exits (saved as `u-v2-live-1-4`)

Entry (unchanged from `u-v2-3`): the 15m series of a USDT perpetual rose ≥ +20% over 24 h and the peak is ≥ +50% above the 24 h low; 24 h volume ≥ 8× the previous week's average day; the peak bar is ≤ 1 h old and has an upper wick ≥ 6%; short on the first 15m bar that closes ≥ 12% under the peak (only the first qualifying bar of an episode); 24 h quote volume ≥ 1M USDT.

| Parameter | `LIVE-0` (previous) | **`LIVE-1`** (recommended) |
| --- | --- | --- |
| stop | +25% from entry | peak +5%, never farther than 25% from entry (`stopLoss: peak`, `stopPeakBufferPct: 5`, `stopMaxPct: 25`) |
| target | pre-spike base +25% | pre-spike base +25% |
| max hold | 120 h | 120 h |
| cooldown after a stop | 12 h | 24 h |
| max open | 10 | 5 (the live limit) |
| leverage / margin | 1× isolated, 50 USDT fixed | same |

At the live cap: `LIVE-0` +86.6% → `LIVE-1` +93.1% (388 trades, PF 1.63, worst trade −19.8 vs −22.6, funding −129 vs −154 USDT). The gain is **+6.5 points, 95% interval [−3, +16]**, i.e. inside the noise; the peak stop is a structural invalidation (above the blow-off high) and a least-regret tweak, not an improvement that was demonstrated. The 5% buffer sits on a plateau (3% → 81.0, 4% → 88.5, 5% → 93.1, 6% → 90.6, 8% → 88.2, 10% → 86.6 total). A cooldown of 24–48 h has the lowest drawdown; cooldown 0 has the highest (16.0%). The 5-slot cap costs about 7.5 points against the 10-slot run, so the 94% figure is not reachable in live.

Last 12 months in the lab, stress costs (`u-v2-live-1-4`, 13 Oct 2025 → 11 Oct 2026): +77.0% on 1000 USDT, 259 trades, 67.6% wins, PF 1.81, max drawdown 7.4%, worst trade −16.4 USDT, no liquidations.

At 2× everything doubles: `LIVE-1` +186.2% (DD 23.3%, worst trade −39.6 USDT), `BT-1` +183.7% (DD 18.3%, worst trade −29.1), no liquidations at stops ≤ 25% (the 2× liquidation distance is +49%); a stop of 60% or none is where 2× breaks (71–100% of trades liquidated). Slippage on squeezed small caps will be worse than the model, so keep 1×.

Execution realism checks (from the web-ideas study): at entry the first 5 minutes trade a median 3.8M USDT (p10 0.73M); an extra 0.8% slippage per side (1.0% total) still leaves +8.2 / +5.8 / +18.4 / +29.7% (+62% total). The BTC move over the hold has no relation to the trade result (correlation −0.03), so a BTC hedge does not help (+91.4% hedged vs +94.0%). Calendar effects are null (permutation p 0.24–0.82). Funding is a real cost (−16, −2, −103, −66 USDT per account-year at 50 USDT margin; 3–23% of the gross profit), and skipping extreme-funding entries does not help.

Optional **shadow gates** to log (not to trade): peak-bar taker-buy share > 0.505 (the worse tercile: +1.9% vs +5.9% per trade, permutation p = 0.10; as a skip gate +81.3% on 274 trades, PF 1.87, DD 10.8%); candle-crowding gate (1h run-up before the peak ≥ ~29%, or peak-area volume climax ≥ ~26×, or taker-buy share between peak and entry ≤ ~0.47: per-trade +6…+9% vs +5%, DD 5–9% vs 14%, but fewer trades and a lower account total, with 4–11 trades per year in 2023–2024); a funding stop (close once funding paid reaches 6% of notional: +7.6 points on v2, worst trade −45% → −30%, but the 3% version hurts v1). None passed the validation bar.

### 2.2 Profit-lock (`BT-1`, backtest only)

`LIVE-1` plus: after the 1m low touches entry × 0.85, move the stop to the entry price (a ratchet; nothing is sold). Drawdown 9.1% (vs 11.7%), worst trade −14.6, PF 1.81; bootstrap probability that the drawdown is lower 0.97–0.98. A threshold of −15% to −25% is a plateau (92 / 97 / 96); −10% is too tight (relief bounces of 8–15% are routine). To make it live: when the loop sees the position's low reach entry × 0.85, cancel the exchange stop and place a `STOP_MARKET` at the entry price. Binance's native `TRAILING_STOP_MARKET` only takes a callback of 0.1–10%, so only a trail up to 10% can be native (10% after a 15% fall: +83–84% with 9.7% drawdown). A profit-lock stop at the entry price fills exactly when the market moves against the position, so real slippage can exceed the 0.2% in the model.

Not implemented in the engine or the runners: suggested engine field `lockAfterFallPct` (and `stopSchedule`); `cooldownHours` applies only after stops, never after targets or time exits; `takeProfit: base` silently drops entries whose target is ≥ 0.997 × entry.

### 2.3 Daily volume-climax short (H3c_k20) — shadow/paper only

Found post hoc: the registered k = 5 version loses, but k = 10 was positive in every year. Dose-response in the volume multiple (a clean placebo with k = 0 loses 1.0% per trade): k 0 → −1.02%, 5 → −0.56%, 10 → +0.64%, 15 → +1.00%, 20 → +1.36%, 30 → +1.90% per trade.

Rule: universe all USDT perps incl. delisted, 24 h quote volume ≥ 1M. Day D (UTC): close > open, quote volume ≥ 20× the average daily quote volume of days D−30…D−1, and high(D) / lowest low of D−14…D−1 − 1 ≥ +50%. Day D+1 closes red. At its close (00:00 UTC of D+2) enter short at that open. Stop entry × 1.25; target = runHigh − 0.618 × (runHigh − runLow) with runHigh the highest high of the 6 days up to D+1 and runLow the lowest low of the 21 days up to D+1 (skip when the target is not ≥ 5% below the entry); time stop 30 days; 1× isolated; 7-day cooldown per token.

Result: 449 trades, −0.7 / +4.9 / +10.8 / +15.6%, total +30.5%, max DD 13.2% (MAE-stressed 18.0%); average +1.36% per trade, win 69% (avg win +12.8%, avg loss −23.9%), 29% end at the stop. Half-years positive in 6 of 8. **The cluster-bootstrap 95% interval of the average trade is [−0.34%, +3.11%] (includes zero); a 60-minute entry delay cuts it to +0.48% per trade (+10% total); break-even slippage is ~0.9% per side; the edge is almost absent before mid-2025** (+0.45% per trade vs +1.95% after). Selecting parameters on one half and testing on the other: 2 of 10 positive one way, 0 of 10 the other.

Why it is interesting anyway: the events *without* a pocket entry nearby are +2.0% per trade, i.e. it is the only multi-day source of return that is not the pocket in disguise. Pocket v2 alone +95.8% (DD 13.7%) vs pocket + H3c-without-pocket +123.6% (DD 18.3%, 703 trades; halves +14.1 / +109.5% vs +8.6 / +87.2%). Rule for the forward test: log signals and entries at 00:00 UTC; judge after ≥ 150 forward trades; stop if the average falls below +0.5% or the forward bootstrap interval is entirely negative.

### 2.4 MA50 cross-down trend short — shadow/paper only

Rule: universe all USDT perps except USDCUSDT/PAXGUSDT/XAUTUSDT, delisted included; on the close of UTC day i: day volume ≥ 5M USDT; close[i] < SMA50[i] and close[i−1] ≥ SMA50[i−1]; SMA50[i] < SMA50[i−10] (falling average); **BTC daily close > its SMA100**. Short at 00:00 UTC of day i+1 (fill = open × 0.998); initial stop = entry + 3 × ATR14 (simple mean of 14 daily true ranges up to day i); trailing stop = min(stop, lowest low since entry + 3 × ATR14) updated every minute; exit at max(stop, open) × 1.002; maximum 60 days; 1× isolated; one position per token. About 590 signals per year (2,252 in 3.8 years, average hold 26.8 days, 38 open on average, peak 153).

Evidence: +8.72% per trade net (cluster t = 3.3, n = 2,252), median +6.1%, win 57%, by exit year +10.5 / +5.3 / +10.6 / +9.1%; positive in both token halves, all liquidity tiers, delisted and live tokens; unchanged by a 1-hour or 1-day entry delay; MA20–MA75 all +5…+8.7%, MA100–150 about zero. Accounts (1000 USDT, 5% margin, 1×): 10 slots +3.8 / +6.1 / +53.9 / +3.3% (total +67.0%, DD 31.6%); 20 slots +20.4 / −13.3 / +88.3 / +10.1% (+105.5%, DD 54.9%).

Why it is weak: it was found after ~800 looks (best of ~270 correlated cells); an honest year-by-year walk-forward over the same grid retains **+4.5% per trade (cluster t = 1.5), median −0.8%, win 49%**; tails are heavy (1st percentile −38%, worst −100% = liquidation-sized, 81% of trades end at the trail); signals cluster so basket drawdowns are 30–60% of the allocated capital; 2025 contributes most; only 17 of 36 months with trades are positive; the unconditional «short every liquid alt when BTC > SMA100» has the same exit and earns +4.9% per trade, so the cross-down adds ~3.8 points; the whole effect could be one factor (the alt bear market). Shorting decliners *without* the BTC filter loses (breakdown shorts −3.6…−5.0% per trade when BTC is below its SMA100).

### 2.5 Day-1 «no pump» listing short — shadow only

Short 24 h after a new listing's first candle only if the first-24h high stayed < 20% above the first open (296 of 519 listings); stop +25%, hold 7 days: −5.9 / +16.7 / +43.2 / +7.4% (296 trades, +61.4%, worst −35%). Listings that pump 20–100% on day 1 lose for shorts (−3.5% at 7 d). Found by a subgroup scan of ~800 cells; concentrated in listings after 2024-07 (before: +0.2%, after: +9.5%); family-wise permutation p ≈ 0.19–0.24. There is no robust stand-alone «new listings decay» edge: the median short of a young token wins, but the right tail (13–49% of 7–30-day shorts see +33% against; 1–16% are wiped out at 1×) eats the mean.

### 2.6 Leverage check: `LIVE-1` at 1×, 2×, 3× and 5× (13 October 2026)

Lab engine (`scripts/lab_sweep.ts`, specs in [research/leverage-specs.json](research/leverage-specs.json), raw output [research/leverage-sweep.txt](research/leverage-sweep.txt)), same entry, stress costs, 50 USDT fixed margin, ≤ 5 open, cooldown 24 h, calendar years run independently. At 5× the isolated liquidation is at about +19.4% from entry (+32.7% at 3×, +49% at 2×), i.e. closer than the `LIVE-1` stop (peak +5%, up to 25%).

| Variant | 2023 / 2024 / 2025 / 2026 (% of 1000) | Total | Worst-year drawdown | Liquidated trades | Live module accepts |
| --- | --- | ---: | ---: | ---: | --- |
| 1× | +10.7 / +6.9 / +35.9 / +41.5 | +95.0% | 12% | 0 | yes |
| 2× | +21.3 / +13.8 / +71.7 / +83.0 | +189.8% | 23% | 0 | yes |
| 3× | +32.0 / +20.8 / +107.6 / +124.5 | +284.9% | 35% | 0 | yes |
| 5×, stop as `LIVE-1` (peak +5%, cap 25%) | +57.6 / +40.7 / +136.2 / +184.6 | +419.1% | 53% | 138 of 387 (36%) | no: the trader rejects a stop deeper than 80% of the liquidation distance (about 15.5% at 5×) |
| 5×, stop cap 15% | +37.3 / +34.0 / +100.7 / +95.4 | +267.4% | 55% | 0 | yes |
| 5×, stop cap 12% | +22.0 / +31.9 / +122.1 / +144.9 | +320.9% | 45% | 0 | yes |
| 5×, stop cap 10% | +10.6 / +29.3 / +107.0 / +162.1 | +309.0% | 39% | 0 | yes |
| 5× with 10 USDT margin (same 50 USDT position as 1×) | +11.5 / +8.1 / +27.2 / +36.9 | +83.7% | 11% | 138 | yes |

Reading: leverage scales profit and drawdown together and buys no efficiency (total return ÷ worst-year drawdown is about 8 at 1×, 2× and 3×, 7–8 at 5× with a 10–12% stop, 4.9 with a 15% stop). At 5× the original stop sits behind the liquidation, so 36% of trades are liquidated and the account effectively trades a 19% stop; the tighter stops that fit inside the liquidation distance lower the win rate to 47–55% in 2025–2026 (64–66% at 1×; normal squeezes hit them), so profit grows only 2.8–3.4× for 5× the exposure and the 2025 drawdown is 39–55% of the account. The engine charges no liquidation fee and assumes a fill at the liquidation price; real liquidations on thin tokens are worse.

**Compounding, cross-margin variant (the configuration of a Lab run on 13 Oct 2026):** `LIVE-1` rules, 10,000 USDT start, margin 3% of the *current* account per trade at 5× (= 15% of the account as position size), cross margin, ≤ 10 open, cooldown 1 h, stress costs. Last 12 months: +1,026%, drawdown 24%, 295 trades. Whole history 2023-01-01 → 2026-10-12 (one run, 55 s, no liquidations because cross margin never liquidates a single position, 433 trades, PF 1.48, 65% wins): **+1,679%, max drawdown 33.4%, funding −32,091 USDT vs fees −5,575**; growth by year +38% / +25% / +125% / +359%, i.e. 83% of the total profit comes from 2026 because every trade is sized on a compounded balance. This is the same per-trade edge as the 1× rows above, amplified by compounding and by the best year; it is not comparable with the fixed-50-USDT isolated rows and it is not live-compatible (cross margin and percent sizing are paper-only).

## 3. Combination check (this synthesis)

`scripts/research/combine/streams.ts` (output in [research/combine-streams.txt](research/combine-streams.txt)) runs the three multi-day/spike streams as separate account rules (each: 5% margin, 1×, ≤ 10 open) and correlates their monthly realized P&L (by exit month, 46 months, 2023-01 → 2026-10):

| | pocket v2 | H3c (no pocket) | MA50 trend |
| --- | ---: | ---: | ---: |
| pocket v2 | 1.00 | 0.21 | −0.01 |
| H3c (no pocket) | 0.21 | 1.00 | −0.23 |
| MA50 trend | −0.01 | −0.23 | 1.00 |

| Account | 2023 | 2024 | 2025 | 2026-ytd | Total | Max DD |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| pocket v2 (baseline exits, 10 slots) | +10.4 | +7.4 | +29.7 | +48.3 | +95.8% | 13.7% |
| H3c without pocket (10 slots) | −2.1 | +9.8 | +8.8 | +12.0 | +28.5% | 8.6% |
| MA50 trend (10 slots) | +3.8 | +6.1 | +53.9 | +3.3 | +67.0% | 31.6% |
| pocket + H3c (10 slots) | +8.3 | +17.2 | +38.5 | +59.5 | +123.6% | 18.3% |
| pocket + MA50 (20 slots) | +25.5 | −4.3 | +122.4 | +38.3 | +181.9% | 50.2% |
| all three (15 slots) | +17.5 | +10.6 | +100.6 | +51.4 | +180.1% | 36.9% |
| all three (30 slots) | +43.4 | +15.1 | +144.0 | +68.4 | +270.9% | 59.0% |

Monthly P&L is near-uncorrelated, which is the reason to run the shadow streams side by side. The sums are **in-sample sums of post-hoc candidates** (the pocket was found on this history, H3c and MA50 after hundreds of looks): they are not forecasts, the drawdowns of the MA50 leg dominate, and the 30-slot account would need 3× the margin and 3× the slots the live module allows. The sum has 29 positive months out of 45 with trades (worst month −9.1%, best +37.5% of 1000).

## 4. What did not work (do not retry without a new idea)

| Idea | Result after stress costs |
| --- | --- |
| Hold to the bottom (no target, wide/no stop) | The median spike falls 40% from entry, but the mean unstopped return turns negative from day 5 (−12.7% at 30 days vs median +27.5%) and funding costs ~0.7% of notional per day; wide/no stops give drawdowns of 23–49% and liquidations |
| Scale-outs / partial closes | −8…−14 points of return for a small drawdown cut |
| Wave re-shorts | 2 of 36 configurations positive; gross edge before costs ≈ 0 |
| Time tightening, stall exits | no change |
| Pure funding carry (short the highest funding, with/without a BTC hedge) | 48 variants, all negative; funding income +0.83% per trade vs price −2.0% (stop) and costs −0.54% |
| Funding as a filter or exit on the pocket | fails the 3-of-4-years test; high funding after a run is *not* a better short (+1.9/+1.4% vs +7.4/+9.6% per trade) |
| Negative-funding continuation (the one robust cross-sectional fact: tokens whose shorts pay fall +0.73% more in 3 d, +1.58% in 7 d, t = 5–6) | the short pays −1.9%/week funding plus 0.54% round trip: net −0.68% |
| New-listing decay (short at age 0–60 days, hold 1–30 days) | median +2…+19%, mean −1.2…+2.3%, month-clustered \|t\| ≤ 1 in 41 of 45 cells |
| Age / listing filters on the pocket | no improvement (< 60 d +6.6%, 60–365 d +1.3%, ≥ 365 d +5.0% per trade; restricting to ≥ 365 d cuts the return +82 → +49%) |
| Opening-range shorts, delisting-proxy shorts | all negative (delisted tokens fall −31% in the last 30 days but volume *rises* into delisting, so volume-collapse proxies fail) |
| Overextension (7 pre-registered multi-day rules; 7,191 variants) | all seven negative in 2026; **the bigger the run, the worse the short** (+100% → +300% run: −0.9…+0.7% → −3.0…−7.2% per trade); precision 70–80% but losses (−15…−27%) outweigh wins (+11…+20%) |
| Breakdown / dead-cat / lower-high / weakest-decile shorts | −2.6% (t −2.0), −2.6% (t −3.5), −1.9…−9.1%, ≈ 0; a falling MA does not remove the pump tail (19% of 14-day shorts see +30% against) |
| Short-all-alts / long-BTC basket | passes the screen only through the BTC leg (+171 vs −24 for the alt shorts), 54% drawdown, −31.8% in 2026 |
| Literature signals (MAX, taker-buy exhaustion, volume-up, green streaks, turnover, Amihud, size, daily reversal, weekly jump variance, 15-minute reversal) | per-trade −0.4…−2.9%; the 15-minute reversal has 1.3 bp gross vs 5 bp cost |
| Calendar/session effects | 1–6 bp per hour vs ~54 bp basket round trip; pocket permutation p 0.24–0.89 |
| BTC hedge on the pocket | no effect (correlation −0.03) |
| Exits conditioned on the daily candle (pocket day-close exit) | +95.8% → +82.4% |

## 5. Data and tooling findings

- **Delisted symbols: the stored «last candle» is a flat zero-volume forward fill, not the settlement.** For 146 of 151 delisted tokens `manifest.last` (mostly 2026-09-30) is such a tail; the real last trade is the last candle with volume (months to years earlier). Delistings per year by the last volume hour: 2023 9, 2024 30, 2025 46, 2026 66. A short held through the tail simply settles at the last price, and liquidity filters remove flat days, so the studies are unaffected, but engines that treat ended tokens by `c.n` see them as alive-but-frozen. `docs/SPIKE_RESEARCH.md` and the earlier note «a delisted token's last candle is treated as the settlement price» are corrected accordingly.
- `data/lab/research/market.json` is a chained *median* of daily returns (it decays from 1 to 0.0024) and is not a tradable index; the equal-weight mean alt basket earned +19.6% per year against BTC +53%.
- Funding intervals changed from 8 h (91% of prints in 2023) to 4 h (85% in 2026), with some 1 h tokens; features should use income per day.
- Engine limits noted by the studies: runs were capped at 400 days (since 13 Oct 2026 the Lab accepts up to 5 years; the store starts on 2023-01-01, so longer spans are cut there) and open trades are marked open at the period end; dailyLossLimitUsd counts realized losses by exit day only; partial/limit and target fills are charged the 0.2% slippage too (conservative for limit orders).

## 6. Assumptions a live trader would break

- Liquidity and slippage on small, freshly pumped tokens (0.2% per side is a stress assumption; a stop at +25% on a squeezed small cap can fill much worse, and a profit-lock stop at the entry price fills when the market runs against it).
- Funding on freshly pumped tokens averages −0.7%/day for shorts and can be far larger after a regime change.
- Borrow/short availability and margin tiers at the moment of a spike; delistings settle at a price that may differ from the last candle.
- Execution delay: the backtest enters at the next 15m bar's open after the signal bar closes; polling adds seconds. The daily rules (H3c, MA50) enter at 00:00 UTC, when the daily open and funding stamp make slippage worse than 0.2%; H3c breaks even at ~0.9% per side.
- Slots: the live limit was 5 open trades when the studies ran (20 since 13 Oct 2026, at the owner's request); in clusters (market-wide pumps) signals are skipped, so the 10-slot results are not reachable live.
- Selection: the pocket was found on this history, ~235 exit variants were then tried on it, and every other candidate came from a grid. Everything except the *risk* effect of the profit-lock should be treated as unproven.

## 8. Reproduce

Reports and per-study reproduction commands: [research/](research/) (`listing-age.md`, `funding-crowding.md`, `web-ideas.md`, `overextension.md`, `spike-exits.md`, `trend-momentum.md`). Scripts: `scripts/research/<topic>/`; the account helper `scripts/research/portfolio.ts`; the combination check `npx tsx scripts/research/combine/streams.ts`. The lab preset `loudLive1` («Гучний спайк v2 · LIVE-1 (стрес-витрати)») on the **Стратегії** page reproduces the `LIVE-1` run on the last 12 months with stress costs.
