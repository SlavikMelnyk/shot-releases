# Leaderboard of strategies on the same conditions

Added 14 October 2026 at the owner's request: *«a leaderboard of strategies that, when displayed, calculates ALL strategies on the same starting amount and the same leverage, so that comparison and sorting are the simplest.»*

The tab is **Лідерборд** in the Strategy Lab (`/app/strategies/board`; the older **Рейтинг** tab ranks the same saved versions by evidence level and keeps the backtest, paper and live records apart: it is not replaced). Code: `shared/leaderboard.ts` (the contract), `server/lab/leaderboard/*` (the computation), `src/components/lab/Leaderboard.tsx` (the page). Everything below is a **historical simulation on the local candle store**; a row is not a forecast and a high rank is not proof.

## The conditions (`LEADERBOARD_CONDITIONS`, id `lb1`)

Every strategy is re-run by the lab engine with the same account, the same size per entry, the same leverage, the same costs and the same time window. The id changes with any number below, which makes every stored result stale.

| | Value | Why |
| --- | --- | --- |
| Account | **1000 USDT** at the start | The account of the saved-plan tests (docs/MOVERS.md «Тест планів на фіксованих умовах») |
| Size per entry | **100 USDT of margin**, fixed | The «Обережний» profile of those tests: ten positions fit in the account, so the margin check is the same for everyone |
| Leverage | **1×** | The builder has no list of options, only a number field whose lowest value is 1 (`strategyParamsSchema`: integer ≥ 1); the plan tests' «Обережний» profile is 1× as well. The position equals the margin, nothing is borrowed, so a size or a leverage a strategy was tuned with can no longer decide its rank |
| Margin mode | **Isolated** | A liquidation takes the margin of that trade only; a strategy tested with Cross is run isolated here |
| Fee | the **standard taker fee of the strategy's own exchange** (`MARKETS[venue].takerFeePct`: Binance 0.05 %, Bybit 0.055 %, …) | Read from the exchange registry, never from a list in this feature |
| Slippage, funding | 0.05 % per fill (the lab's default); funding from the stored real rates; maintenance margin 0.5 % | |
| Window | the **last 365 full UTC days of the exchange's local candle store**, cut at the first complete day of the store | One window per exchange, the same for all its strategies. It ends at the newest *complete* day, so a tail top-up in the middle of a day changes nothing and the window moves once a day. A store with less history gives a shorter window and the row says so (`period.clipped`) |
| Stress costs | fee `max(exchange taker fee, 0.07 %)`, slippage 0.2 % | `STRESS_COSTS`, the lab's own stress values (docs/TRUST_LAB.md, the `costs` check) |

**What stays the strategy's own:** entry rules and filters, exits (stop, target, scale-out levels, a part at the first target, breakeven, trailing, time limit), token list and turnover filter, signal timeframe, exchange, the open-position cap, entries per day and the pause after a stop. **The daily loss limit** is a USDT amount tied to the strategy's own account, so it is scaled to the same share of the 1000 USDT account (500 USDT on a 10,000 USDT account becomes 50). Its own size, leverage, margin mode, account, fee, slippage, funding switch and period are replaced (`conditionedParams()` in `shared/leaderboard.ts`; a test checks that two strategies with the same rules and different sizes, leverage, accounts, margin modes and costs get identical inputs and identical results).

Each strategy is computed **twice** in the same pass: with the leaderboard costs and with the stress costs.

## What a row shows (`NormalisedResult`)

Strategy id, name, version, `fingerprint` (the library fingerprint of the rules, stable across renames), `runKey` (the cache key), exchange, type, `computedAt`, `dataThrough`, the period, tokens (with candles in the window / that traded), trades, wins, end equity, **ROI %**, **stress ROI %**, **max drawdown %** (on the closing curve, as in every lab test), win rate, average trade (% of the 100 USDT margin), profit factor (null without losses), liquidations, the **evidence** (below), and `thin` with its reasons:

* fewer than 90 days of history, fewer than 10 tokens, fewer than 30 trades (the `sample` check's bar), or more than 2 % forward-filled minutes (`LEADERBOARD_CONDITIONS.thin`).

**Evidence** is the level and the number of the ten checks passed from the strategy's **own** reliability check (a check is made on the strategy's own conditions and takes ~15 engine runs, so the leaderboard does not repeat it for every row). It is never «proven» and is shown as *Не перевірено* when no check was made. Because of this the page says plainly that the evidence column and the numbers come from different runs.

Sort keys (`LEADERBOARD_SORTS`): stress ROI (**default, because ranking by plain profit rewards luck**), ROI, drawdown (less is better), trades, tokens, win rate, average trade, profit factor, evidence level, checks passed, computed at. A missing number sorts last in either direction; rows without a result come after the ranked ones. Filters: exchange, type (`family:side`), hide thin data. The functions (`sortRows`, `filterRows`) are pure and shared.

## What a rank means, and what it does not

The same conditions make the rows **comparable**: the same account, size, leverage, costs and window remove the differences that come from how a strategy was set up. They do **not** make a high rank evidence:

* it is a simulation of the past, on the same data the idea was most likely chosen on (selection bias); the more ideas are tried, the likelier it is that the top row is the lucky one (multiple testing);
* no order book, no latency, no partial fills; the stop-before-target rule inside a candle is the lab's;
* the evidence column is the strategy's own check, the nearest thing to a counterweight, and it is advice only.

The page says this in a callout above the table. Nothing here changes the capital guard, the typed `REAL MONEY` step or any live limit, and nothing on the page can open a position.

## What is ranked

* The user's saved strategies: the **latest non-archived version of each name** (`latestVersions`).
* **Imported** strategies, marked *«тест виконано тут із вашими свічками»*: nothing was tested for them before, this is the first test, made with the owner's candles.
* ~~Historical research strategies~~ — removed on 17 October 2026 (owner's request): no research rows, no `historical` count.

A strategy that **cannot** be computed (no candles for its exchange, no token of its list in the store, rules that fail validation) shows the reason and no numbers; one whose computation **failed** shows the engine's message and is retried only by «Перетестувати» or «Перерахувати все», not by opening the page.

## How it is computed

`StrategyLab.leaderboard` (`Leaderboard` in `server/lab/leaderboard/service.ts`), nothing runs until the page or the hub asks.

* **Pass over the candles, shared by a group.** Reading and decompressing a year of 1m candles for ~700 tokens is the cost (about 28 s); one more strategy on the same candles costs about 4 s. Strategies of one exchange with the same token list are therefore run together in batches of up to 8 (`batchSize`): the candles of each token are read once for the whole batch (`runBatch`, `run.ts`).
* **Own driver, same engine.** `runBatch` uses the engine's own functions (`aggregate`, `symbolUnits`, `rulesUnits`, `portfolio`, `equityGrid`, `summarize`), but gives every strategy the history it would get **alone** (its own warm-up before the window). `runSpecs` gives every spec of a run the *longest* warm-up, so a spec's first days (which entries are still open, which tokens are resting) depend on its batch mates; a cached result must not. A test shows both: the same strategy alone and next to one with a longer warm-up gives identical outcomes here, different ones in `runSpecs`; and the result equals `runSpecs` of the strategy alone. The two differ only when a gap in a token's candles straddles the start of the warm-up (a few minutes of priming).
* **Background queue** (`queue.ts`): a bounded `WorkQueue` (1 batch at a time by default, `concurrency`), priority first (a single re-test and the hub's request go first, strategies that have never been computed before the stale ones), cancellable, with per-strategy states `queued` / `computing` / `ready` / `stale` / `failed` / `unavailable` and a progress counter. The batch yields to the event loop after every token and idles 25 % of its work time (`idleRatio`) so the live module and the panel keep their breath.
* **It gives way.** A test or a reliability check of the user pauses it (`waiting`, nothing is read); a candle download or tail refresh makes it drop the batch and start it again afterwards (the store changed, a mix of two states would be wrong). It never holds the lab's one-test slot, so a test or a download is never refused because of it.
* **Cache** (platform database key `lab.leaderboard`, one entry per strategy): a result is fresh when its key equals the strategy's current key, `conditions id : hash of the rules as they run on the conditions (window included) : hash of the data` (exchange, end of the window, the resolved token list, the funding-file count). Opening the page reads the cache and costs milliseconds; only a new, changed or stale strategy is computed (stale-while-revalidate: the old numbers stay visible with a «рахується…» / «у черзі» tag and a progress bar). Renaming a strategy or running its reliability check recomputes nothing. A failed computation is cached too (with the same key) so a broken one is not retried in a loop.
* **The page** opens, shows the cache, and posts `refresh` for what is stale (at most once per 10 s; «Зупинити» keeps it stopped until the person asks again).

### Measured on this machine (14 Oct 2026, the real local store: 674 Binance tokens, 365 days, 328 M candles)

| | Time |
| --- | --- |
| One strategy, normal + stress (the whole pass) | 28–36 s |
| Three strategies in one pass | 31 s |
| Eight strategies (seven on all tokens, one on three) | 57 s at full speed, **100 s with the default 25 % idle share** while the real app was running; peak memory 0.75–0.8 GB |
| The page opened again with nothing changed | `state()` 4 ms, `refresh()` 14 ms, nothing queued |

So a hundred strategies on «all tokens» take roughly 15–20 minutes in the background after a new day of candles (every result goes stale once a day, when the window moves). Those figures are from synthetic strategies that mostly lose money; heavier ones (long holds without a stop) keep more price paths in memory.

## API (`/api/strategy-lab/*`, local session token)

* `GET leaderboard` → `LeaderboardState`: the conditions, the window of each exchange, the rows (with their state, result or reason), counts per state, the progress.
* `POST leaderboard/refresh {scope?: 'stale' | 'all', strategyId?}` → 202 and the state. `strategyId` is a saved strategy (`u-…`) and puts that one first. Classified `free` in `server/remote/policy.ts` like the other lab tests (it computes and stores nothing but the cache).
* `DELETE leaderboard/refresh` stops the queue; what was computed stays.

For other modules: `lab.leaderboard.normalisedResultFor({ id, name, params, version?, runId?, source?, evidence? }, { force? })` returns the fresh cached `NormalisedResult` or computes it now (ahead of the background work) and rejects with an `AppError` and the reason when it cannot; `peek()` returns the fresh one or null and never computes. The strategy need not be saved (the community hub asks for the rules of a test result; the cache keeps it under the id it gives). `LeaderboardTab` takes an `extra(row)` slot for more row buttons.

## Tests

`shared/leaderboard.test.ts` (conditions, window, `conditionedParams`, sorting and filtering), `server/lab/leaderboard/queue.test.ts` (concurrency, priority, cancel, requeue), `leaderboard.test.ts` (a synthetic 450-day exchange: identical results for strategies that differ only in their own size and leverage; parity with `runSpecs` for the spike and rules families, plain and stress; independence from batch mates; cache hit, stale-while-revalidate, a new day, a tail top-up, other conditions, shared computations; progress, batches, cancel, waiting for a test, restart after a download; failure and unavailable rows; the hub's function; HTTP routes), `leaderboard.i18n.test.ts` (every server reason has an English text), `src/components/lab/leaderboard.render.test.ts` (both languages, states, sorting, filters, accessibility). `server/remote/policy.test.ts` fails on an unclassified route.

## Not done, and limits

* The evidence is the strategy's own reliability check; the checks are not re-run on the leaderboard conditions (about 15 engine runs per strategy).
* Windows differ between exchanges when their stores differ (a short Bybit history gives a short window): the row shows its own period and the thin-data flag; the filter by exchange is the honest way to compare.
* One CPU thread: the batch shares the event loop with the app (a worker thread would give true parallelism but not less work).

## Across markets (16 October 2026)

A strategy belongs to no market, so the board now computes it on **every market that has candles** on the same conditions (`lb1`; each market's own standard taker fee, its own window of the last 365 days of its store) and ranks the STRATEGY. `LeaderboardStrategy.baseId` / `LeaderboardRow.baseId` is the strategy; the entry of its own market keeps its id (cache, hub and saved test unchanged), the entries of the other markets are `<id>@<market>`, made with the same rules as a multi-market test (`StrategyLab.paramsForMarket`: the market's contracts and fee) with no saved test and no reliability check of their own. A historical research strategy stays on its own market. The page's default view **«Усі ринки разом»** (`src/components/lab/BoardMarkets.tsx`, numbers in `shared/leaderboardMarkets.ts`): one row per strategy, one coloured column per market (the stress-cost return), and **the median** of the stress returns over the markets that have a result (a thin-history market, MEXC, stays in its column but is left out of the median while another market has a result), how many markets are positive, the worst market and the trades; sortable by the headers. **«Кожен ринок окремо»** is the old flat table (a row per strategy × market, venue filter, the hub's publish buttons). The median is a way to order simulations on past data, not a forecast and not proof; one lucky market cannot carry it, and the number of positive markets is beside it. Computation is the same background queue as before (about 28 s of reading per market's candles, shared by every strategy of that market), so the first full board takes a few minutes and then only what changed is recomputed.

## The shape of a run (16 October 2026)

Besides the summary numbers, every result now carries the shape of its main run for the strategy page (docs/STRATEGY_LAB.md «The list and the page»): `curve` (the account in percent of the start, at most 96 points plus the peak and the low), `months` (realised result and trades per month) and `exits` (trades per exit reason). They come out of the same pass over the candles (`server/lab/leaderboard/run.ts`), cost a few kilobytes per result and never change a number of the table. A cached result that predates them is treated as stale: recomputed in the background, its numbers shown meanwhile.
