# Control CandleLab from your phone

Added 14 October 2026 at the owner's request: «add phone control right away, and a simple, clear instruction with the steps the user must take».

**What this is.** CandleLab cannot run on a phone. The engine, the data and the exchange key stay on **your computer** (or a small always-on machine). The **phone is a remote control**: you see the state, run backtests and paper, switch new entries on and off, and press «Стоп усе». It opens the same panel in the phone's browser, which you can add to the home screen so it behaves like an app. There is **no native app** (nothing in the App Store or Google Play).

**What it is not.** It is not a way to trade from anywhere without your computer: when the computer is off, asleep or offline, CandleLab is not running, and the phone says so. CandleLab never exposes itself to the open internet: the only road from the phone to the computer is your private [Tailscale](https://tailscale.com) network.

## The six steps (as the user sees them; the same list is in **Settings → Phone**)

1. **Install Tailscale on the computer and on the phone** and sign in to the **same account** (free for personal use). [Computer](https://tailscale.com/download) · [App Store](https://apps.apple.com/app/tailscale/id1470499037) · [Google Play](https://play.google.com/store/apps/details?id=com.tailscale.ipn). In the Tailscale admin console (DNS page) MagicDNS and «HTTPS Certificates» must be on; the setup command tells you if they are not.
2. **Run one command in the CandleLab folder:** `npm run remote:setup`. It checks Tailscale, publishes CandleLab on your tailnet (`tailscale serve`), asks for a **password** (twice, input hidden; use a phrase of 4 random words, at least 12 characters), writes the two `.env` lines, restarts CandleLab, checks that the door is locked, and prints the **https address and a QR code**.
3. **Open the address on the phone** (scan the QR code with the camera) and **sign in** with the password. The phone must have Tailscale switched on.
4. **Add to the home screen.** iPhone: Safari → Share → «Add to Home Screen» → Add. Android: Chrome → ⋮ → «Install app» (or «Add to Home screen»). The app then opens with one tap, without the browser bar.
5. **Keep the computer on and online.** `npm run app:up` starts CandleLab in the background and, on a Mac, keeps the computer from sleeping (`caffeinate -i -s`, only on AC power for `-s`; the screen may go dark; `npm run autostart:on` brings CandleLab back after a crash and after you log in; `npm run doctor` checks the settings; full guide: [LAPTOP.md](LAPTOP.md)). A closed laptop lid, a manual sleep, a power cut or a lost network stops CandleLab. Exchange-side stop-losses that are already on the exchange keep protecting open positions, but nothing manages trades until CandleLab is back. For round-the-clock use later: a small always-on machine or a VPS (see **Advanced** below).
6. **Optional: push alerts on the phone with ntfy.** Install the free ntfy app, subscribe to a long random topic (Settings → Phone shows a ready one, and it works like a password), add `NTFY_TOPIC=that-topic` to `.env`, run `npm run app:restart`, and press «Send a test alert». Every new phone sign-in and every burst of failed sign-ins is sent this way (and to Telegram or a webhook if you set those up; see `.env.example`).

The wizard (first start) shows a card **«Control from your phone»** on its last step that opens these steps.

### If it does not open: the five usual causes

1. **Tailscale on the phone is off or in another account.** Open the Tailscale app: it must be on, and your computer must be in its list.
2. **The computer is asleep or off, or CandleLab is not running.** On the computer: `npm run app:status`; if it is not running, `npm run app:up`.
3. **The address is not the one it was.** Renaming the computer changes it. `npm run remote:status` shows the current one; `npm run remote:setup` updates everything.
4. **HTTPS is not turned on in Tailscale.** Admin console → DNS → MagicDNS and «HTTPS Certificates»; then `npm run remote:setup` again. (A first `tailscale serve` also needs «Serve» enabled once; the command prints the link.)
5. **The password is refused, or «Too many attempts».** Tap the eye icon to see what was typed (a phone keyboard may change the case). After a few mistakes sign-in is blocked for a while (see below); an already open session keeps working. You can always set a new password on the computer: `npm run remote:setup`.

## Commands

| Command | What it does |
|---|---|
| `npm run remote:setup` | The whole setup above. Safe to repeat: an existing password can be kept («Keep it? [Y/n]»), a publication that is already ours is left alone, `.env` ends up byte for byte the same when nothing changed. Options: `--port N` (CandleLab's port, default from `.env`), `--https-port N` (the tailnet HTTPS port, default 443; use another when 443 already serves something else; the host entry then carries `:N`), `--lang uk|en`, `--no-restart`. |
| `npm run remote:status` | Is it on, which address, how many phone sessions and sign-ins, and whether Tailscale publishes our port. Never prints the hash. |
| `npm run remote:off` | Removes `REMOTE_PASSWORD_HASH` and `REMOTE_HOSTS` from `.env`, turns off **our** Tailscale publication only (`tailscale serve --https=<port> <local port> off`, never `serve reset`, so your other publications are untouched), restarts CandleLab. Every phone session stops working at once. Safe to run twice. |
| `npm run remote:hash` | Only asks for a password (hidden) and prints the `REMOTE_PASSWORD_HASH=…` line, for a machine where `remote:setup` cannot run (Docker, see below). Touches nothing. |
| `npm run pwa:icons` | Redraws the app icons from `public/favicon.svg` (deterministic; the PNGs are committed). |

`remote:setup` writes **only** `REMOTE_PASSWORD_HASH` and `REMOTE_HOSTS`: every other line, comment and the line ending of `.env` stay exactly as they were (the file is replaced atomically and set to mode 0600). It never prints the password and never runs `tailscale` with anything but `version`, `status --json`, `serve status --json` and our own `serve` line. The tailnet command is the documented current form (`tailscale serve --bg --https=443 3001`; [docs](https://tailscale.com/kb/1242/tailscale-serve)). On macOS the CLI of the Tailscale app is found at `/Applications/Tailscale.app/Contents/MacOS/Tailscale` (run with `TAILSCALE_BE_CLI=1`); on Windows in `C:\Program Files\Tailscale`.

## Keeping the phone link on the newest `main` (19 Oct 2026)

The phone shows what the computer's copy of CandleLab serves, so the link is only as new as that copy. `npm run follow:on` (a source checkout only; `follow:off`, `follow:status`, `follow:now` are the rest) starts a small watcher (`scripts/follow.mjs`, log `data/follow.log`, state `data/follow.json`) that every minute:

1. fetches the branch and, when the remote is ahead and nothing here is uncommitted, fast-forwards this checkout (it never pulls over uncommitted files and never merges);
2. waits until the newest commit has been quiet for 90 seconds (the owner's tooling commits in bursts);
3. builds it NEXT to the running copy (`dist.next`: types, the browser part, the server, the hub) and, only if all of it builds, swaps it in. A change that only touches the browser part (the compiled server and shared files are byte-identical) replaces the pages in place and restarts nothing; a server change restarts the app and puts the old files back if the new server does not answer;
4. **never restarts while any entries switch is on** (Live on any exchange, practice trading): a restart turns entries off by design, so it waits, says so in `follow:status` (`note`) and goes in once they are off. A candle download that a restart cuts short continues by itself (`server/lab/history.ts` `resumeInterrupted`; one the person stopped does not).

It starts again with the app (`app:up`, autostart) while it is on. The installed phone app picks a new version up on the next open: the app page is fetched from the network first and the service worker's cache name changes with every build. It touches no data, no `.env`, no key; it arms nothing.

## The security model, in plain words

CandleLab controls real money, so remote access has to be strong and must never be open by accident.

**What protects what**

| Layer | What it does |
|---|---|
| CandleLab listens on `127.0.0.1` only | Nothing on the network can reach it directly. `tailscale serve` is a local proxy that carries requests from your tailnet to that loopback port. `HOST` can only be set to something wider together with remote mode, otherwise the server **refuses to start**. |
| Tailscale | Only your own signed-in devices are on the tailnet; traffic is encrypted end to end; the HTTPS certificate is issued for the host name. Nothing is published to the internet (`serve`, never `funnel`). |
| Exact host name | A request is «remote» only when its `Host` header is exactly one of `REMOTE_HOSTS` (no wildcards, case-insensitive). **Every other Host is refused** (this is the DNS-rebinding protection of the local app, kept). `X-Forwarded-Host` is never read. |
| Proxy markers remove local trust | A request that carries `X-Forwarded-*`, `Forwarded`, `Via`, `X-Real-IP` or `Tailscale-*` headers is **not** the person at the computer, whatever its `Host` says. So a device on the tailnet cannot get password-free access by forging «Host: localhost» (the proxy adds these headers). Local trust also needs a loopback socket (matters when `HOST` is wider, as in Docker). |
| The password | `POST /api/login`: scrypt (N=2^16, r=8, p=1, random salt) checked in constant time; only the hash is in `.env`; the password is never logged, stored or returned. Two checks at a time at most, over-long input refused unhashed. |
| Rate limiting | Per client address and for everybody: 3 free attempts, then 2 s, 4 s, 8 s … up to 15 min; 10 failures from one address lock it for an hour; 30 failures from anyone lock everybody out of **signing in** for 30 minutes. A blocked attempt is refused before the password is hashed and does not extend the block. Password checks cannot be started in parallel: one per client and four in all run at a time, a further one is answered «Too many attempts» at once (otherwise hundreds of guesses could be in flight before the first failure is counted). Open sessions are never affected by a lockout. Answers are generic («Could not sign in. Check the password.»). |
| The session | 256 random bits in the cookie `__Host-shot_session` (`HttpOnly; Secure; SameSite=Strict`, host-only); the server keeps only its SHA-256 in `data/platform.sqlite`. Ends after **30 days without use** (sliding) or **90 days** from sign-in, when you sign out (this device or all), or when the password changes. At most 20 sessions. Every API call also needs the `x-shot-token` of the session (a different secret per session and per server start). |
| Origin / cross-site | The `Origin` of a remote request must be `https://<one of the hosts>`; `Sec-Fetch-Site: cross-site` is refused, and so is `same-site` for the remote host (another computer of your tailnet shares its domain). A request that carries `Tailscale-Funnel-Request` (it came through Tailscale **Funnel**, the open internet) is refused whatever its Host says, and `remote:setup` refuses to go on while a Funnel or a raw TCP forward (`serve --tcp`, which adds no proxy headers) leads to CandleLab's port. Responses carry `Cache-Control: no-store`; the remote host gets HSTS. |
| Password again for real-money actions | From a phone, arming live, changing live or paper limits, changing any settings, switching an approach to LIVE, preparing a strategy for live, and billing consent need the password **typed again within the last 10 minutes** (`POST /api/stepup`), on top of the typed `REAL MONEY` phrase. |
| «Стоп усе» is always one tap | «Стоп усе», disarming («Вимкнути нові входи»), closing a position, stopping the bot and signing out **never** ask for the password again (they only need a signed-in session). The table of every route is `server/remote/policy.ts`, and a test fails when a new mutating route is not classified. |
| Alerts | Every new phone sign-in («New sign-in from a remote device» with the device, e.g. «iPhone · Safari», and the time) and every burst of failed sign-ins (5 in 10 minutes, or a lockout) is journaled and sent to the in-app feed and to ntfy / Telegram / webhook if configured. |
| Offline honesty | The page never shows numbers older than 30 s as if they were live (see below). |

**What is NOT protected**

- Someone who has your **unlocked phone with an open session**, or access to the computer itself. Keep the phone locked; use «Sign out everywhere» (Settings → Phone) if it is lost, and change the password.
- A password you reveal, reuse or pick badly. The setup asks for a long phrase but cannot make you keep it secret.
- A device you **share into your tailnet** or tag-based access you grant: it can reach the sign-in page (not the app without the password).
- A malicious proxy in front of CandleLab that **strips** the forwarding headers **and** a hostile member of your own tailnet who forges a loopback `Host` through it. `tailscale serve` adds identity and forwarding headers, so this does not apply to the supported setup; if you put your own proxy in front, make sure it adds `X-Forwarded-For`, or do not use it.
- **Local trust is decided by the absence of proxy headers**, because `tailscale serve` reaches CandleLab over the loopback address like a browser on the computer would. `tailscale serve` (an HTTPS reverse proxy written with Go's `Rewrite`) deletes any `X-Forwarded-*` a client sends and always sets its own `X-Forwarded-For` and `X-Forwarded-Host`, so a peer can neither remove nor forge them. Anything else that puts a path to CandleLab's port without those headers breaks this: a raw TCP forward, a different proxy, a tunnel. `remote:setup` and `remote:status` look for a raw TCP forward and a Funnel in `tailscale serve status --json`, but nothing sees a tunnel you add later: do not forward CandleLab's port in any other way. (A separate listening port for remote requests would remove this dependency; it is not built yet.)
- Anything that happens on the exchange outside CandleLab. Your exchange key should stay IP-restricted, with only reading and futures rights (CandleLab advises this and never calls a withdrawal endpoint).
- The first sign-in over plain `http` is not blocked by CandleLab: the `Secure` cookie simply is not stored by the browser, so it cannot work; use the `https://` address.

**Adversarial review, 14 October 2026** (tests in `server/remote/{hostile,remote,access,limiter,policy,bind}.test.ts`, mutation pass on a scratch copy). What it found and fixed: a parallel burst of wrong passwords was all hashed before the limiter counted the first failure (now one check per client and four in all at a time); `Host: [::1].anything` passed for `[::1]` (now an exact match); a request through Tailscale Funnel was treated like any remote one (now refused, and setup refuses while a Funnel or a raw TCP forward leads to CandleLab); `remote:off` could switch off another service on the same Tailscale port (now left alone); `same-site` pages of the tailnet could reach the remote host (refused); the session cookie is now `__Host-` prefixed; an oversize body was a logged 500 (now 413). What it could not close: local trust still rests on the proxy's headers (see the list above), and everything that needs a real tailnet is in the last section.

**Where the data lives.** `REMOTE_PASSWORD_HASH` and `REMOTE_HOSTS` in `.env`; the session hashes and a sign-in counter in `data/platform.sqlite` (table `remote_sessions`, key `remote.stats`). A rate-limit state is in memory only (a restart needs you at the computer). `GET /api/remote/status` returns booleans and counts only (no password, hash, session id or host name) and is session-protected.

**Local use is unchanged.** On the computer itself (`http://127.0.0.1:3001`, `localhost`, `[::1]`) there is no password, as before. Remote mode adds a second door; it does not lock the first.

## What the phone shows when it cannot reach the computer

- The installed app opens (its shell is cached by a service worker) and says **«Немає зв’язку з вашим комп’ютером»** / «Cannot reach your computer», with **no data at all**, and asks again every few seconds.
- If the connection is lost while the page is open, or nothing has been answered for **30 seconds** (or two requests in a row failed), a banner appears and the data under it is **dimmed and not clickable**; «Live ON/OFF» in the top bar turns into **«Live ?»** (an unknown state is never shown as OFF). «Стоп усе» stays in the top bar; if it cannot be delivered the dialog says so and points to the exchange app.
- The service worker (`src/pwa/sw.js`, registered only over HTTPS or on localhost, versioned cache with cleanup) caches **only the static shell**: `/app/` and its hashed files, the icons, the manifest. It never touches `/api` and never stores a response that is `private` or `no-store`; tests run it in a sandbox and read its source to prove it.

## Phone layout

At 375 px: the top bar always carries the page title with the environment (**MAINNET** / **TESTNET**), the **Live ON / OFF / ?** chip and **«Стоп усе»**; the bell's count is on «Ще», language and theme moved into the «Ще» sheet, where «Sign out on this device» also lives. Tap targets are at least 44 px, fields use 16 px text (no zoom on focus), safe-area insets are respected, there is no horizontal scroll, and the typed `REAL MONEY` box opens the keyboard in capitals with auto-correct off. A pull-down reload cannot trigger anything: nothing destructive is a GET, and every action is a button press with a confirmation dialog.

## Advanced: an always-on machine, a VPS, Docker

For 24/7 operation put CandleLab on a small machine that stays on and runs `npm run remote:setup` there (Tailscale installed on it). Keep the exchange key IP-restricted to **that machine's** address (the home address will no longer be the one that trades). Never open port 3001 or 443 of the machine to the internet; the firewall should drop everything inbound except SSH (or use Tailscale SSH). Start it with `npm run app:up`, or with a systemd unit / the Docker restart policy.

**Docker (provided, untested).** `Dockerfile` and `docker-compose.yml` in the repo root:

```sh
npm run remote:hash                     # prints REMOTE_PASSWORD_HASH=… ; add it to .env, together with REMOTE_HOSTS=<your-machine>.<tailnet>.ts.net
docker compose up -d --build            # the data volume is named shot-data
tailscale serve --bg --https=443 3001   # on the HOST: publishes the container's loopback port on your tailnet
```

- `HOST=0.0.0.0` is set **inside the container only** and only together with `REMOTE_PASSWORD_HASH` and `REMOTE_HOSTS`: Compose refuses to start without them, and the server itself refuses a wide `HOST` without remote mode.
- The port is published to the **host's loopback only** (`127.0.0.1:3001:3001`), so nothing outside the host can reach it, and `tailscale serve` on the host is the only road in.
- Inside the container the local no-password door is closed by design: a request from the Docker bridge is not a loopback socket, so every request needs the password (the health check runs inside the container and is local).
- Behind Docker's port publishing every request arrives from the bridge address, so the sign-in rate limiter sees **one client** (it only reads `X-Forwarded-For` from a loopback connection): someone on your tailnet who fails ten times locks sign-in for everybody for an hour (open sessions and «Стоп усе» keep working; `npm run remote:setup` on the host cannot reset it, restart the container).
- State (`data/`, including the SQLite databases and candles) lives in the `shot-data` volume. Back it up like `data/` (see DATA.md).
- **Not verified:** nobody has run this image, a Compose `env_file` with `required: false` needs Compose 2.24 or later, Tailscale inside a container (a sidecar) is not covered, and the Python downloaders in the image have not been run.

## Environment reference

| Variable | Meaning |
|---|---|
| `REMOTE_PASSWORD_HASH` | `scrypt:<log2 N>:<r>:<p>:<salt>:<hash>` (base64url). Written by `remote:setup` / `remote:hash`. A malformed value makes the server refuse to start (the message never repeats the value). A cost below N=2^14 is refused. |
| `REMOTE_HOSTS` | Comma list of exact host names (`my-mac.tail1234.ts.net`, optionally `:port` when the tailnet HTTPS port is not 443). No wildcards, schemes, paths, IP addresses or `localhost`. Up to 8. A `*.localhost` name is allowed and also accepts a plain-http origin (how the remote path is tried out on one computer without a certificate). |
| `HOST` | Listening address. Default `127.0.0.1`. Anything else needs both variables above, or the server refuses to start (if your shell exports a `HOST`, unset it). |

Remote mode is on only when **both** the hash and at least one host are set. With only one of them the server stays closed to remote requests and says so at start.

## Code map and tests

| Area | Files |
|---|---|
| Server | `server/remote/{index,access,hosts,password,sessions,limiter,device,policy}.ts`; the `/api` guard moved from `server/app.ts` into `remote.guard`; `server/config.ts` parses the three variables |
| Setup | `scripts/remote_setup.mjs`, `scripts/lib/remote.mjs`, `scripts/lib/remoteMessages.mjs` (Ukrainian and English) |
| Page | `src/components/remote/*` (sign-in, offline screen, offline banner, Live chip, password-again dialog, gate), `src/remote/*` (auth, connection freshness, step-up, install helpers), `src/components/settings/PhoneSection.tsx` (the guide), `src/remote.css`, the phone rules in `src/mobile.css` |
| App | `shared/pwa.ts`, `shared/brand.ts`, `src/pwa/sw.js`, `src/pwa/register.ts`, `scripts/pwa_icons.mjs`, `public/icons/*`, the plugin in `vite.config.ts` that emits `manifest.webmanifest` and `app/sw.js` |
| Words | `src/i18n/en/remote.ts` (English), `landing` FAQ «Can I use it from my phone?» |
| Tests | `server/remote/*.test.ts` (login, rate limit and lockout, cookie flags, expiry, host allow-list incl. a spoofed `X-Forwarded-Host` and a rebinding Host, loopback unchanged, step-up required and never for panic or disarm, a policy entry for **every** mutating route, remote refusal without config, `HOST` refusal, no secret in any response, journal or alert, English for every server text), `scripts/remote_setup.test.mjs` and `scripts/lib/remote.test.mjs` (injected exec and fs: no real `tailscale`, no real `.env`), `src/pwa/sw.test.ts` (the worker in a sandbox: never caches `/api`), `shared/pwa.test.ts` (manifest, icons exist with the declared size), `scripts/pwa_icons.test.mjs`, `src/remote/*.test.ts`, `src/api.test.ts`, `src/components/remote/remote.render.test.ts` (both languages, labelled controls, 16 px fields) |

## Verified, and not verified

Verified (tests and a browser at 375 × 812, in the isolated sandbox, over a `*.localhost` name that resolves to this computer): sign-in, wrong password, the cookie and the session across a reload, the guide and its illustrations, the offline banner after the server was stopped, «Live ?», and the honest warning in the «Стоп усе» dialog.

**Check once, from a second device on your tailnet (or the phone's terminal app), before you rely on it.** These three requests must all be refused; they are what the review of 14 October 2026 could only test against the code, not against a real `tailscale serve`:

```sh
H=https://<your-machine>.<tailnet>.ts.net
curl -s -H 'Host: localhost:3001' $H/api/session            # expect 403 «Лише локальний доступ.» (a forged loopback Host must NOT hand out the local token)
curl -s -H 'Host: 127.0.0.1:3001' -H 'X-Forwarded-For:' $H/api/session   # expect 403 (the proxy sets its own X-Forwarded-For; an empty or forged one changes nothing)
curl -s $H/api/status                                       # expect 401 «Потрібен вхід.»
```

If the first one returns a JSON `token`, **stop**: `tailscale serve` is not adding its forwarding headers in your version, so CandleLab cannot tell the proxy from the person at the computer. Run `npm run remote:off` and report it.

**Needs a real phone and a real tailnet** (not done here, nothing ran `tailscale`): `tailscale serve` on your machine and its exact first-run messages; HTTPS with the tailnet certificate; the install flow on iOS Safari and Android Chrome (the manifest, the icons, standalone mode, the iOS status bar); the **service worker** (the embedded browser used for the checks cannot register one at all; the worker is proven by sandbox tests and by reading its source); the real `X-Forwarded-*` / `Tailscale-User-*` headers that `serve` adds (the policy relies on them being present, and on `Host` being preserved); push alerts through ntfy; the phone keyboard behaviour (capitals for `REAL MONEY`, no zoom); Docker.
