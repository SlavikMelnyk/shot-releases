# CandleLab in short

<!-- This file is the hand-written core of the chat helper's knowledge (docs/ASSISTANT.md). It is written in English with the Ukrainian names of the interface in «quotes», because the helper answers in the language of the question. Every section is short on purpose: the helper receives only the few sections that fit a question. The `{#anchor}` after a heading is the stable id of the section (`faq-<anchor>`) that buttons and tests refer to. Keep it honest: no profit promises, no «proven», simulations are not forecasts. -->

## What CandleLab is {#what-is-shot}

CandleLab is a local research lab for crypto-futures trading ideas. You describe an idea in the builder («Конструктор»), test it on saved 1-minute candles of an exchange, run ten reliability checks that try to break the result, and only then follow it in paper («Paper», virtual money at real prices). Live trading with real money is a separate, manual step that only you take. CandleLab runs on your own computer: the engine, the data and the exchange keys stay there. It is not a signal service, not an adviser and not a marketplace.

## The path of a strategy {#path}

1. «Конструктор»: choose a type of idea, describe the rules (or say them in words), run a test on history.
2. «Мої стратегії»: a tested version can be saved; a saved version never changes (changing a rule makes a new version).
3. «Paper»: follow it with virtual money at real prices. The readiness advice is at least 40 closed paper trades over about two weeks with a positive result after costs, but that is advice, not a gate.
4. «Live»: real money on your own Binance or Bybit account. It needs an exchange stop-loss and your typed confirmation REAL MONEY; it drops back to off after every restart.
The sidebar shows these four steps.

## The builder and «Опишіть своїми словами» {#builder}

The builder is organised by strategy type: you pick the type first. Under it, the box «describe in words» turns a typed or dictated idea into parameters and shows the rules in plain words, the assumptions it made and any questions. It only fills the form: you press the buttons, and the test itself is always run by the deterministic engine, never by an AI. A type that cannot run in paper or live is refused there instead of being approximated.

## The ten reliability checks {#ten-checks}

After a test, «Перевірити надійність» runs ten deterministic checks: risk (is it near liquidation?), sample (enough trades and tokens?), consistency (stable across time windows?), other periods (rules re-run on data they were not tested on), costs (the result with higher fees and slippage), neighbours (small changes to the numbers), concentration (one lucky trade or token?), regime (up, down and flat markets), execution (stop and target inside one minute candle) and data (are the candles complete?). They test stability; they are not a search for better settings.

## Evidence levels {#evidence-levels}

The check gives one of four labels: «Замало даних» (insufficient data, under 30 trades), «Не витримує перевірок» (fails the checks), «Змішані результати» (mixed results) and «Витримує перевірки» (passes the checks). The best label is never «proven» and never a forecast: it only means the result did not break under these particular tests. The next honest step is forward paper.

## The leaderboard («Лідерборд») {#leaderboard}

The leaderboard recomputes every strategy on the same conditions: account 1000 USDT, 100 USDT margin per entry, 1x leverage, isolated margin, the standard taker fee of the strategy's exchange, 0.05% slippage and the last 365 full days of that exchange's local candles. It sorts by profit under stress costs by default, because plain profit rewards luck. Rows with thin data are marked. A high rank is a historical simulation, not proof; with many ideas tried, the top row is the likeliest to be lucky. «Рейтинг» is a different tab: it ranks by evidence level and keeps the backtest, paper and live records apart.

## Data and candles («Стратегії → Дані») {#data}

Tests always read the local candle store, never the live exchange, so they are fast and reproducible. You download candles yourself in the Data tab: choose the exchange, the period (3, 6 or 12 months, or your own start) and the tokens (top by turnover, all, or your own list). CandleLab shows the size and time before anything is downloaded, refuses a selection that does not fit the free disk, and can resume a stopped download. Roughly half a megabyte per token per month on Binance: the 30 most liquid tokens for 3 months are about 55 MB, every token for a year a few GB. Bybit downloads slower (hours for everything), and MEXC's public history is only about 30 days. The Data tab, the setup wizard and the website's disk-space estimator show the size for your choice before anything is downloaded. Without candles, the builder has nothing to test on, so the first thing to do is download some.

## Backtest, paper and live {#paper-live}

A backtest replays past candles with fees, slippage and funding. Paper follows the same rules on real current prices with virtual money: it avoids the look-ahead trap but is optimistic about fills. Live uses real orders on your exchange account: fills, latency and rejections are real. The three records are shown side by side and are never added together. Paper results are not proof of live results, and neither of them is a forecast.

## Live trading and safety {#live-safety}

Live is never started by CandleLab on its own, and no AI can start it. You arm it on the «Live» page by typing REAL MONEY. A stop-loss placed on the exchange is mandatory, a capital guard limits the size and the daily loss in code, and live always drops back to off after a restart. «Стоп усе» (stop everything) is in the top bar: it turns off new entries and closes CandleLab's trades; on a phone it never asks for the password again. This chat helper cannot trade, arm, change a limit or a setting.

## Exchanges («біржі»): Binance, Bybit, OKX, Gate, Bitget and MEXC {#exchanges}

Which exchanges can I use for tests, paper and live trading? Tests run on six exchanges (USDT perpetual futures): Binance Futures, Bybit, OKX, Gate, Bitget and MEXC. You download an exchange's candles in «Стратегії → Дані» and test rules on it; a second market is extra evidence, not proof. Paper (virtual money at real prices, no keys) runs on all six; on OKX, Gate, Bitget and MEXC it is new and still in testing. Live (real money) exists for Binance and Bybit (Bybit live is still in testing) and, in testing only, for OKX, Gate, Bitget and MEXC: those four were built and checked against fake exchanges but have never run on a real or demo account, so the first run is on the exchange's demo or test network (MEXC has none: the smallest size on the real account). Live is always armed by you, with the typed phrase. A strategy runs only on its own exchange. MEXC's public 1-minute history reaches back only about 30 days.

## The CandleLab fee («комісія CandleLab», payment, invoice) {#fee}

CandleLab is free to use and nothing is charged until billing is set up. The planned fee is 9% of the net profit of closed live trades on a real account, above a high-water mark (so a loss is recovered first), never 9% of the balance. It is paid only in USDT (TRON TRC-20 or BNB Chain BEP-20) to one-time addresses; the app only reads the chain and never spends. Not paying only pauses CandleLab's own new entries; it never closes your positions or touches your funds.

## Exchange keys: how to add a Binance or Bybit key («ключі бірж», «додати ключ») {#keys}

Keys never go through the browser. You type them only into the terminal command `npm run keys` (the input is hidden) or add them to the `.env` file by hand. CandleLab recommends keys with only Reading and Futures rights and an IP allow-list; a key with more rights is accepted, and CandleLab only advises turning the extra rights off. CandleLab never calls a withdrawal or transfer endpoint.

## Using CandleLab from a phone («телефон») {#phone}

CandleLab cannot run on a phone. The engine stays on your computer; the phone is a remote control over your private Tailscale network, set up with `npm run remote:setup` (Settings has a guide). It needs a password, real-money actions and settings ask for the password again, and «Стоп усе» never does.

## A laptop that sleeps or loses the internet («комп’ютер заснув», «пропав інтернет») {#laptop}

CandleLab notices sleep, a stalled clock and a lost connection. After waking it reconnects, checks what it missed, and never takes an entry for a signal whose candle closed while it was away. The exchange-side stop and target are what protect an open position while the computer is off. `npm run doctor` checks the setup; autostart and keep-awake are in Settings → «Стан комп’ютера».

## Privacy: what leaves your computer («приватність», «що надсилається») {#privacy}

By default nothing. Only what you choose goes out: a strategy you publish to the community hub (rules only), or strong strategies if you switch that on. Exchange keys, balances, trades and account ids never leave. The chat helper sends your questions, a few documentation excerpts and a small description of where you are (never your keys or account) to a free hosted model provider (Gemini, Groq or Cerebras); free tiers may use prompts to improve their products.

## This chat helper and the buddy {#helper}

The buddy is a cosmetic companion; in this chat it gives the helper a friendly voice and changes no number or advice. The helper uses only free hosted models, so it can be slow, rest when a free limit is used up, and be wrong. Its answers are not evidence of anything and not investment advice. It proposes buttons (open a page, fill the builder with an idea, open the Data tab); you click, and nothing runs by itself.

## What CandleLab and the helper will not do {#limits}

«Will this strategy make money?», «is it profitable?» and «should I go live?» cannot be answered with a promise or advice. A test is a simulation of the past, not a forecast. No investment advice, no price predictions, no promise of profit, no «this strategy works». A good-looking test is the cheapest thing to produce; CandleLab exists to help you find out whether it deserves trust. CandleLab's own research has not found a generally profitable rule after stress costs; some rules are only candidates for forward paper tests.

## Costs and words worth knowing {#costs}

Fees are paid on every entry and exit. Slippage is the gap between the expected and the real price. Funding is a periodic payment between longs and shorts on perpetual contracts. Leverage multiplies both gains and losses. Isolated margin risks only the margin of one trade; liquidation is the exchange closing a position because the margin is gone. Drawdown is the fall from the highest equity to the next low. Profit factor is the sum of wins divided by the sum of losses. A stop-loss is an order that closes a losing trade at a limit.

## Strategy files, candidates and the community {#files}

A strategy can be exported as a rules-only file (`shot.strategy/1`); a file carries no results, and an imported strategy is untested until you test it. Tests that clear a modest bar are kept automatically and only on your computer in «Кандидати»: leads, not proof. The community hub («Спільнота та дані») is optional; nothing is sent unless you publish or switch sending on.

## Installing and updating {#install}

People install from a signed release (a one-line command or a ZIP); the installer checks a signature and a checksum and needs no admin rights. The app tells you when a newer signed release exists and shows the command to run; nothing is installed from the page, and CandleLab never updates itself silently.

## Common problems {#problems}

No candles: open «Стратегії → Дані» and download some first. A test cannot start while a download runs; wait for it. The result looks too good: check the reliability verdict, the stress-cost return and the number of trades. Live does not arm: the Live page lists the blockers in plain words. The phone cannot connect: `npm run remote:status` on the computer, and check that the computer is awake.
