# Strategy spec, strategy files and the library of candidates

Added 13 October 2026. One reusable way to write a strategy down, one file to pass it around in, and a library that keeps the good ideas on its own.

## The spec (`shared/strategySpec.ts`)

A strategy is a **rules-only**, nested, versioned JSON document (`schema: "shot.strategy/1"`). It says *what* is traded, *what triggers*, *how it enters and leaves*, *how much it risks* and *what costs the test assumes*. It has no period and no results, so it can be shared without carrying "proof".

| Section | Holds |
|---|---|
| `meta` | name, notes, tags: never affect behaviour |
| `market` | venue (the market id of an exchange: `binance-usdm`, `bybit-linear`, `okx-swap`, … one per exchange, written as `specId` in `shared/venues/<id>.ts`; never renamed once files exist), side (`short`; `long` only for the rules type), universe (`all` / `recurring` / `tierAB` / `custom` + symbols, 24h turnover floor) |
| `signal` | `kind: "spike"` (the original type): bar size, look-back window, rise %, optional quality filters (0 = off); or `kind: "rules"` (the generic type): bar size (1, 5, 15, 30, 60, 240 min) and 1–6 `conditions` (`shared/conditions.ts`) |
| `entry` | one of `spike`, `rollover`, `pullback`, `turn` (each with only its own settings; the original type) or `nextOpen` (the rules type: the open of the bar after the conditions turn true) |
| `exit` | take-profit (`percent` / `base` / `rr` / `spike` / `atr` / `none`), stop-loss (`percent` / `peak` / `atr` / `none`), max hold, scale-out, trailing; `base`, `spike` and `peak` are the original type's, `atr` (a multiple of the ATR(14) of the signal bar) is the rules type's |
| `risk` | leverage, margin mode, sizing (`fixed` margin or `percent` of the account), limits |
| `costs` | fee, slippage, funding, maintenance margin |
| `testing` | the account size a test starts with: not part of the rules |

**Two types in one format (13 Oct 2026, [UNIVERSAL_BUILDER.md](UNIVERSAL_BUILDER.md)).** A spec with `signal.kind: "spike"` is written **exactly as before** (side `short`, the same keys), so every earlier file, library entry and fingerprint keeps its meaning; `server/lab/spec-pins.test.ts` pins eight fingerprints and spec texts, and `shared/rulesSpec.test.ts` reads a spec as the old code wrote it and writes it back byte for byte. A `rules` spec has `signal.kind: "rules"`, `entry: { "mode": "nextOpen" }` and may be `long`; the schema refuses a mix (a rules signal with a spike entry, a long spike) and the engine's own checks refuse the other combinations (`base`/`spike` targets and a `peak` stop for the rules type, ATR levels for the spike type, a trend whose fast average is not shorter than the slow one). Settings a type does not use never appear in its spec (a rules spec has no rise or look-back, a spike spec no conditions), so they cannot change its identity. The spike signal now also accepts a 4-hour bar (`timeframeMin: 240`).

`toSpec(params)` / `fromSpec(spec, period?)` convert to and from the flat parameters the engine runs. A spec keeps only what its choices make meaningful (a rollover entry has no pullback depth), so strategies that behave the same have the same spec: `identityOf(spec)` (the spec without name, notes, tags and `testing`, written with sorted keys) is what a fingerprint is made of. `specJsonSchema()` / `GET /api/strategy-lab/schema` publish the JSON Schema. Tests: `shared/strategySpec.test.ts` (round trip for every entry, exit and sizing kind, identity, schema, refusal of unknown keys and of parts that do not fit together).

```json
{
  "schema": "shot.strategy/1",
  "meta": {
    "name": "Spike rollover, stop 8%",
    "notes": "Short a token after it has fallen 10% from a +50% / 24h spike.",
    "tags": [
      "rollover",
      "short"
    ]
  },
  "market": {
    "venue": "binance-usdm",
    "side": "short",
    "universe": {
      "kind": "all",
      "symbols": [],
      "minVolume24hUsd": 2000000
    }
  },
  "signal": {
    "kind": "spike",
    "timeframeMin": 15,
    "lookbackHours": 24,
    "risePct": 50,
    "filters": {
      "maxWeekRisePct": 0,
      "minVolSurge": 0,
      "minRsi": 0,
      "minPeakWickPct": 0,
      "minPeakRisePct": 0,
      "maxHoursSincePeak": 0
    }
  },
  "entry": {
    "mode": "rollover",
    "dropPct": 10,
    "belowVwap": true,
    "minBarsSincePeak": 0,
    "waitBars": 96
  },
  "exit": {
    "takeProfit": {
      "kind": "percent",
      "pct": 10
    },
    "stopLoss": {
      "kind": "percent",
      "pct": 8
    },
    "maxHoldHours": 24,
    "partials": [],
    "breakevenAfterPartial": false,
    "trailing": {
      "pct": 0,
      "activatePct": 5
    }
  },
  "risk": {
    "leverage": 3,
    "marginMode": "isolated",
    "sizing": {
      "kind": "fixed",
      "marginUsd": 100
    },
    "limits": {
      "maxOpenPositions": 10,
      "maxEntriesPerDay": 0,
      "cooldownHours": 12,
      "dailyLossLimitUsd": 0
    }
  },
  "costs": {
    "feePct": 0.05,
    "slippagePct": 0.05,
    "includeFunding": true,
    "maintenanceMarginPct": 0.5
  },
  "testing": {
    "startBalanceUsd": 10000
  }
}
}
```

The saved-strategy card shows its own spec under **«Схема стратегії (JSON)»**.

## The file (`shared/strategyFile.ts`)

`{ "format": "shot.strategy", "version": 2, "exportedAt", "spec": {…}, "note" }`. Version 1 files (flat `params`) are still read. Import is defensive: size ≤ 32 KB, strict schema, names and notes reduced to plain text, nothing the file claims about results is kept (there is nowhere to put it). `GET /strategy-lab/strategies/:id/export`, `POST /strategy-lab/strategies/import`; in the app: **Мої стратегії → Імпортувати / Експорт**.

An imported strategy becomes a new version with `runId: null`: empty backtest, paper and live records, no reliability check, a **«З файлу · не тестувалось»** badge, readiness steps that say so. Importing switches nothing on. Live still needs an exchange stop-loss (`liveBlockers`) and the typed `REAL MONEY` confirmation by the user. **«Перевірити на історії»** puts its rules into the builder (the period and the data stay the user's own); a strategy can also go straight to paper without any candles.

## The library of candidates (`server/lab/library.ts`)

When a test finishes and clears a deliberately modest bar, its rules are kept **automatically and silently**, so the best ideas a person tried do not get lost with the test history. The bar (`shared/libraryBar.ts`) is about the quality of the test, not about promising profit: ≥ 30 trades, ≥ 5 % after costs, an exchange stop-loss, drawdown ≤ 35 %, liquidations < 5 % of trades, profit factor ≥ 1.2, a result that does not hang on three tokens, an account that survived.

- One entry per fingerprint of the rules, whatever the name or period; the best-scoring test is kept, with the count of qualifying tests seen. A reliability check later records how far the evidence got (a failing level sinks the entry).
- It is **a lead, never proof**: one simulation on one period. The **Кандидати** tab says so and offers *У конструктор*, *Експорт*, *Схема*, *Прибрати* (a dismissed entry does not come back).
- **Privacy.** The library lives in the local database (`lab.library`). Nothing is sent anywhere. For a future hosted service the intended design is: a shared pool is **opt-in**, holds rules only (the spec, never keys, balances, trades or an account), ranks by forward (paper and live) evidence rather than by backtests, and shows an entry's creator only if they choose to. Silently uploading people's ideas without consent is not part of the design. **Built on 14 October 2026 as the community hub ([HUB.md](HUB.md)):** publishing a rules file is an explicit act with a dialog that shows exactly what leaves, and sending strong strategies to the owner's database is off by default; with no hub address nothing is sent.
- API: `GET /strategy-lab/library`, `DELETE /strategy-lab/library/:fingerprint`, `GET /strategy-lab/library/:fingerprint/export`.
