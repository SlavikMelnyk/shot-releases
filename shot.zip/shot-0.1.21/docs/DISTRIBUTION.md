# Distribution: how a person gets CandleLab, and keeps it current

Added 14 October 2026 at the owner's request. The landing told people to install Node 24 and Python 3.9 and to run `node scripts/setup.mjs`, without saying where the app comes from («how users know from where to install the app? we have to make it super easy to fully install and make it work»). The source repository is private, so nobody can clone it. This document is the answer: a **signed release**, a **one-line installer** that needs nothing installed first, and a **verified in-place update**.

## What the person does

| System | One step | What they see |
|---|---|---|
| macOS, Linux | `curl -fsSL <base>/install.sh \| sh` in a terminal | a few lines of progress, then the browser opens on the setup wizard |
| Windows | `irm <base>/install.ps1 \| iex` in PowerShell | the same |
| Any (no terminal) | download `shot-<version>.zip`, unpack, double-click `Install CandleLab.command` (macOS) or `Install CandleLab.cmd` (Windows); Linux: `sh install.sh --from-dir "$PWD"` | the same |

`<base>` is `baseUrl` of `config/release.public.json` (see «Hosting»). Nothing needs to be installed first: no Node.js, no Python, no npm, no git, no administrator rights. The installer asks nothing and prints exactly where it puts things:

- the app goes to `~/SHOT` (macOS, Linux) or `%LOCALAPPDATA%\CandleLab` (Windows); `--dir` / `SHOT_HOME` change that;
- a Node.js 24 that is already on the machine is used; otherwise the official **portable** Node.js is downloaded into `<install>/runtime/` (nothing else on the system changes);
- launchers: `<install>/shot` / `shot.cmd` (`shot start|stop|restart|status|update|keys|doctor`; both are one line that hands the arguments to `scripts/shot.mjs`), macOS `~/Applications/SHOT.app` (no terminal window) and `CandleLab.command`, Linux `~/.local/share/applications/shot.desktop`, Windows Start menu and Desktop shortcuts;
- a **safe** `.env` is created only if there is none (testnet, trading off, no keys), CandleLab starts in the background, waits for `/api/health` and opens `http://127.0.0.1:3001/app/`. The first start shows the setup wizard (docs/SETUP.md). Real-money trading stays off until the person switches it on, as before.

Running the same command again is an **in-place update**: `data/` and `.env` are kept. `sh install.sh --uninstall` removes the app, the runtime and the launchers and **keeps the data**; `--delete-data` removes the whole folder, and only when it is recognised as a CandleLab install. `--dry-run` prints what would happen and uses no network and writes nothing.

## Architecture

```
private source repo ──npm run release──▶ release/<version>/            (on the owner's computer; nothing leaves it)
                                            shot-<version>.zip         one archive for every system (pure JavaScript; Node.js is not inside)
                                            shot.zip                   the same bytes under a name that never changes (the landing's «Download ZIP» link)
                                            latest.json (+ .sig)       version, url, sha256, size, minNode, publishedAt: signed with the release key
                                            SHA256SUMS (+ .sig)        every file's checksum: signed
                                            install.sh, install.ps1    the bootstrap installers, with the PUBLIC key and the address built in
        ──npm run release:publish──▶ a PUBLIC place (gh release create)     the owner decides when
user: curl … | sh ──▶ finds/fetches Node.js ──▶ node core.mjs install ──▶ fetch latest.json + .sig, VERIFY ──▶ download the archive, VERIFY sha256 + size
                                              ──▶ unpack (every path checked) ──▶ swap into place ──▶ launchers ──▶ scripts/setup.mjs (start, open the browser)
```

One implementation does all the work after Node.js is at hand: `scripts/installer/core.mjs` (plain Node, no dependencies, tested in `scripts/installer/core.test.mjs`). It is **embedded** into `install.sh` and `install.ps1` (so the script is self-contained: the key and the code that uses it come from the same file) and **shipped** in every release as `scripts/lib/installer-core.mjs`, where `npm run update` (`scripts/update.mjs`) uses the very same code. The bootstrap scripts only do what has to happen before there is a Node.js: detect the system, find or fetch Node.js, write the core to a temporary file, run it.

### What a release contains

`dist/` (the build: client, server, shared; no source maps, no compiled tests), `node_modules/` with **only the production packages the compiled server really imports** (found by scanning `dist/server` and `dist/shared`, then following each package's `dependencies`; type files, sources, tests, docs and `.bin` are left out, licences are kept: 81 packages, ~12 MB unpacked, **~3.8 MB zipped**), `package.json` (production dependencies and the run scripts), `scripts/` (`service`, `setup`, `setup_keys`, `update`, `remote_setup`, `doctor`, `autostart` and `scripts/lib/*.mjs`), `config/*.public.json`, `docs/*.md` (since 15 Oct 2026: the **public edition** of the documents the app and the chat helper refer to, i.e. the `SOURCES` of `server/assistant/knowledgeBuild.ts`, read from the finished build; every heading block that the helper's privacy rule would keep out of its knowledge pack, such as the owner's own account, a path on a disk or a personal name, is left out; flat `.md` files only, `publicDocs` / `publicDocument` in `scripts/release.mjs`), `.env.example`, `VERSION` (JSON: version, commit, dirty, builtAt), `install.sh`, `install.ps1`, `Install CandleLab.command`, `Install CandleLab.cmd`, `README.txt`, `LICENSE.txt` (a placeholder: the licence is the owner's decision), `NOTICE.txt` (third-party packages and their licences).

It never contains: `.env` or any `.env.*` other than `.env.example`, `data/`, `reports/`, anything under `docs/` but those flat public `.md` files, `src/`, tests, databases, logs, `*.pem`/`*.key`, `node_modules/.bin`, symbolic links, a secret or a key-looking string, the release signing key. This is not a promise in a comment: **the builder refuses to produce the archive** if the folder or the written archive holds any of it (`scanFiles` in `scripts/release.mjs`: a whitelist of top-level entries, forbidden file names, PEM blocks, `sk-ant-…`, `xprv…`, filled-in `*_API_KEY`/`*_SECRET`/`*_TOKEN` lines, and the exact private key bytes), and `scripts/release_verify.mjs` repeats the scan on the archive before publishing. Tests plant each kind of forbidden thing and assert the build stops.

Build isolation: the build runs in a **temporary copy of the sources** (`git ls-files` plus untracked-not-ignored files), with `node_modules` linked, so a release never overwrites the `dist/` of the running app. Without `--allow-dirty` the build refuses a working tree with uncommitted changes, so a release can be rebuilt from a commit. The zip is deterministic (sorted entries, fixed time stamp, fixed attributes): the same inputs give the same bytes.

## Python and Node.js

**Node.js 24** is the only runtime. The installer brings it. The built-in `node:sqlite` is the database, and every production dependency is pure JavaScript (checked: nothing in the release has a native addon).

**Python is no longer required by anything the app does.** The candle downloader that needed it was ported to Node (`server/lab/download/`, run by the app as a background child process of the same Node; `npm run backfill -- binance backfill --from 2026-08` by hand). It writes the same `SC1M` shards, the same `manifest.json` and the same funding files byte for byte (`server/lab/download/parity.test.ts` compares decoded planes with the original Python code on golden files and on a live Python run). The Python scripts stay in the repo for research (`npm run backfill:py`, the `scripts/*.py` studies); the older research lab and research paper sessions still start Python and now answer «a research feature, needs Python and the research scripts» in an installed copy.

## Hosting

The source repository stays **private**; releases live somewhere public. The base URL must serve, next to each other: `install.sh`, `install.ps1`, `latest.json`, `latest.json.sig`, `shot.zip` and the archive named in `latest.json` (a relative `url` is resolved against `latest.json`).

- **A. Recommended: a public GitHub repository `shot-releases`** (it holds no source, only releases). `baseUrl` = `https://github.com/OWNER/shot-releases/releases/latest/download`. `gh release create` uploads the eight files as assets of one release, atomically; `releases/latest/download/<file>` always points at the newest non-pre-release. One-liners: `curl -fsSL https://github.com/OWNER/shot-releases/releases/latest/download/install.sh | sh` and `irm https://github.com/OWNER/shot-releases/releases/latest/download/install.ps1 | iex`. For a stable short address, put the installers also in the repository's main branch (raw URLs are served as `text/plain; charset=utf-8`).
- **B. Static files on the landing domain** (the landing is already static, `vercel.json`): copy `release/<version>/*` to `landing`'s public folder, e.g. `https://example.com/dl/`, and set `baseUrl` to `https://example.com/dl`. Every release overwrites the same files; keep the old archive too if people may be mid-download.
- **C. Object storage** (S3, R2, Backblaze…): upload the eight files to one prefix with public read; set `baseUrl` to the prefix. Cache: short for `latest.json*` and the installers, long for the archive.

Windows caveat (unverified, see below): `irm … | iex` needs the answer to be text. GitHub release assets are served as `application/octet-stream`; if `irm` returns bytes there, use the raw URL of option A, option B, or the equivalent `iex (New-Object Net.WebClient).DownloadString('<url>')` (`install.ps1` is pure ASCII, so the encoding does not matter). **Test the Windows one-liner once on a real machine before announcing it.**

The address people use can be overridden without a new installer: `SHOT_DIST_URL` (environment) beats the built-in one, in the installers, in `npm run update` and in the app.

## The update model

- `GET /api/update` (behind the same session guard as every route) compares `VERSION` with the signed `latest.json` from the configured base URL, **at most once a day** (an hour after a failure, «Check now» at most once a minute), with two plain GET requests, a fixed `User-Agent`, nothing else sent: no identifier, no version, no cookie. It is **off** in a source checkout and while no address or key is configured. The answer is cached in the platform database, so a restart does not ask again.
- The app shows a quiet «Доступне оновлення x.y» line with the exact command (the installer one-liner for the person's system, the `shot update` launcher form, or `npm run update`), dismissible per version. **CandleLab never installs an update by itself.** Settings → About shows the real version, when it last looked, and «Check now».
- `npm run update` / `<install>/shot update` / re-running the installer all do the same verified update: stop the service, replace the app files (every top-level entry of the release is swapped; the old one is set aside and put back if anything fails), remove entries the new release dropped, keep `data/`, `.env`, `runtime/`, `reports/` and anything else that is not from a release, start CandleLab again.
- `<install>/.shot-install.json` records the version, the source (`url` or `folder`), the base URL, the key id and the entries the release installed.

## Environment variables

`SHOT_DIST_URL` (where releases are published), `SHOT_HOME` (install folder), `SHOT_NODE_MIRROR` (default `https://nodejs.org/dist`, for a mirror), `SHOT_LANG` (`uk`|`en`; otherwise `LC_ALL`, `LC_MESSAGES`, `LANG`; Ukrainian for `uk`, English for everything else). The downloader reads `SHOT_BINANCE_ARCHIVE`, `SHOT_BINANCE_REST`, `SHOT_BYBIT_BASE` and `SHOT_CANDLES_DIR` (tests and mirrors).

## Tests

`scripts/installer/core.test.mjs` (signature, tamper, update, downgrade, data kept, rollback, launchers, unpacking safety), `scripts/installer/installer.test.mjs` (the rendered `install.sh` run under `sh`, `dash` and `bash --posix` against a local server in a throw-away HOME: dry run, install, update, uninstall, tampered archive, tampered list, foreign key, no key, portable Node.js from a fake nodejs.org mirror and its checksum, cut-short download), `scripts/installer/install.ps1.test.mjs` (everything checkable without PowerShell), `scripts/shot.test.mjs` (the launcher's command map), `scripts/release.test.mjs` and `scripts/release_keygen.test.mjs` (the builder on a fake project, deterministic archive, forbidden content, key handling in a temporary HOME, the publish script with a fake `gh`), `server/update/update.test.ts` and `src/components/update/*.test.ts` (the check, the routes, the notice), `server/lab/download/*.test.ts` (the downloader). No test reaches a non-local host.

## Verified and not verified

Verified on macOS (arm64, Node 24.16): the whole chain with a real build: `npm run release` (in a temp copy, temp HOME, temp key) → the real `install.sh` against a local server → install, start (network guard on), `/api/health`, `/api/update`, the candle download through the packaged app against a local fake exchange, `shot update` to a newer version with data and `.env` kept, `install.sh --uninstall`. One real-network smoke of the downloader: BTCUSDT, one finished month from data.binance.vision plus a few REST calls on Binance and Bybit; the shard built by Node had the **same SHA-256 of its planes** as the one built by the Python script from the same real archive file.

**Not verified** (no such machine here): a real install from a real URL on **macOS with Gatekeeper**, **Windows** and **Linux**; the whole of **`install.ps1`** (checked for syntax-level properties only; PowerShell 5.1 behaviour, `irm | iex`, `Expand-Archive`, the shortcuts made through `WScript.Shell`, deleting a running `node.exe`); `curl | sh` through a corporate proxy; the portable Node.js download from the real nodejs.org (a fake mirror is tested); Alpine/musl (refused with a message); `CandleLab.app` launching from Finder (the plist and script are valid; not launched); a Windows `shot.cmd`.

## Decisions the owner must make

1. ~~Where releases live~~ (done: option A).
2. ~~The release key~~ (not needed: releases are unsigned).
3. The licence: no `LICENSE.txt` in the repository yet; the release has a `LICENSE.txt` template of the builder (read it before the announcement).
4. Whether to keep supporting `curl | sh` at all next to the ZIP route (it is the easiest for people, and the one with the least to check beforehand).
