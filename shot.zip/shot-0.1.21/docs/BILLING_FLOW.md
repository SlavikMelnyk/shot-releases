# USDT-only fee: the idea and the whole flow (decided and built, 14 Oct 2026)

Status (14 Oct 2026): **decided and built (stage 1).** The owner took every recommendation of §7 («as you recommended»); what exists now is described in [BILLING.md](BILLING.md), with the operator's cheat sheet. The branch `shot/feature/usdt-billing` was merged into `main` (8096545) and finished on top of it. Principles unchanged from [PRODUCT.md](PRODUCT.md): **9 % of net profit above a high-water mark**, never of the balance, **USDT only**, nothing charged for tests or paper, and not paying only pauses CandleLab's own new entries.

## 1. The idea in one paragraph

CandleLab is free to try. Backtests, reliability checks and paper are free forever. When CandleLab trades **real money** on your exchange account, it keeps a monthly statement of what those trades earned *net of exchange fees and funding*, and asks for **9 % of the profit above your best result so far**, paid in **USDT** (TRON or BNB Chain) to a one-time address. A losing or recovering month costs 0; small fees roll over; an unpaid invoice pauses only CandleLab's *new entries* after 14 days (open positions, stops and your funds are never touched). No card, no company account, no custody.

## 2. What the branch already does (reviewed)

Tests (`shared/billing`, `shared/invoice`, `server/billing`) pass in a clean export (52 tests, `tsc` clean). Strengths: pure fee rules reuse `settlePeriod`; mainnet-only live trades; monthly settle +24 h; carry < 5 USDT; invoice = one-time addresses per network from a **public** key (an `xprv` is refused); balance-based detection (confirmed state only: TRON `only_confirmed`, BSC `head − 15`), so no transfer parsing; networks never added together; overpayment → credit; the pause is a blocker on new entries only; the card (QR, tabs, copy, progress, statements) exists in UA/EN and both themes.

## 3. Review findings

| # | Severity | Finding | Proposal |
| --- | --- | --- | --- |
| 1 | High (operations) | **Gas.** A one-time address holds only USDT; moving it needs BNB (BSC) or TRX/energy (TRON). The doc says «sweep from your phrase» but gives no tool and no gas plan. | Ship `scripts/billing_sweep.ts` (offline signing): top up gas from a gas wallet, then sweep, per invoice; or batch. Document costs. |
| 2 | High (operations) | **The operator cannot see who paid.** Paths are two hashed 31-bit indices, so nobody can enumerate addresses; `billing_find` needs `installId` + month from the user. | See §5 (customer code with enumerable paths, or receipts). |
| 3 | Medium | **No consent step.** Billing starts when the operator's key is configured (`since` = that month), with no «I accept» by the user and no record of the terms version. | Terms modal at the first live arming, stored acceptance, `since` = the month of the first real live trade. |
| 4 | Medium | **The base is the local database** (`store.trades()`): editable. | Cross-check against the exchange's own income history (REALIZED_PNL, COMMISSION, FUNDING_FEE) for CandleLab's client-id prefix; flag a mismatch on the statement. |
| 5 | Medium | **Binance only.** It does not see Bybit live trades (new module, separate store) or the Bybit trader's pause. | Billing base = all mainnet live trades of every connected exchange; `setExtraBlockers` on both traders. |
| 6 | Medium | **No receipts / audit trail.** Paid = balance ≥ amount; the transaction hashes are not kept. | Record the transfers (txid, time, amount, network) when paid; downloadable statement + receipt. |
| 7 | Low | Rolling back the DB (or a fresh install id) wipes the books. | Accepted limit (§6); a signed voucher can re-establish state. |
| 8 | Low | The landing still says «nothing is charged». | Change only when billing goes live; wording in §8. |
| 9 | Merge | The branch touches `trader.ts`, `app.ts`, `config.ts`, `FeeCard.tsx`, `theme.css`, i18n; `main` has since gained Bybit live, staged exits, Bybit paper. Expect conflicts (mostly mechanical). | Merge after the current work is committed; re-run the full check. |

## 3a. Deposit schemes compared

| Scheme | Matching | Operator visibility | Sweeping | Replay / double claim | Verdict |
| --- | --- | --- | --- | --- | --- |
| **A. One-time address per invoice, hashed path (the branch)** | by address balance | none without the user | per invoice, needs gas | impossible | fine for a personal tool; weak operations |
| **B. One-time address, path from an operator-issued customer code** `m/…/n/month` | by address balance | **full**: scan issued customers × months | per invoice, needs gas (scriptable) | impossible | **recommended for early access** |
| C. One address per network + a unique amount tag (e.g. 12.3407) | incoming transfers to your address | full (one address) | none | tag collisions possible, user must send the exact amount | simplest ops, worst UX |
| D. Prepaid balance (top up, fee deducted monthly) | same as A/B for top-ups | as A/B | as A/B | impossible | **built 14 Oct 2026** on top of B (top-ups are invoices of kind `credit` at path attempts 64+); the pause rule did not change to «credit < 0»: it stays «a fee invoice is overdue», and a fee paid from the balance simply is not overdue (§9) |

## 4. The whole flow

```
USER                                   CandleLab APP (local)                          CHAIN / OPERATOR
────                                   ────────────────                          ─────────────────
0  Install, try: backtests, paper (free)
1  Arms live for the first time   →    Terms modal: 9 % of net profit above
   (typed REAL MONEY)                  your high-water mark, USDT only, how the
                                       pause works. «I accept» → acceptance +
                                       terms version stored; billing starts
                                       with this month
2  Trades live all month          →    Statement base = CandleLab's closed mainnet
                                       live trades, net of fees + funding
                                       (cross-checked with the exchange's income)
                                       Live estimate on the card
3  Month ends (+24 h)             →    Statement: result, new high-water mark,
                                       fee, carried (< 5 USDT rolls over)
4  Fee ≥ 5 USDT                   →    Invoice: due in 7 days; TRON + BNB Chain  ← addresses derive from the
                                       one-time addresses, QR, exact amount,        operator's PUBLIC key
                                       in-app alert (+ ntfy/Telegram if set)
5  Pays USDT from any wallet or exchange withdrawal (sends amount + network fee)  → transfer on chain
6                                      Watcher (90 s / «Перевірити оплату») reads
                                       the CONFIRMED balance → paid; overpayment
                                       = credit; receipt with txid
7  (not paid) day 7: overdue notice; day 14: new entries pause (positions,
   stops, funds untouched); paying lifts the pause automatically
8  Disputes: statement lists every trade (CSV); an operator-signed voucher
   (waive / credit / extend) can be pasted into the app
                                                                                 Operator: scan issued customers,
                                                                                 gas top-up, sweep (offline signing),
                                                                                 ledger CSV for accounting/tax
```

### Edge cases decided
- **Partial payment:** same address can be topped up; progress bar; no pause while within due + grace.
- **Wrong network / token:** funds are lost (said on the card); only USDT on the two listed contracts counts.
- **Network fee:** paid by the sender (the card says to add it).
- **Month without live trades or in the red:** no invoice; the high-water mark stays.
- **Fee < 5 USDT:** carried to the next month; at stop-using time nothing is owed (a stated rule).
- **Exchange outage / chain endpoint down:** never marks paid, never pauses by itself; reported as «CHAIN_UNAVAILABLE».
- **Stopping use:** nothing is held **except a prepaid balance, which stays on the balance and is not paid out** (§9); the last statement is final.
- **Prepaid, partial top-up:** the address is topped up like an invoice; the person can close it at what has arrived. **Overpaid top-up:** everything that arrived is credited. **Top-up paid after the invoice:** the open invoices are paid from the balance at once (§9). **Balance short at month end:** it takes what it has, the rest is a normal invoice. **Month in the red, under the high-water mark, or fee under 5 USDT:** the balance takes nothing.

## 6. Honest limits

- A local app **cannot force** payment (edit the code, delete the database, new install id). Today the mechanism is an invoice, a clear rule and a pause for people who use the operator's build. Real enforcement needs a hosted/licensed distribution; exchange-native profit sharing (copy-trading lead) is the only fully enforced model and is a different product.
- USDT removes the card processor, **not** obligations: income, VAT, AML/MiCA-style rules for receiving crypto as a business, consumer-protection terms. Get legal and tax advice before the first real charge.
- The 9 % covers only CandleLab's own live trades; manual trading outside CandleLab is not in the base.
- **Holding prepaid money** (custody, refund rights of unused prepaid balances, tax timing, AML) is a separate question per jurisdiction: see §9.

## 7. Decisions needed (all taken, see the table at the top)

1. Deposit scheme: **B (customer codes, recommended for early access)**, keep A, or C.
2. Consent: terms modal at first live arming and `since` = first live trade (recommended).
3. Verification: cross-check the base against the exchange's income history (recommended) or keep local-only.
4. Receipts/vouchers: build them (recommended) or defer.
5. Prepaid credit (D) now or later. **Taken on 14 Oct 2026: now, minimal (§9).**
6. When to merge the branch and switch billing on (the landing text changes at that moment).

## 8. Landing wording when billing goes live (no promises of profit)

EN: «CandleLab is free to test and to follow in paper. If you run it with real money, the fee is 9 % of the net profit above your best result so far, paid monthly in USDT. A losing month costs nothing; if you stop paying, only CandleLab's new entries pause.» UA: «CandleLab безкоштовний для тестів і paper. Якщо ви запускаєте його з реальними грошима, комісія — 9 % чистого прибутку вище вашого найкращого результату, щомісяця в USDT. Збитковий місяць нічого не коштує; якщо ви перестаєте платити, на паузу стають лише нові входи CandleLab.»

## 9. Prepaid balance (decided and built, 14 Oct 2026)

**Request (owner, translated):** «think about whether this is sensible: add the ability to prepay, so a user can hold a balance from which the fee is deducted automatically when a trading month ends (only if the month is positive and also overall positive for the whole period), but only if this is simple to do; and put a notice somewhere that the user cannot withdraw money from this balance for now, and that the balance exists so it can be taken as the fee and trading never stops because of an unpaid invoice.»

**Assessment: sensible, and simple when it reuses what exists.** The fee rule is already «9 % of net profit above the high-water mark», so a fee is due only when the month is positive AND the cumulative result is above the mark (`due > 0` implies both); «deduct only then» is therefore «apply the balance to a statement whose fee is due», which is a few lines in `settle()` and needs no new rule. A top-up is an ordinary invoice (same addresses from the public key, same watcher, same matching, same receipts), so there is no new deposit scheme and nothing that can spend. What is NOT simple, and was therefore kept small: legal custody questions (below), the operator's accounting (deposits are visible on the chain, applications are not), and what happens when money arrives out of step with invoices.

**Design (built):** top-ups are invoices of kind `credit` at path attempts 64…69 per month (so the operator's scan enumerates them); a confirmed top-up becomes a `credit` entry in an append-only local ledger; the balance is computed; at settle, `min(balance, what is left)` is taken for a fee that is due, in the same transaction as the statement, idempotently (key `apply:<month>#1`); a fully covered invoice is `paid` (`settledBy: 'balance'`), a short balance leaves a normal invoice for the rest; the unpaid-invoice pause is unchanged (a balance-paid invoice is paid, a top-up is never a debt). Caps: top-up 10…100 USDT, balance ≤ 200 USDT, six top-up addresses a month. Terms bumped to `2026-10-14.2` with the clause and the notice; everyone re-accepts before the next real-account arming (nothing else stops; see BILLING.md «Terms and consent»).

**One deviation from the letter of the brief, with the reason:** the brief applies the balance when a statement is finalised. This build also applies it when the balance **grows** while a fee invoice is still open (a top-up confirmed after the invoice, or an operator `balance-add`), oldest invoice first, as a further `application` entry of the same statement (`apply:<month>#2…`). Without it a customer who prepays to avoid the pause could sit with a balance next to an overdue invoice and still be paused, which contradicts «trading never stops because of an unpaid invoice». It still takes money only for a fee that is due (the invoice exists only then) and never twice. Also added to the brief: a top-up can be **closed** at what has arrived (otherwise an underpaid top-up strands money); the person must tick that they understand the balance cannot be withdrawn (the server requires it and records when); the ledger is checked on every use and a ledger that does not replay is not spent from; `billing.terms` now keeps a `history` of accepted versions.

**What the operator can and cannot see:** deposits per customer (`billing:scan`, `kind=topup`); not applications (they exist in the customer's ledger, receipts and statements). Refunds are not offered (the notice says so); if the operator ever repays money by hand, the `balance-sub` voucher records it in the customer's ledger so the books stay explainable. The model stays trust-based, like the rest of billing.

**Open before real customers:** a lawyer must look at holding prepaid customer money in USDT (custody, refund rights, tax timing, AML). The notice's «for now» is the owner's wording and states the present only; the lawyer should confirm the wording. The landing is not changed (another agent owns it): the FAQ sentence is a TODO in [LANDING.md](LANDING.md).
