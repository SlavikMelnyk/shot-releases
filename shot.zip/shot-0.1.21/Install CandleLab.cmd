@echo off
rem Double-click on Windows: installs CandleLab from this folder (no download, no prerequisites), starts it and opens the browser.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" -FromDir "%~dp0."
pause
