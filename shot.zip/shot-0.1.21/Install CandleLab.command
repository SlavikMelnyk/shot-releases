#!/bin/sh
# Double-click on macOS: installs CandleLab from this folder (no download, no prerequisites), starts it and opens the browser.
cd "$(dirname "$0")" || exit 1
sh ./install.sh --from-dir "$(pwd)"
status=$?
echo
printf 'Press Enter to close this window... '
read -r _
exit $status
